import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        flex:1,
        backgroundColor: '#ffffff',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    showinput: {
        flexDirection: 'row',
        marginBottom: 10,
        borderColor: 'black',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    textInput: {
        color: 'black',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    ficon:{
        width:22,
        height:20,
        margin:10,
        
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
      profileimg:{
    //   borderWidth:1,
      width:90,
      height:90,
      backgroundColor:'#d4d4d4',
      borderRadius:48
       
      }
})