import React, { useEffect, useState } from 'react';
import { ScrollView,ActivityIndicator, Text, TextInput, TouchableOpacity, View, Image,StatusBar } from 'react-native';
import { styles } from './styles';
import { Dropdown } from "react-native-element-dropdown";
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import { Alert } from 'react-native';
import FastImage from 'react-native-fast-image';


export default function Editprofile({ navigation }) {
    const [value, setValue] = useState('');
    const [uid,setUid]=useState('');
    const [vnum,setVnum]=useState('');
    const [full_name, setfull_name] = useState('');
    const [gender, setGender] = useState('');
    const [address, setAddress] = useState('');
    const [email1, setEmail1] = useState('');
    const [team, setTeam] = useState('');
    const [contact_number, setContact_number] = useState('');
    const [name1, setName1] = useState('');
    const [isFocus, setIsFocus] = useState(false);
    const [name, setName] = useState()
    const [email, setEmail] = useState()
    const [call, setCall] = useState()
    const [lacation, setLocation] = useState()
    const [ptd, setPtd] = useState()
    const [sp, setSp] = useState()
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [loading, setLoading] = useState(false);
    const [utype, setUsertype] = useState('');
    const [image, setImage] = useState();
    const [profileimg1, setProfile1] = useState('');
  

    var ImagePicker = require('react-native-image-picker');
    
    const data = [
        { label: 'female', value: '1' },
        { label: 'male', value: '2' },
    ]
    useEffect(() => {
        async function fetchData() {
            navigation.addListener('focus', async () => {
               
                getdata();
            })
            const type = await AsyncStorage.getItem('usertype')
            setUsertype(type); 
            // const result = await AsyncStorage.getItem('lunguage');
            // //console.log('launuage => ', result);
            const typelang = await AsyncStorage.getItem('type');
            //console.log('typelang== => ', typelang);
            selectlang(typelang)
        }
        fetchData();
        
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };

    const selectlang = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
       

    }
    const getdata = async () => {
        setLoading(true)
        const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)
        //console.log('userdataeditcomp => ', screenData)
        setUid(screenData.id)
        setName1(screenData.company_name)
        setEmail1(screenData.email)
        setfull_name(screenData.full_name)
        setGender(screenData.gender)
        setAddress(screenData.address)
        setTeam(screenData.team)
        setContact_number(screenData.contact_number)
        setVnum(screenData.vehicle_number)
        setProfile1(screenData.profile_pic)

        setLoading(false)
        
}
    const update =async () => {
        const pic = []
        if (profileimg1) {
            pic.push(profileimg1)
        }
        //console.log('vnum>>>>',vnum)
        //console.log('pic.toString()>>>>',pic.toString())
        setLoading(true)
    
         fetch(global.url+'updateprofile.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body:JSON.stringify({
                    user_id:vnum,
                    profile_pic:pic.toString()
                   }),
            })
            .then((res) => res.json())
            .then(async(json) => {  
                
                if (json.ResponseCode == '1') {
                    //console.log('ResponseMsg',json)
                    const result1 = await AsyncStorage.getItem('QasLogin')
                    const screenData = JSON.parse(result1)
                    const newUpdatedUserInfo = {
                        ...screenData,
                        "profile_pic": pic.toString()
                      };
                      AsyncStorage.setItem('QasLogin', JSON.stringify(newUpdatedUserInfo))
                      //console.log('newUpdatedUserInfo',newUpdatedUserInfo)
                      Alert.alert('','Update successfully')
                      navigation.navigate('Setting')
                    }
                     else {
                        alert(json.ResponseMsg)
                    }
                    setLoading(false)
                })
					.catch((err) => {
                    //console.log(err);
                    //console.log(err)
                });       
         }
    


    function selectimage(imgid) {
        Alert.alert("Alert", "Choose an option", [
            {
                text: 'Back',
                onPress: () => { },
            },
            {
                text: 'Camera',
                onPress: () => openCamera(imgid),
            },
            {
                text: 'Library',
                onPress: () => openLibrary(imgid)
            },
        ]);
    }


    const openCamera = (imgid) => {
        var options = {
            mediaType: 'photo',
            includeBase64: true,
            quality: 1,
            maxHeight: 500,
            maxWidth: 500,

        }
        ImagePicker.launchCamera(options, (response) => {
            // //console.log('response>>',response)
          if(response.didCancel != true){
            let base64Image = response.assets[0].base64;
            // //console.log('base64Image>>>',base64Image)

            setLoading(true)
            fetch(global.url + 'imageupload.php',
                {
                    method: 'post',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        base64: base64Image
                    }),
                })
                .then((res) => res.json())
                .then((json) => {
                    if (json.ResponseCode == '1') {


                        if (imgid == '1') {
                            let userpic1 = json.image_url
                            setProfile1(userpic1)
                        }
                       

                        setLoading(false)
                    }
                })
                .catch((err) => {
                    setLoading(false)
                })
            }
        },
        )
    }
    const openLibrary = async (imgid) => {

        var options = {

            mediaType: 'photo',
            includeBase64: true,
            quality: 1,
            maxHeight: 500,
            maxWidth: 500,
        }
        ImagePicker.launchImageLibrary(options, response => {
            if(response.didCancel != true){
            let base64Image = response.assets[0].base64;


            setLoading(true)
            fetch(global.url + 'imageupload.php',
                {
                    method: 'post',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        base64: base64Image
                    }),
                })
                .then((res) => res.json())
                .then((json) => {
                    if (json.ResponseCode == '1') {

                        if (imgid == '1') {
                            let userpic1 = json.image_url
                            setProfile1(userpic1)
                        }
                       
                        setLoading(false)
                    }
                })
                .catch((err) => {
                    setLoading(false)
                })
            }
        })
    };
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
            <StatusBar backgroundColor='#ffffff' barStyle="dark-content" />

                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <View style={{ height: 15 }}></View>
                    <Text style={{ fontSize: 25, color: 'black' }}>{t('Edit Profile')}</Text>
                    <View style={{ height: 15 }}></View>

                    {profileimg1?
                     <TouchableOpacity style={styles.profileimg} onPress={() => selectimage('1')} onChangeText={(value) => setImage(value)} value={image}>
                                  <FastImage resizeMode='contain' style={{flex:1}}  source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg1}` }} />
                     </TouchableOpacity>
                    :
                    <TouchableOpacity style={styles.profileimg} onPress={() => selectimage('1')} onChangeText={(value) => setImage(value)} value={image}>
                    <FastImage resizeMode='contain' style={{flex:1}}source={require('../../../image/user.png')} />
              </TouchableOpacity>
                    }
            {/* {profileimg1?
                   <TouchableOpacity style={styles.profileimg} onPress={() => selectimage('1')} onChangeText={(value) => setImage(value)} value={image}>
                        <FastImage resizeMode='contain' style={{flex:1}}  source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg1}` }} />
                    </TouchableOpacity>
                    : 
                    <TouchableOpacity style={styles.profileimg} onPress={()=>navigation.navigate('Editprofile')}>
                  
                    <FastImage resizeMode='contain' style={{flex:1}}source={require('../../../image/user.png')} />
                 </TouchableOpacity>
                } */}

                    <View style={{ height: 10 }}></View>
                    {utype!='2'?
                      <View style={styles.showinput}>
                             <Ionicons name="person-outline" size={25} style={{ margin: 6 }} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setVnum(value)} value={vnum} />
                    </View>
                    :
                    <View>
                         <View style={styles.showinput}>
                        <Ionicons name="person-outline" size={25} style={{ margin: 6 }} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setfull_name(value)} value={full_name} />
                       
                    </View>
                    {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                    <View style={{ height: 10 }}></View>
                    <View style={styles.showinput}>
                        <Ionicons name="mail-outline" size={25} style={{ margin: 6 }} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setEmail1(value)} value={email1} placeholder="Johnluccs@gmail.com" />
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.showinput}>
                        <Ionicons name="call-outline" size={25} style={{ margin: 6 }} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setContact_number(value)} value={contact_number} placeholder="J98562356" />
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.showinput}>
                        <Ionicons name="location-outline" size={25} style={{ margin: 6 }} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setAddress(value)} value={address} placeholder="500 nabj lkjiu hajb jjh" />
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.showinput}>
                        {gender == '1' ?
                            <Ionicons name="female" size={25} style={{ margin: 6 }} />
                            :
                            <Ionicons name="male" size={25} style={{ margin: 6 }} />
                        }
                        <View style={{ width: '80%', marginHorizontal: 15, letterSpacing: 1.5, fontSize: 18 }}>
                            <Dropdown
                                style={[styles.dropdown]}
                                placeholderStyle={styles.placeholderStyle}
                                selectedTextStyle={styles.selectedTextStyle}
                                iconStyle={styles.iconStyle}
                                data={data}
                                maxHeight={300}
                                labelField="label"
                                valueField="value"
                                placeholder={!isFocus ? 'Female' : '...'}
                                value={gender}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => setIsFocus(false)}
                                onChange={(item) => {
                                    setGender(item.value);
                                    setIsFocus(false);
                                }}
                            />
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                   
                    <View style={styles.showinput}>
                        <Image style={styles.ficon} source={require('../../../image/editb.png')} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setName(value)} value={name1} placeholder="Rentail Intail Singapore Pte.Ltd." />
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.showinput}>
                        <Image style={styles.ficon} source={require('../../../image/editb.png')} />
                        <TextInput style={styles.textInput} onChangeText={(value) => setTeam(value)} value={team} placeholder="Sp." />
                    </View>
                    </View>
                    }
                   
                    <View style={{ height: 20 }}></View>
                    <TouchableOpacity style={styles.btn} onPress={update}>
                        <Text style={styles.btninner}>
                           {t('Update')} 
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};