import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#ffffff',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    dropdown:{
        borderWidth:0,
        width:'88%',
        alignSelf:'center',
        padding:10,
        backgroundColor:'#afdbfc',
        borderRadius:20,
        // marginTop:-10
    },
    placeholderStyle:{
        fontSize:20,
        color:'#000000'
    },
    selectedTextStyle:{
            fontSize:20,
            color:'#000000'
    },
 
    
})