import React, { useState, useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, StatusBar, Image, Alert,SafeAreaView } from 'react-native';
import { styles } from './styles';
import { Dropdown } from "react-native-element-dropdown";
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import { resetNavigateTo } from '../../../NavigationHelper';

export default function Selectlanguage({ navigation }) {
    const [value, setValue] = useState('1');
    const [isFocus, setIsFocus] = useState(false);
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('en');
    const [click1,setclick1]=useState(0);
    const [click2,setclick2]=useState(0);

    const changeLanguage = value => {

        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };

    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        //   alert('english')
        //   alert(value)
         
        }
        if (value == '2') {
            changeLanguage('hi')
            // alert(value)

         
        }
      
        await AsyncStorage.setItem('lunguage',currentLanguage)
        await AsyncStorage.setItem('type', value)

        Alert.alert(  
            '',  
            (t('Successfully Changed Language')),  
            [  
                {  
                    text: 'ok',  
                    onPress: () => navigation.navigate('Home'),  
                    
                },  
                
            ]  
        );
    }
// const data = [
//         { label: 'English', value: '1' },
//         { label: 'Chinese', value: '2' },
//     ]

    useEffect(() => {
        async function fetchData() {
            const result = await AsyncStorage.getItem('lunguage');
            //console.log('launuage => ', result);
            const type = await AsyncStorage.getItem('type');
            //console.log('type== => ', type);
            if(type=='1'){
                setclick1(1)
            }else if(type=='2'){
                setclick2(1)
            }
            setValue(type)
        }
        fetchData();
    }, [])
    const English =(pass)=>{
        //console.log('pass1>>>',pass)

        selectlan(pass)
        setclick1(1)
        setclick2(0)
    }
    const Chinese =(pass)=>{
        //console.log('pass2>>>',pass)
        selectlan(pass)
        setclick2(1)
        setclick1(0)
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#346696' }}>
         <View style={styles.maincontainer}>
            <StatusBar backgroundColor='#346696' barStyle="dark-content" />
             <TouchableOpacity style={{backgroundColor:'#346696',paddingLeft:20,}} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={35}  style={{color:'#ffffff',marginLeft:-10}}/>
            <Text style={{fontSize:25,color:'#ffffff',marginTop:20,marginLeft:10,marginBottom:10}}>Please select your preferred language</Text>
            <Text style={{fontSize:25,color:'#ffffff',marginLeft:10,marginBottom:10}}>请  选择 你的 首选 语言</Text>
               
            </TouchableOpacity>


            <View style={{ width: '100%',flex:0,flexDirection:'row',borderWidth:0,padding:10,marginTop:30,marginLeft:20}}>
                {click1=='1'?

                <TouchableOpacity onPress={()=>English('1')} style={{height:20,width:20,borderWidth:0,backgroundColor:'#346696',borderRadius:10,marginTop:3}}></TouchableOpacity>

                 :
                <TouchableOpacity onPress={()=>English('1')} style={{height:20,width:20,borderWidth:1,borderRadius:10,marginTop:3}}></TouchableOpacity>
                }

                <Text style={{fontSize:20,borderWidth:0,marginLeft:10,marginRight:20}}>English</Text>
             
                {click2=='1'?

                    <TouchableOpacity onPress={()=>Chinese('2')} style={{height:20,width:20,borderWidth:0,backgroundColor:'#346696',borderRadius:10,marginTop:3}}></TouchableOpacity>
                    :
                    <TouchableOpacity onPress={()=>Chinese('2')} style={{height:20,width:20,borderWidth:1,borderRadius:10,marginTop:3}}></TouchableOpacity>
                    }

                <Text style={{fontSize:20,borderWidth:0,marginLeft:10}}>Chinese</Text>      
            </View>
                    {/* <View style={{ width: '70%' ,marginTop:3,backgroundColor:'#0b538a',alignSelf:'center',height:'50%',justifyContent:'center',margin:35,borderRadius:20}}>
                            <Dropdown
                                style={[styles.dropdown]}
                                placeholderStyle={styles.placeholderStyle}
                                selectedTextStyle={styles.selectedTextStyle}
                                iconStyle={styles.iconStyle}
                                data={data}
                                maxHeight={300}
                                labelField="label"
                                valueField="value"
                                placeholder={!isFocus ? 'Language' : '...'}
                                value={value}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => setIsFocus(false)}
                                onChange={(item) => {
                                    selectlan(item.value);
                                    setIsFocus(false);
                                }}
                            />
                        </View> */}
        </View>
        </SafeAreaView>
        // </View>
    )
}
