import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
        // borderWidth:2,
        justifyContent:'center'
    },
    imgcontainer:{
        // borderWidth:1,
        alignSelf:'center',
        
        
    },
    btn:{
        height:50,borderRadius:3,backgroundColor:'#346696',width:'91%',margin:'5%'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:19,fontWeight:'bold',paddingTop:12
    },
})