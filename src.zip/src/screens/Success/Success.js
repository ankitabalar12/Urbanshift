import React, { useState ,useEffect} from "react";
import {
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  StatusBar
} from "react-native";

import { styles } from "./styles";
import FastImage from "react-native-fast-image";
 const Success = ({ navigation,route }) => {
  const [type,settype]=useState();
  useEffect(() => {
  navigation.addListener('focus', async() => {
   const gettype =route.params
   console.log('gettype',gettype)
   settype(gettype)
     })
    }, []);
return(
	<View style={styles.maincontainer}>
<ScrollView>
        <View style={styles.imgcontainer}>
        <Image style={{
          resizeMode:'stretch',
          height:350,
        width:350
        }} source={require('../../../image/Success.png')} />
      </View>
      <Text style={{fontSize:30,color:'#0d0d26',fontWeight:'bold',alignSelf:'center',marginTop:'5%'}}>Success!</Text>
      <View style={{borderWidth:0,marginTop:'3%',padding:'3%'}}>
        {type==1?
      <Text style={{fontSize:20,color:'#95969d',alignSelf:'center'}}>You have a successfully clocked out</Text>
       :
      <Text style={{fontSize:20,color:'#95969d',alignSelf:'center'}}>You have a successfully clocked in</Text>
        }
      <Text style={{fontSize:20,color:'#95969d',borderWidth:0,alignSelf:'center'}}>Have a good day! </Text>
      </View>
              <TouchableOpacity style={styles.btn} onPress={()=>{navigation.navigate('Atten')}} >
                        <Text style={styles.btninner}>
                        Back to The attendance
                        </Text>
                    </TouchableOpacity>
                    </ScrollView>
    </View>
)

}
export default Success;