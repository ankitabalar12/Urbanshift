import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    date: {
        borderWidth: 1, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row'
    },
    ficon: {
        width: 25,
        height: 25,
        margin: 9,
        borderWidth:1
    },
    btn: {
        height: 45, borderRadius: 3, backgroundColor: '#346696',
        marginTop: 120
    },
    btninner: {
        textAlign: 'center', color: 'white', fontSize: 18, fontWeight: 'bold', marginTop: 7
    },
    yes: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill: {
        borderWidth: 1,
        width: '41%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'2%'

    },
    no: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout: {
        borderWidth: 1,
        width: '41%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'2%'

    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
      yes2: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill2: {
        borderWidth: 1,
        width: '35%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'2%'
    },
    no2: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout2: {
        borderWidth: 1,
        width: '35%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'2%'
    },
    container: {
        flex: 1,
        paddingTop: 30,
       
      },
      date1:{
        borderWidth: 1, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row' ,flex:1
    },
    yes3: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill3: {
        borderWidth: 1,
        width: '27%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'1%'
    },
    no3: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout3: {
        borderWidth: 1,
        width: '27%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'1%'
    },
})