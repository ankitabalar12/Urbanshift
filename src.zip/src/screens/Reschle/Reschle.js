import React, { useState,useEffect } from 'react';
import { ScrollView, Text, ActivityIndicator,TextInput, TouchableOpacity, View, StatusBar, Image,SafeAreaView, Alert } from 'react-native';
import { styles } from './styles';
import DateTimePicker from '@react-native-community/datetimepicker';
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import CalendarPicker from 'react-native-calendar-picker';
import moment from 'moment';




export default function Reschle({ route,navigation }) {
    const [dates, setdates] = useState('');
    const [di, setdi] = useState('');
    const [Value, setValue] = useState('');

    // const [is_select, setSelect] = useState('');
    const [datePicker, setDatePicker] = useState('');
    const [date, setDate] = useState(new Date());
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [adate,setADate]=useState('');
    const [atime,setAtime]=useState('');
    const [submitted, setsubmitted] = useState(false)
    const [loading, setLoading] = useState(false);
    const [userid,setUserID] = useState('');
    const [dob,setDob] = useState("");

    const [time1,setTime1] = useState(false);
    const [time2,setTime2] = useState(false);
    const [time3,setTime3] = useState(false);
    const [time4,setTime4] = useState(false);
    const [time5,setTime5] = useState(false);
    const [time6,setTime6] = useState(false);
    const [time7,setTime7] = useState(false);
    const [select,setSelect]=useState('');
    const [service_type,setService_type]=useState('');
    const [oldd,setOldd]=useState('');
    const [oldt,setOldt]=useState("");
    const [stype,setStype]=useState('');
    const [id,setId]=useState('');
    const [selectedStartDate, setSelectedStartDate] = useState('');
    const [dis,setdis]=useState([]);
    const [weekdays, setWeekdays] = useState([ 'Mon', 
    'Tue', 
    'Wed', 
    'Thur', 
    'Fri', 
    'Sat', 
    'Sun']);
    const [selectsat,setSelectsat]=useState('');
    const [holi,setholi]=useState('');
    const [apidate, setapidate] = useState('');



    const onDateSelected = (date) => {
        setholi(0)
        //console.log('***********date',date)
        // //console.log(di,'di++++++++++')
        const res = date.replace(/-/g,'')
        const res2 =res.replace(/ /g,'')
      for (var i=0;i<dis.length;i++){
            //console.log('dis[i]---->>>>',dis[i])
            //console.log(i)
            // setdisable(dis[i])
            //console.log('dis[i]*********',dis[i])
            //console.log('res++++++++++',res2)
            if(res2==dis[i]){
                  Alert.alert('','Sorry, we are not open on Sundays and Public Holidays')
                  setDatePicker(true)
                  setholi(1)
            }else{
                setDatePicker(false);
                // const string =date
          
                setapidate(apidate)
            }
         
        }
      
        const string =date
        
        let firstChar = string.charAt(1); 
        //console.log('string-->>>',firstChar)
       
        if(firstChar=='7'){
           Alert.alert('','Sorry, we are not opne on Sundays and Public Holidays')
            setDatePicker(true);
        }else{
            setDatePicker(false);
        }
        setSelectsat(firstChar)
        if(firstChar=='7' || holi==1){
            //console.log('condition true')
            setapidate('')
            //console.log('if****===>>>',apidate)
        }else{
            let newStr = string.substr(2, string.length - 1); 
            //console.log(newStr)
            const apidate =newStr.replace(/ /g,'')
            setSelectedStartDate(apidate);
            //console.log('else****===>>>',apidate)
            setapidate(apidate)
        }
        
    
     
      };


   const changetime1 = () => {
        
        setTime1(true)
        setTime2(false)
        setTime3(false)
        setTime4(false)
        setTime5(false)
      
        const timee = '9am-10:30am'
        setSelect(timee);
     }
   const changetime2 = () => {
    setTime1(false)
    setTime2(true)
    setTime3(false)
    setTime4(false)
    setTime5(false)

    const timee1 = '10:30am-12pm'
    setSelect(timee1);
   
        }
    const changetime3 = () => {
        setTime1(false)
        setTime2(false)
        setTime3(true)
        setTime4(false)
        setTime5(false)
      
    const timee2 = '1pm-2:30pm'

        setSelect(timee2)
     }
    const changetime4 = () => {
        
        setTime1(false)
        setTime2(false)
        setTime3(false)
        setTime4(true)
        setTime5(false)
       
    const timee3 = '2:30pm-4pm'

        setSelect(timee3);
        
    }
   const changetime5 = () => {
    setTime1(false)
    setTime2(false)
    setTime3(false)
    setTime4(false)
    setTime5(true)
    const timee4 = '4pm-6pm'
    setSelect(timee4);
    }
      
useEffect(() => {
        navigation.addListener('focus', async () => {
            // getdata();
            const typee = await AsyncStorage.getItem('type');
            //console.log('type== => ', type);
            selectlan(typee)
          const info =route.params
          //console.log(info)
          const olddate =info.date
          const type=info.service_type
          
          const user=info.id
          //console.log('*************')
          //console.log(olddate)
          //console.log(info.time)    
          //console.log(type)  
          setapidate(olddate)
        setSelectedStartDate(olddate)
      
        setStype(type)
        setId(user)
        setSelect(info.time);
        
          if(info.time =='9am-10:30am'){
              setTime1(true)
             }else if(info.time =='10:30am-12pm'){
                    setTime2(true)
                    
                }else if(info.time =='1pm-2:30pm'){
                    setTime3(true)
                    //console.log('**********************************************',time3)
                    
        
                }
                else if(info.time =='2:30pm-4pm'){
                    setTime4(true)
                    
        
                }
                else if(info.time =='4pm-6pm'){
            
                    setTime5(true)
                    
        
                }
               
                    if(selectsat !=6){
                       if(info.time =='1pm-3pm'){
                            setTime3(true)
                            //console.log('**********************************************',time3)
                            
                
                        }else if(info.time =='3pm-5pm'){
                            setTime4(true)
                        }

                    }

           
                    dis.push('10212023','20312023','12312023','22412023','50742023','62242023','10152023','50262023','42962023','30982023','113112023','125122023')
         
                    //console.log(dis)  
    })
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
      

    }

  
    const valueformatedate = (value) => {
        //console.log(value)
        var month = ["January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"];
        var strSplitDate = String(value).split(' ');
        var dates = new Date(strSplitDate[0]);
        var dd = date.getDate();
        var mm = month[date.getMonth()];
        var yyyy = date.getFullYear();
        var conformdate = dd + ' ' + mm + ' ' + yyyy
        //console.log(conformdate)
        return conformdate
    }
    const showDatePicker = () => {
        setDatePicker(true);
    };
    const register = () => {
        setIsRegister('1')
    }
   
   
    const update=()=>{
       
      if (selectsat != '7') {
        // {selectsat=='7' || holi=='1'?
      //console.log('date pass>>>',apidate)
      //console.log('time pass>>>',select)
      //console.log('id pass>>>',id)
       setLoading(true)
        //console.log('###########')
           
            fetch(global.url+'rescheduleappointment.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: id,
                    adate: apidate,
                    atime:select
                }),
            })

                .then((res) => res.json())
                .then(async(json) => {
                    // //console.log('Response =>', json)
                    //console.log(date)
                    //console.log(select)
                    if (json.ResponseCode == '1') {
                     //console.log('update console',json)
                    //  await AsyncStorage.setItem('QasUpdate', JSON.stringify(json.upcomming));
                 
                     navigation.navigate('Conformation')
                    } else {
                        alert(json.ResponseMsg)

                        setLoading(false);
                    }
                   
                })
                .catch((err) => {
                    //console.log(err)
                });
        
        }
    }
    return (
        <View style={styles.maincontainer}>

            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 20 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="chevron-back" size={35}  style={{color:'black',marginLeft:-10}}/>
                    </TouchableOpacity>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ marginTop: 10, fontSize: 25, color: 'black' }}>
                        {t('Reschedule')}
                    </Text>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ fontSize: 17 }}>{t('Your current appointment is on.')}</Text>
                    <View style={{ height: 10 }}></View>

                    <View style={{ width: '100%', flexDirection: 'row' }}>
                        <View style={{ width: '15%' }}>
                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/cal.png')} />
                        </View>
                        <View style={{ width: '80%' }}>
                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{apidate}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row' }}>
                        <View style={{ width: '15%' }}>
                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clock.png')} />
                        </View>
                        <View style={{ width: '80%' }}>
                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{stype}</Text>
                        </View>
                    </View>
                    <View style={{ height: 25 }}></View>
                    <Text style={{ fontSize: 17 }}>{t('Please select new date and time(DD-M-YYYY)')}</Text>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={showDatePicker}>
                    <View style={styles.date1}>
                       
                                <Image style={styles.ficon} source={require('../../../image/datenew1.png')} />
                                {/* {selectsat=='7' || holi=='1'? */}
                            {/* <Text style={{alignSelf:'center',fontSize:16}}>null</Text> */}

                                {/* : */}
                                {selectsat=='7' || holi=='1'?
                                <Text style={{alignSelf:'center',fontSize:16}}>null</Text>
                             

                                :
                                <Text style={{alignSelf:'center',fontSize:16}}>{selectedStartDate.toString()}</Text>
                                }
                            {/* <Text style={{alignSelf:'center',fontSize:16}}>{selectedStartDate.toString()}</Text> */}
                            {/* } */}
                       </View>
                    </TouchableOpacity>

                 
                        <SafeAreaView>       
      <View style={styles.container}>
       
        {datePicker?
        <CalendarPicker
          startFromMonday={true}
        //   allowRangeSelection={true}
          minDate={new Date(2018, 1, 1)}
          maxDate={new Date(2050, 6, 3)}
          weekdays={weekdays}
       
          months={[
            'January',
            'Febraury',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December',
          ]}
          previousTitle="Previous"
          nextTitle="Next"
          todayBackgroundColor="#e6ffe6"
          selectedDayColor="#66ff33"
          selectedDayTextColor="#000000"
          scaleFactor={375}
          textStyle={{
            fontFamily: 'Cochin',
            color: '#000000',
          }}
        //   onDateChange={onDateSelected}
        onDateChange={(res) => onDateSelected(moment(res).format(" E YYYY - M - DD "))}
          

        //   disabledDates={weekdays}
          value={apidate}
        />:null}
    
      </View>
      </SafeAreaView>  
            <View>
                        <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>


                        <TouchableOpacity onPress={changetime1} style = { time1? styles.yesfill : styles.noout}>
                           <Text style = { time1? styles.yes : styles.no}>
                           9am - 10:30am
                            </Text>
                    </TouchableOpacity>
            <TouchableOpacity onPress={changetime2} style = { time2? styles.yesfill : styles.noout}>
                           <Text  style = { time2? styles.yes : styles.no}>
                           10:30am - 12pm
                         </Text>
                         </TouchableOpacity>
                   
                            
                        </View>
                        {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                        <View style={{ height: 10 }}></View>
                        {selectsat != 6?
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                <TouchableOpacity onPress={changetime3} style={time3 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time3 ? styles.yes2 : styles.no2}>

                                            1pm - 2:30pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime4} style={time4 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time4 ? styles.yes2 : styles.no2}>
                                           2:30pm - 4pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime5} style={time5 ? styles.yesfill3 : styles.noout3}>
                                        <Text style={time5 ? styles.yes3 : styles.no3}>
                                           4pm -6pm
                                        </Text>
                                    </TouchableOpacity>
                                    
                                </View>
                                :
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                <TouchableOpacity onPress={changetime3} style={time3 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time3 ? styles.yes2 : styles.no2}>

                                            1pm - 3pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime4} style={time4 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time4 ? styles.yes2 : styles.no2}>
                                           3pm - 5pm
                                        </Text>
                                    </TouchableOpacity>
                                  </View>
                                
                                }
                    </View>
                    <TouchableOpacity style={styles.btn} onPress={update}>
                        <Text style={styles.btninner}>
                            {t('Update')}
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};