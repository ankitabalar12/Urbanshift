import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    SafeAreaView,
    Dimensions,
    ActivityIndicator,
    Alert
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Dropdown } from "react-native-element-dropdown";
import FastImage from 'react-native-fast-image';
import AsyncStorage from '@react-native-community/async-storage';
import Modal from "react-native-modal";
var ImagePicker = require('react-native-image-picker');
import { PureRoundedCheckbox } from "react-native-rounded-checkbox";



const Ins = ({ navigation, route }) => {
    const [date, setDate] = useState(new Date());
    const [datePicker, setDatePicker] = useState(false);
    const [From, setFrom] = useState(new Date());
    const [To, setTo] = useState(new Date());
    const [show, setShow] = useState(false);
    const [currentSetting, setcurrentSetting] = useState('from');
    const [From1, setFrom1] = useState('');
    const [To1, setTo1] = useState(new Date());
    const [show1, setShow1] = useState(false);
    const [currentSetting1, setcurrentSetting1] = useState('from');
    const [loading, setLoading] = useState(false);
    const [From2, setFrom2] = useState('');
    const [value1, setValue1] = useState('');
    const [width, setWidth] = useState('');
    const [m2, setM2] = useState(0);
    const [m4, setM4] = useState(0);
    const [category, setCategory] = useState('');
    const [category2, setCategory2] = useState('');
    const [vnum, setvnum] = useState('');
    const [vbrand, setvbrand] = useState('');
    const [vmodel, setvmodel] = useState('');
    const [profileimg1, setProfile1] = useState('');
    const [profileimg2, setProfile2] = useState('');
    const [profileimg3, setProfile3] = useState('');
    const [profileimg4, setProfile4] = useState('');
    const [profileimg5, setProfile5] = useState('');
    const [profileimg6, setProfile6] = useState('');
    const [profileimg7, setProfile7] = useState('');
    const [profileimg8, setProfile8] = useState('');
    const [profileimg9, setProfile9] = useState('');
    const [remark, setremark] = useState([]);
    const [b1, setB1] = useState(false);
    const [image, setImage] = useState();
    const [isModalVisible, setModalVisible] = useState(false);
    const [contact, setContact] = useState('');
    const [clickval, setclickval] = useState([]);
    const [dropDownData, setdropDownData] = useState([]);
    const [touch, settouch] = useState(false);
    const [state, setState] = useState(false);
    const [checkedIds, setCheckedIds] = useState([]);
    const [checkedCount, setCheckedCount] = useState(0);
    const [checkedCount2, setCheckedCount2] = useState(1);
    const [mill,setmill]=useState('');
    const [com,setcom]=useState('');
    const [driver,setdriver]=useState('');
    const [con,setcon]=useState('');
    const [to,setto]=useState('');
    const [time,settime]=useState('');
    const [chit,setchit]=useState('');
    const [rem,setrem]=useState('');
    const [done,setdone]=useState('');
    const [des,setdes]=useState('');
    const [req,setreq]=useState('');
    const [is_draft1,setisdarff1]=useState(1);
    const [is_draft0,setisdarff0]=useState(0);
    const [pic,sedtpic]=useState([]);

    const [disable, setdisable] = useState(0);
    const box1 = (label, checked) => {
        //console.log('label:----', label)//name
        //console.log('checked:----', checked)//true or false
        if (checked === true) {
            setCheckedCount(checkedCount);//0 pass
            //console.log(checked, checkedCount)// true 0
        }
        if (checked == false) {
            setCheckedCount2(checkedCount2);// 1 pass
            //console.log(checked, checkedCount2)// false, 1
        }
        if (!clickval.includes(label)) {
            clickval.push(label)// selected value
        } else {
            Alert.alert(
                'This Mechanic Allready Selected',
                'You Remove This Mechanic?',
                [
                    {
                        text: 'Yes',
                        onPress: () => {
                            var index = clickval.indexOf(label)
                            clickval.splice(index, 1);
                        },

                    },
                    {
                        text: 'No',
                        onPress: () => setModalVisible(!isModalVisible)
                    },
                ]
            );

        }
        //console.log('clickval', clickval)
    }
    useEffect(() => {
        setWidth(Dimensions.get('screen').width);


        const Repairarray = route.params.Repair
        //console.log('inspection screenn Repairarray ----', Repairarray)


        const screenData = JSON.parse(Repairarray);

        var data = screenData.map(function (item) {
            return {
                key: item.id,
                label: item.name
            };
        });
        //console.log('----------------------------inspection screen-----------------------')
        //console.log(screenData)
        //console.log('----------------------------inspection screen-----------------------')
        //console.log(data[0].label)
        //console.log(data[1].label)
        //console.log(data[2].label)
        //console.log(data[3].label)
        //console.log(data[4].label)
        //console.log(data[5].label)
        //console.log(data[6].label)
        //console.log(data[7].label)
        //console.log(data[8].label)
        //console.log(data[9].label)
        //console.log(data[10].label)
        //console.log(data[11].label)
        //console.log(data[12].label)
        setvnum(data[0].label)
        setvbrand(data[1].label)
        setvmodel(data[2].label)
        setmill(data[3].label)
        setcom(data[6].label)
        setdriver(data[7].label)
        setcon(data[8].label)
        setto(data[11].label)
        settime(data[10].label)
        setchit(data[12].label)
    

        const desc = route.params.des
        //console.log('inspection screenn desc ----', desc)

        const Remark = route.params.rem
        //console.log('inspection screenn Remark----', Remark)

        const done = route.params.done
        //console.log('inspection screenn done----', done)

        const req = route.params.requirement
        //console.log('inspection screenn req----', req)
        getmac();
        addreport();
        global.draffid=global.id
    }, []);

    const model = () => {
        setModalVisible(!isModalVisible);

    }

    const addreport = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData2 = JSON.parse(result1)
        const Repairarray = route.params.Repair
        //console.log('inspection screenn Repairarray ----', Repairarray)
        // const pic = []

      
        const screenData = JSON.parse(Repairarray);

        var data = screenData.map(function (item) {
            return {
                key: item.id,
                label: item.name
            };
        });
        //console.log('----------------------------inspection screen-----------------------')
        //console.log(screenData)
        //console.log('----------------------------inspection screen-----------------------')
        //console.log(data[0].label)
        //console.log(data[1].label)
        //console.log(data[2].label)
        //console.log(data[3].label)
        //console.log(data[4].label)
        //console.log(data[5].label)
        //console.log(data[6].label)
        //console.log(data[7].label)
        //console.log(data[8].label)
        //console.log(data[9].label)
        //console.log(data[10].label)
        //console.log(data[11].label)
        //console.log(data[12].label)
        //   setvnum(data[0].label)
        //   setvbrand(data[1].label)
        //   setvmodel(data[2].label)
        const desc = route.params.des
        const descarray = desc.toString();
        setdes(descarray)
        //console.log('stringdesc----', descarray)
        const Remark = route.params.rem
        const remarkarray = Remark.toString();
        setrem(remarkarray)
        //console.log('stringremark----', remarkarray)
        const done = route.params.done
        setdone(done)
        const donekarray = done.toString();
        //console.log('stringdone----', donekarray)
        const req = route.params.requirement
        setreq(req)
        const reqkarray = req.toString();
        //console.log('stringreq----', reqkarray)
      
    }
    const getmac = () => {
        setLoading(true);
        fetch(global.url + 'getmechanics.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: 10
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {

                //console.log('Response =>', json)
                if (json.ResponseCode == '1') {
                    await AsyncStorage.setItem('Qasmac', JSON.stringify(json.upcomming));
                    // //console.log(json.upcomming.full_name)
                    // alert('okooko')
                    var count = Object.keys(json.upcomming).length;

                    for (var i = 0; i < count; i++) {
                        dropDownData.push({ value: json.upcomming[i].id, label: json.upcomming[i].full_name }); // Create your array of data
                    }

                    setCategory(dropDownData);
                    setCategory2(dropDownData)
                    //console.log('****************%^%^%^%^', dropDownData)
                    // setData(json.data)
                    // setcategoryDataSource(json.data);
                    // //console.log('json.data', json.data)
                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }
    const onChange = (event, selectedDate) => {
        if (currentSetting === 'from') {
            const currentDate = selectedDate || From;
            setShow(Platform.OS === 'ios');
            setFrom(currentDate);
        } else {
            const currentDate = selectedDate || To;
            setShow(Platform.OS === 'ios');
            setTo(currentDate);
        }
    };
    const showTimepicker = (current) => {
        setShow(true);
        setM2(1)
        setcurrentSetting(current);
    };
    const onDateSelected = (event, value) => {
        //console.log(value)
        setDate(value);
        setDatePicker(false);
    };
    const valueformatedate = (value) => {
        //console.log(value)
        var month = ["January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"];
        var strSplitDate = String(value).split(' ');
        var dates = new Date(strSplitDate[0]);
        var dd = date.getDate();
        var mm = month[date.getMonth()];
        var yyyy = date.getFullYear();
        var conformdate = dd + ' ' + mm + ' ' + yyyy
        //console.log(conformdate)
        return conformdate
    }
    const showDatePicker = () => {
        setM4(1)
        setDatePicker(true);
    };
    const placeholderText2 = 'Time Out'
    const placeholderText4 = 'Date Out'
    function selectimage(imgid) {
        //console.log('****imgid--->>>', imgid)
        Alert.alert("Alert", "Choose an option", [
            {
                text: 'Back',
                onPress: () => { },
            },
            {
                text: 'Camera',
                onPress: () => openCamera(imgid),
            },
            {
                text: 'Library',
                onPress: () => openLibrary(imgid)
            },
        ]);
    }
    const openCamera = (imgid) => {
        //    //console.log('abcdef')
        var options = {
            mediaType: 'photo',
            includeBase64: true,
            quality: 1,
            maxHeight: 500,
            maxWidth: 500,
            cameraType: 'back'
        }
        ImagePicker.launchCamera(options, (response) => {
            let base64Image = response.assets[0].base64;
            //console.log('cameraresponse==>>>', response)
            // //console.log('base64Image-->>',base64Image)
            setLoading(true)
            fetch(global.url + 'imageupload.php',
                {
                    method: 'post',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        base64: base64Image
                    }),
                })
                // //console.log('hello')
                .then((res) => res.json())
                .then((json) => {
                    //console.log(json)
                    if (json.ResponseCode == '1') {
                        //console.log(json.image_url)
                        if (imgid == '1') {
                            let userpic1 = json.image_url
                            setProfile1(userpic1)
                        }
                        if (imgid == '2') {
                            let userpic2 = json.image_url
                            setProfile2(userpic2)
                        }
                        if (imgid == '3') {
                            let userpic3 = json.image_url
                            setProfile3(userpic3)
                        }
                        if (imgid == '4') {
                            let userpic4 = json.image_url
                            setProfile4(userpic4)
                        }
                        if (imgid == '5') {
                            let userpic5 = json.image_url
                            setProfile5(userpic5)
                        }
                        if (imgid == '6') {
                            let userpic6 = json.image_url
                            setProfile6(userpic6)
                        }
                        if (imgid == '7') {
                            let userpic7 = json.image_url
                            setProfile7(userpic7)
                        }
                        if (imgid == '8') {
                            let userpic8 = json.image_url
                            setProfile8(userpic8)
                        }
                        if (imgid == '9') {
                            let userpic9 = json.image_url
                            setProfile9(userpic9)
                        }

                        setLoading(false)
                    }
                })
                .catch((err) => {
                    setLoading(false)
                    //console.log(err)
                })
        },
        )
    }
    const openLibrary = async (imgid) => {
        //console.log('bvcfd')

        var options = {

            mediaType: 'photo',
            includeBase64: true,
            quality: 1,
            maxHeight: 500,
            maxWidth: 500,
        }
        ImagePicker.launchImageLibrary(options, response => {
            let base64Image = response.assets[0].base64;
            //console.log('gallaryresponse==>>>', response)

            //console.log(base64Image)

            setLoading(true)
            //console.log('****** gallary********')
            fetch(global.url + 'imageupload.php',
                {
                    method: 'post',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        base64: base64Image
                    }),
                })
                .then((res) => res.json())
                .then((json) => {
                    //console.log(json)
                    if (json.ResponseCode == '1') {
                        //console.log('Gallary pic----', json.image_url)

                        if (imgid == '1') {
                            let userpic1 = json.image_url
                            setProfile1(userpic1)
                        }
                        if (imgid == '2') {
                            let userpic2 = json.image_url
                            setProfile2(userpic2)
                        }
                        if (imgid == '3') {
                            let userpic3 = json.image_url
                            setProfile3(userpic3)
                        }
                        if (imgid == '4') {
                            let userpic4 = json.image_url
                            setProfile4(userpic4)
                        }
                        if (imgid == '5') {
                            let userpic5 = json.image_url
                            setProfile5(userpic5)
                        }
                        if (imgid == '6') {
                            let userpic6 = json.image_url
                            setProfile6(userpic6)
                        }
                        if (imgid == '7') {
                            let userpic7 = json.image_url
                            setProfile7(userpic7)
                        }
                        if (imgid == '8') {
                            let userpic8 = json.image_url
                            setProfile8(userpic8)
                        }
                        if (imgid == '9') {
                            let userpic9 = json.image_url
                            setProfile9(userpic9)
                        }
                        setLoading(false)
                    }
                })
                .catch((err) => {
                    setLoading(false)
                    //console.log(err)
                })
        })
    };

    const setremarkvalue = (val) => {

        //console.log('remakvalue-----', val)
        remark.push(val);
        //console.log('fullarray', remark)

    }
    const okk = () => {
        setModalVisible(!isModalVisible);

        // navigation.navigate('Description')
    }
      if (profileimg1) {
        pic.push(profileimg1)
    }
    if (profileimg2) {
        pic.push(profileimg2)
    }
    if (profileimg3) {
        pic.push(profileimg3)
    }
    if (profileimg4) {
        pic.push(profileimg4)
    }
    if (profileimg5) {
        pic.push(profileimg5)
    }
    if (profileimg6) {
        pic.push(profileimg6)
    }
    if (profileimg7) {
        pic.push(profileimg7)
    }
    if (profileimg8) {
        pic.push(profileimg8)
    }
    if (profileimg9) {
        pic.push(profileimg9)
    }


const alldata = {
       
      
    vehicle_number:vnum,
    vehicle_brand:vbrand,
    vehicle_model:vmodel,
    mileage:mill,
    company_name:com,
    driver_name:driver,
    contact_number:con,
    towing_date:to,
    time_in:time,
    tow_chit_no:chit,
    description: des,
    req_attn: req,
    done: done,
    remarks: rem,
    date_out: date,
    time_out: From,
    completed_by: clickval.toString(),
    inspected_by: value1,
    mileage_in: From1,
    mileage_out: From2,
    images: pic.toString(),
    image_remark: remark.toString(),
    is_draft:is_draft0


}


const pass =async()=>{
    const result1 = await AsyncStorage.getItem('QasLogin')
    const screenData2 = JSON.parse(result1)
            // //console.log('num->>>',click.id)
            //    alert('function call')
               fetch(global.url + 'deletefromdraft.php', {
                    method: 'POST',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id:screenData2.id
                     
                    }),
                })
                    .then((res) => res.json())
                    .then(async (json) => {
                        if (json.ResponseCode == '1') {
                           //console.log('json--->>>', json)
                           navigation.navigate('Description2', alldata)
                            // navigation.navigate('Home')
                        }
                        else {
                            alert(json.ResponseMsg)
                        }
        
                    })
                    .catch((err) => {
                        //console.log(err);
                        //console.log(err)
                    });
                
}

    
    // const pass=()=>{
    //     deletedraf()
      
    //     alert('pass call')
      

    // }

    let Repairarray = [
      
        { "id": 0, 'name': vnum },
        // {"id":1,'name':vbrand},
        // {"id":2,'name':mill},
        // {"id":3,'name':com},
        // {"id":4,'name':driver},
        // {"id":5,'name':con},
        // {"id":6,'name':to},
        // {"id":7,'name':time},
        // {"id":8,'name':chit},
        // {"id":9,'name':des},
        // {"id":10,'name':req},
        // {"id":11,'name':done},
        // {"id":12,'name':rem},
        // {"id":13,'name':date},
        // {"id":14,'name':From},
        // {"id":15,'name': clickval.toString()},
        // {"id":16,'name':value1},
        // {"id":17,'name': From1},
        // {"id":18,'name': From2},
        // {"id":19,'name':  pic.toString()},
        // {"id":20,'name':  remark.toString()},
        // {"id":21,'name':is_draft1},
        // { "id": 1, 'name': global.draffid },
      

    ];

    const draff=async()=>{

        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData2 = JSON.parse(result1)
        global.id=screenData2.id
    // if (remarkvalidation==0) {
        // //console.log('***************apifinal==>>>', final)
        setLoading(true)

        fetch(global.url + 'addreport.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData2.id,
                vehicle_number: vnum,
                vehicle_brand: vbrand,
                mileage: mill,
                company_name: com,
                driver_name: driver,
                contact_number: con,
                towing_date: to,
                time_in: time,
                tow_chit_no: chit,
                description: des.toString(),
                req_attn: req.toString(),
                // done: done.toString(),
                // remarks: Remark.toString(),
                date_out: date,
                time_out: From,
                completed_by: clickval.toString(),
                inspected_by: '',
                mileage_in: From1,
                mileage_out: From2,
                images: pic.toString(),
                image_remark: remark.toString(),
                is_draft:is_draft1
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                 
                    
                    //console.log('json--->>>', json)
                    //console.log(vnum)
                   //console.log(is_draft1)
                   
                    navigation.navigate('Draff', JSON.stringify(Repairarray))

                    setLoading(false)

                }
                else {
                    alert(json.ResponseMsg)
                }

            })
            .catch((err) => {
                //console.log(err);
                //console.log(err)
            });

        //   }
    
        
    }

   
    
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />

                        {/* <Image style={styles.ficon} source={require('../../../image/back.png')} /> */}
                    </TouchableOpacity>
                    <Text style={{ fontSize: 22, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, borderWidth: 0 }}>Van Inspection Report</Text>

                </View>
                <View style={{ marginTop: -10 }}>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Vehicle Number</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>{vnum}</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Brand</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>{vbrand}</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Model</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>{vmodel}</Text>
                        </View>

                    </View>
                </View>
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                {/* **************************************************************************************************************************************** */}
                {width < '700' ?
                    <View style={{ borderWidth: 0 }}>
                        <TouchableOpacity onPress={showDatePicker}>
                            <View style={{ flexDirection: 'row' }}>

                                <View style={{ width: '10%', marginRight: 0, marginLeft: 22, borderBottomWidth: 2, borderLeftWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopLeftRadius: 10, borderBottomLeftRadius: 10 }}>
                                    <TouchableOpacity >
                                        <Image style={styles.ficon2} source={require('../../../image/datenew.png')} />
                                    </TouchableOpacity>
                                </View>
                                <View style={{ width: '40%', borderBottomWidth: 2, borderRightWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopRightRadius: 10, borderBottomRightRadius: 10 }}>
                                    {datePicker
                                        ?
                                        <DateTimePicker

                                            value={date}

                                            mode={'date'}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={true}
                                            onChange={onDateSelected}
                                        />
                                        :
                                        // <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{valueformatedate(date.toDateString())}</Text>
                                        null
                                    }
                                    {date &&
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{m4 == 1 ? valueformatedate(date.toDateString()) : placeholderText4}</Text>
                                    }
                                </View>
                            </View>
                        </TouchableOpacity>
                        <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity onPress={showTimepicker}>
                                <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                            </TouchableOpacity>
                        </View>
                        {show ?
                            <DateTimePicker
                                testID="dateTimePicker"
                                value={From}
                                mode={'time'}
                                is24Hour={true}
                                display="default"
                                onChange={onChange}
                            /> :
                            // <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '20%', left: '18%', marginTop: -30 }}>{To.toLocaleTimeString()}</Text>
                            null

                        }
                        {From &&
                            <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '20%', left: '18%', marginTop: -33 }}>{m2 == 1 ? To.toLocaleTimeString() : placeholderText2}</Text>
                        }
                        <View style={{ borderWidth: 0, width: '97%', marginTop: 0, marginLeft: 6 }}>

                            <TouchableOpacity>
                                <Image style={styles.ficon3} source={require('../../../image/per.png')} />
                            </TouchableOpacity>




                            <TouchableOpacity style={styles.dropdown} onPress={model}>
                                <ScrollView style={{ borderWidth: 0, width: '80%', marginLeft: 50, position: 'absolute', top: 5 }} horizontal={true}>
                                    <View>
                                        {clickval.toString() ?
                                            <Text style={{ borderWidth: 0, marginLeft: 2, fontSize: 16, paddingTop: 2 }}>{clickval.toString()}</Text>

                                            :
                                            <Text style={{ borderWidth: 0, marginLeft: 2, fontSize: 16, paddingTop: 2, color: 'black' }}>Select mechanic</Text>
                                        }
                                    </View>
                                </ScrollView>
                            </TouchableOpacity>

                            <Modal isVisible={isModalVisible}>
                                <View style={{ justifyContent: 'center', backgroundColor: '#fff', width: '75%', height: 300, marginLeft: '15%' }}>

                                    <View style={{ height: 30, margin: 5, marginLeft: -5 }}>
                                        {category ?
                                            <View>
                                                {category.map((click, index) => (

                                                    <View style={{ paddingBottom: 15, flexDirection: 'row', marginLeft: 20 }}>
                                                        <View>
                                                            <PureRoundedCheckbox
                                                                key={click.label}

                                                                borderColor={'#ffff'}
                                                                backgroundColor={"#ffff"}
                                                                iconColor={'white'}
                                                                text={'✔'}
                                                                innerStyle={{ height: 25, width: 25 }}
                                                                outerStyle={{ height: 25, width: 25 }}
                                                                onPress={(checked) => box1(click.label, checked)}
                                                                checkedColor={'#49c2c6'}
                                                            />
                                                        </View>
                                                        <View>
                                                            <Text style={{ marginHorizontal: 20 }}>{click.label}</Text>
                                                        </View>
                                                    </View>

                                                ))}
                                            </View>
                                            : null}
                                    </View>
                                    <TouchableOpacity style={{ borderWidth: 0, flex: 0, flexDirection: 'row', justifyContent: 'flex-end', marginTop: '70%' }} onPress={okk}>
                                        <View>
                                            <Text style={{ fontSize: 20, paddingRight: 15, color: '#3c6899' }}>ok</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </Modal>

                        </View>


                    </View>
://device width condition 

                    <View style={{ borderWidth: 0, flexDirection: 'row', width: '100%' }}>
                       

                        <View style={{ width: '7%', marginRight: 0, marginLeft: 22, borderBottomWidth: 2, borderLeftWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopLeftRadius: 10, borderBottomLeftRadius: 10, marginTop: 10 }}>
                            <TouchableOpacity onPress={showDatePicker}>
                                <Image style={styles.ficon2} source={require('../../../image/datenew.png')} />
                            </TouchableOpacity>
                        </View>
                        <View style={{ width: '20%', borderWidth: 0, borderBottomWidth: 2, borderRightWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopRightRadius: 10, borderBottomRightRadius: 10, marginTop: 10 }}>
                            {datePicker
                                ?
                                <DateTimePicker

                                    value={date}

                                    mode={'date'}
                                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                    is24Hour={true}
                                    onChange={onDateSelected}
                                />
                                :
                                
                                null
                            }
                            {date &&
                                <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{m4 == 1 ? valueformatedate(date.toDateString()) : placeholderText4}</Text>
                            }
                        </View>
                        {/* </View> */}
                        <View style={{ width: '27%', borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity onPress={showTimepicker}>
                                <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                            </TouchableOpacity>
                        </View>
                        {show ?
                            <DateTimePicker
                                testID="dateTimePicker"
                                value={From}
                                mode={'time'}
                                is24Hour={true}
                                display="default"
                                onChange={onChange}
                            /> :
                            
                            null
                        }
                        {From &&
                            <Text style={{ color: 'black', fontSize: 15, width: '20%', borderWidth: 0, width: '10%', marginTop: 9, paddingTop: 15, position: 'absolute', left: '43%' }}>{m2 == 1 ? To.toLocaleTimeString() : placeholderText2}</Text>
                        }
                        <View style={{ borderWidth: 0, width: '97%', marginTop: 0, marginLeft: 6 }}>

                            <TouchableOpacity>
                                <Image style={styles.ficoncolum} source={require('../../../image/per.png')} />
                            </TouchableOpacity>




                            <TouchableOpacity style={styles.dropdown2} onPress={model}>
                                <ScrollView style={{ borderWidth: 0, width: '80%', marginLeft: 50, position: 'absolute', top: 5 }} horizontal={true}>
                                    <View>
                                        {clickval.toString() ?
                                            <Text style={{ borderWidth: 0, marginLeft: 2, fontSize: 16, paddingTop: 5 }}>{clickval.toString()}</Text>

                                            :
                                            <Text style={{ borderWidth: 0, marginLeft: 2, fontSize: 16, paddingTop: 5, color: 'black' }}>Select mechanic</Text>
                                        }
                                    </View>
                                </ScrollView>
                            </TouchableOpacity>
                            <Modal isVisible={isModalVisible}>
                                <View style={{ justifyContent: 'center', backgroundColor: '#fff', width: '75%', height: 300, marginLeft: '15%' }}>

                                    <View style={{ height: 30, margin: 5, marginLeft: -5 }}>
                                        {category ?
                                            <View>
                                                {category.map((click, index) => (

                                                    <View style={{ paddingBottom: 15, flexDirection: 'row', marginLeft: 20, marginTop: 30 }}>
                                                        <View>
                                                            <PureRoundedCheckbox
                                                                key={click.label}
                                                                // checked={checkedIds.includes(click.label)}
                                                                borderColor={'#ffff'}
                                                                backgroundColor={"#ffff"}
                                                                iconColor={'white'}
                                                                text={'✔'}
                                                                innerStyle={{ height: 25, width: 25 }}
                                                                outerStyle={{ height: 25, width: 25 }}
                                                                onPress={(checked) => box1(click.label, checked)}
                                                                checkedColor={'#49c2c6'}
                                                            />
                                                        </View>
                                                        <View>
                                                            <Text style={{ marginHorizontal: 20 }}>{click.label}</Text>
                                                        </View>
                                                    </View>

                                                ))}
                                            </View>
                                            : null}
                                    </View>
                                    <TouchableOpacity style={{ borderWidth: 0, flex: 0, flexDirection: 'row', justifyContent: 'flex-end', marginTop: '40%' }} onPress={okk}>
                                        <View>
                                            <Text style={{ fontSize: 20, paddingRight: 15, color: '#3c6899' }}>ok</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </Modal>
                        </View>
                    </View>

                }


                {/* ******************************************************************************************************/}

                {width < '700' ?
                    <View style={{ borderWidth: 0 }}>
                        <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity>
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom1(value)} value={From1} placeholder="Mileage In" fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 20, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity>
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom2(value)} value={From2} placeholder="Mileage out" fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>


                            </TouchableOpacity>
                        </View>


                    </View>


                    ://device width condition 

                    <View style={{ borderWidth: 0, flexDirection: 'row', width: '100%' }}>


                        <View style={{ width: '7%', marginRight: 0, marginLeft: 22, borderBottomWidth: 2, borderLeftWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopLeftRadius: 10, borderBottomLeftRadius: 10, marginTop: 10 }}>
                            <TouchableOpacity >
                                <Image style={styles.ficon} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom1(value)} value={From1} placeholder="Mileage In" fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={{ width: '20%', borderWidth: 0, borderBottomWidth: 2, borderRightWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopRightRadius: 10, borderBottomRightRadius: 10, marginTop: 10 }}>

                        </View>

                        <View style={{ width: '27%', borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity >
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom2(value)} value={From2} placeholder="Mileage out" fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>
                            </TouchableOpacity>
                        </View>


                    </View>

                }
                {/* *************************************************************************************** */}

                <View style={{ borderWidth: 0, marginTop: 20 }}>
                    <Text style={{ fontSize: 21, paddingLeft: '4%', color: '#1d334c', fontWeight: 'bold' }}>
                        Upload Image
                    </Text>
                </View>
                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 1, flexDirection: 'row', marginTop: 10, marginLeft: 10 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('1')}>
                            {profileimg1 ?

                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg1}` }} />
                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg1}` }} />

                            }
                        </TouchableOpacity>
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('2')}>
                            {profileimg2 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg2}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg2}` }} />

                            }
                        </TouchableOpacity>
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} placeholder="Remarks" style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('3')}>
                            {profileimg3 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg3}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg3}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>
                </View>
                {/* ************************************************************************************* */}

                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 1, flexDirection: 'row', marginTop: -10, marginLeft: 10 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('4')}>
                            {profileimg4 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg4}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg4}` }} />
                            }
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>

                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('5')}>
                            {profileimg5 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg5}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg5}` }} />
                            }
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('6')}>
                            {profileimg6 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg6}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg6}` }} />
                            }
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>

                    </View>
                </View>
                {/* ************************************************************************************** */}

                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 1, flexDirection: 'row', marginTop: -10, marginLeft: 10 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('7')}>
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                            {profileimg7 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg7}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg7}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('8')}>
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                            {profileimg8 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg8}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg8}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('9')}>
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                            {profileimg9 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg9}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg9}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>
                </View>
              
                <View style={{borderWidth:0,bottom:10,marginLeft:0,flex:1,flexDirection:'row',justifyContent:'center'}}>
                 <TouchableOpacity style={styles.btn} onPress={draff} >
                    <Text style={styles.btninner}>
                        Save Draff
                    </Text>
                </TouchableOpacity>
                <View style={{width:15}}></View>
                <TouchableOpacity style={styles.btn} onPress={pass} >
                    <Text style={styles.btninner}>
                        Submit
                    </Text>
                </TouchableOpacity>
                </View>
               
            </ScrollView>
        </View>

    )

}
export default Ins;