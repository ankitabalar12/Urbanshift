import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
// borderWidth:5,
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    ficon3:{
        width:35,
        height:35,
        margin:9,
        position:'absolute',
        top:20,
        left:10
      },
      dropdown: {
        // height: 50,
        borderColor: '#AFB0B6',
        // borderWidth: 0.5,
        borderRadius: 10,
        paddingHorizontal: 8,
        borderWidth:2,
        // borderBottomWidth:1,
        width:'95%',
        // alignSelf:'center',
        borderStyle: 'solid',
        paddingLeft:'2%',
        marginTop:20,
        marginLeft:13,
        height:50
        
      },
      placeholderStyle: {
        fontSize: 18,
        color: '#AFB0B6',
        fontFamily:'Poppins-bold',
        marginLeft:36
        // borderWidth:1
      },
      selectedTextStyle: {
        fontSize: 17,
        color:'black',
        fontFamily:'Poppins-bold',
        marginLeft:36

        // borderWidth:1
      },
      btn:{
        height:50,borderRadius:3,backgroundColor:'#346696',width:'91%',margin:'5%'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:19,fontWeight:'bold',paddingTop:12
    },
    spinner: {
      flex: 1,
      justifyContent: 'center',
      backgroundColor:'rgba(24, 24, 24, 0.075)',
      position:'absolute',
      top:0,
      zIndex:9999,
      height:'100%',
      width:'100%',
      // borderWidth:1
     
    },
    validate:{
      color:'#cc1a1a',
      textAlign:'left',
      alignContent:'flex-start',
      marginLeft:20
  },
   
})
