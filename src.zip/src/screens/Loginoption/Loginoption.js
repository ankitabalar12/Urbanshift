import React, { useState } from "react";
import {
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  StatusBar
} from "react-native";

import { styles } from "./styles";
import FastImage from 'react-native-fast-image';

const Loginoption = ({ navigation }) => {
   

    const userRole =(type)=>{
        navigation.navigate('Login',type)
    
       }

    return(
        <ScrollView style={{ backgroundColor: "#fafafd" }}>
        <StatusBar backgroundColor="#fafafd" barStyle="dark-content" />
    <View style={styles.container}>
     
        <View style={styles.img}>
           <FastImage resizeMode='stretch' style={{flex:1}} source={require('../../../image/first.jpeg')} />
        </View>
        {/* <View style={{borderWidth:0,marginTop:60}}> */}
        <TouchableOpacity
      
        //  onPress={() => navigation.navigate('Login',1)}
        onPress={()=>navigation.navigate('Login',1) }
        >
          <View style={styles.btnclass}>
            <Text
              style={{
                color:"#ffffff",
               
                fontWeight: "bold",
                fontSize: 18,
                fontFamily: "Poppins-SemiBold"
              }}
            >
              Customer
            </Text>
          </View>
          </TouchableOpacity>
          <TouchableOpacity  
         
          onPress={() => navigation.navigate('Login',2)}
          >
          <View style={styles.btnclass2}>
            <Text
              style={{
                color:"#ffffff",
                fontWeight: "bold",
                fontSize: 18,
                fontFamily: "Poppins-SemiBold"
              }}
            >
              Mechanic 
            </Text>
          </View>
        </TouchableOpacity>
        </View>
        <View style={{ height: 50 }}></View>
     
    {/* </View> */}
    </ScrollView>
    )

}
export default Loginoption;