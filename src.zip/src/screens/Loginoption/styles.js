import { Platform, StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    marginHorizontal: 16,
    marginTop: Platform.OS === "ios" ? 35 : 0,
    borderWidth: 0,
    // padding: "2%"
    backgroundColor:'#fafafd',
    
    
  },
  imagelogo: {
    width: "100%"
  },
  contentview: {
    width: "100%",
    padding: 30
    // borderWidth: 1
  },
  heading: {
    color: "#000000",
    fontSize: 25,
    // fontStyle:'normal',
    fontFamily: "Poppins-SemiBold",
    // borderWidth: 1,
    width: "100%",
    paddingLeft: "20%"
  },
  contenttxt: {
    color: "#000000",
    fontSize: 18,
    fontFamily: "Poppins-Regular",
    // borderWidth:1,
    // padding:'3%',
  paddingLeft:'14%'
  },
  btnclass: {
    width: "80%",
    
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    backgroundColor: "#346696",
    borderRadius: 8,
   
    height: 40,
   
    margin: "3%",
  
  },
  btnclass2: {
    width: "80%",
   
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    backgroundColor: "#346696",
    borderRadius: 8,
  height: 40,
   
    margin: "3%",
    // borderWidth: 2,
    borderColor: "#346696"
  },
  img:{
    height:390,width:'100%',borderWidth:0,alignSelf:'center',marginTop:50,
  }
});