import React, { useState ,useEffect} from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import { styles } from './styles';
import { Dropdown } from "react-native-element-dropdown";
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';

export default function Support({ navigation }) {
    const [value, setValue] = useState('');
    const [isFocus, setIsFocus] = useState(false);
    const [submitted, setSubmitted] = useState(false)
    const [mess, setMess] = useState('')
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
  useEffect(() => {
        async function fetchData() {
            const typelang = await AsyncStorage.getItem('type');
            selectlang(typelang)
        }
        fetchData();
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    
    const selectlang = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
       

    }
    const submit = async() => {
        setSubmitted(true)
        console.log('value==', value, 'mess->', mess)
        if (mess !== ''  && value !== '') {
       
            const result = await AsyncStorage.getItem('QasLogin')
            const screenData = JSON.parse(result)
            fetch(global.url+'support.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id:screenData.id,
                    message: mess,
                    type:value
                }),
            })
                .then((res) => res.json())
                .then((json) => {
                    if (json.ResponseCode == '1') {
                        navigation.navigate('Conformation')
                      
                    } else {
                        alert(json.ResponseMsg)
                    }
                })
                .catch((err) => {
                    console.log(err);
                    console.log(err)
                });
        }
    }
    const data = [
        { label: 'General Enquiry', value: 'General Enquiry' },
        { label: 'Bug', value: 'Bug' },
        { label: 'Message', value: 'Message' },
      ]
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <View style={{ height: 15 }}></View>
                    <Text style={{ fontSize: 25, color: 'black' }}>{t('Support')}</Text>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ textAlign: 'left', color: '#8a97a4', fontSize: 18 }}>{t('Need help? Write in to us')}</Text>
                    <View style={{ height: 20 }}></View>
                    <Text style={{ color: 'black', fontSize: 16, marginBottom: 12 }}>{t('Type of Support')}</Text>
                    <View style={styles.showinput}>
                        <Image style={styles.ficon} source={require('../../../image/mess.png')} />
                        <View style={{ width: '80%', marginHorizontal: 15, fontSize: 18 }}>
                            <Dropdown
                                style={[styles.dropdown]}
                                placeholderStyle={styles.placeholderStyle}
                                selectedTextStyle={styles.selectedTextStyle}
                                iconStyle={styles.iconStyle}
                                data={data}
                                maxHeight={300}
                                labelField="label"
                                valueField="value"
                                placeholder={!isFocus ? 'General Enquiry' : '...'}
                                value={value}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => setIsFocus(false)}
                                onChange={(item) => {
                                    setValue(item.value);
                                    setIsFocus(false);
                                }}
                            />
                        </View>
                    </View>
                    {value === '' && submitted ? <Text style={styles.validate}>{t('Please Select any Enquiry')}</Text> : null}
                    <View style={{ height: 10 }}></View>
                    <Text style={{ color: 'black', fontSize: 16, marginBottom: 12 }}>{t('Message')}</Text>
                    <View style={{ borderWidth: 1, borderRadius: 10, margin: 7 }}>
                        <TextInput
                            multiline={true}
                            numberOfLines={5}
                            keyboardType='default'
                            placeholder="Enter here"
                            onChangeText={(value) => setMess(value)} value={mess}
                            style={{ height: 120, textAlignVertical: 'top', borderRadius: 10, margin: 10 }} />
                    </View>
                    {mess === '' && submitted ? <Text style={styles.validate}>{t('Please Enter Message')}</Text> : null}
                    <View style={{ height: 20 }}></View>
                    <TouchableOpacity style={styles.btn} onPress={submit}>
                        <Text style={styles.btninner}>
                           {t('Submit')} 
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};