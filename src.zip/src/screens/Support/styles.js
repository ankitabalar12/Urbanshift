import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    showinput: {
        flexDirection: 'row',
        marginBottom: 10,
        borderColor: 'black',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    showmess:{
        borderColor: 'black',
        borderWidth: 1,
        width: '100%',
        height:120,
        borderRadius:10,
    },
    textInput: {
        color: 'black',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    ficon:{
        width:25,
        height:22,
        margin:10,
        
    },
    selectedTextStyle:{
        color:'black',
        fontSize:15,
      
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    validate:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start'
    }
})