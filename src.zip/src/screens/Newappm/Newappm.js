import React, { useState, useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image, StatusBar, Button,SafeAreaView ,Alert} from 'react-native';
import { styles } from './styles';
import { Dropdown } from "react-native-element-dropdown";
import Ionicons from 'react-native-vector-icons/Ionicons';
import DateTimePicker from '@react-native-community/datetimepicker';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import CalendarPicker from 'react-native-calendar-picker';
import moment from 'moment';



export default function Newappm({ navigation }) {
    const [value, setValue] = useState(null);
    const [timer, settimer] = useState('')
  
    const [time1, setTime1] = useState(false);
    const [time2, setTime2] = useState(false);
    const [time3, setTime3] = useState(false);
    const [time4, setTime4] = useState(false);
    const [time5, setTime5] = useState(false);
    const [time6, setTime6] = useState(false);
    const [select, setSelect] = useState('');
    const [di, setdi] = useState('');
    const [apidate, setapidate] = useState('');
    const [name, setname] = useState('');
    const [mobile, setmobile] = useState('');

    const [isFocus, setIsFocus] = useState(false);
    const [isregister, setIsRegister] = useState('1')

    const [datePicker, setDatePicker] = useState(false);
    const [date, setDate] = useState(new Date());
    const [mess, setMess] = useState()
    const [submitted, setsubmitted] = useState(false)
    const { t, i18n } = useTranslation();
    const [dis,setdis]=useState([]);
    const [currentLanguage, setLanguage] = useState('');
    const [selectedStartDate, setSelectedStartDate] = useState('');
    const [weekdays, setWeekdays] = useState([ 'Mon', 
    'Tue', 
    'Wed', 
    'Thur', 
    'Fri', 
    'Sat', 
    'Sun']);
    const [selectsat,setSelectsat]=useState('');
    const [holi,setholi]=useState('');
    const changetime1 = () => {

        setTime1(true)
        setTime2(false)
        setTime3(false)
        setTime4(false)
        setTime5(false)
       
        const time = '9am-10:30am'
        setSelect(time);
    }
    const changetime2 = () => {
        setTime1(false)
        setTime2(true)
        setTime3(false)
        setTime4(false)
        setTime5(false)
       
        const time1 = '10:30am-12pm'
        setSelect(time1);
    }
    const changetime3 = () => {
        setTime1(false)
        setTime2(false)
        setTime3(true)
        setTime4(false)
        setTime5(false)
       
        const time2 = '1pm-2:30pm'

        setSelect(time2)

    }
    const changetime4 = () => {

        setTime1(false)
        setTime2(false)
        setTime3(false)
        setTime4(true)
        setTime5(false)
       
        const time3 = '2:30pm-4pm'

        setSelect(time3);
    }
    const changetime5 = () => {
        setTime1(false)
        setTime2(false)
        setTime3(false)
        setTime4(false)
        setTime5(true)
        
        const time4 = '4pm-6pm'

        setSelect(time4);
    }
    

    useEffect(() => {
        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            //console.log('type== => ', typee);
            selectlan(typee)
            dis.push('10212023','20312023','12312023','22412023','50742023','62242023','10152023','50262023','42962023','30982023','113112023','125122023')
         
            //console.log(dis)
        }
        fetchData();
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
      

    }
	

    
   
    const onDateSelected = (date) => {
        setholi(0)
        //console.log('***********date',date)
        //console.log(di,'di++++++++++')
        const res = date.replace(/-/g,'')
        const res2 =res.replace(/ /g,'')
      for (var i=0;i<dis.length;i++){
            //console.log('dis[i]---->>>>',dis[i])
            //console.log(i)
            // setdisable(dis[i])
            //console.log('dis[i]*********',dis[i])
            //console.log('res++++++++++',res2)
            if(res2==dis[i]){
                Alert.alert('','Sorry, we are not opne on Sundays and Public Holidays')
                setDatePicker(true)
                setholi(1)
                //console.log('holi==>>',holi)
               
               
            }else{
                setDatePicker(false);
                // const string =date
          
                setapidate(apidate)
            }
         
        }
      const string =date
      let firstChar = string.charAt(1); 
        //console.log('string-->>>',firstChar)
      if(firstChar=='7'){
           Alert.alert('','Sorry, we are not open on Sundays and Public Holidays')
            setDatePicker(true);
          }else{
            setDatePicker(false);
        }
        setSelectsat(firstChar)
      
        //console.log('apidate*******',apidate)
        if(firstChar=='7' || holi==1){
                    //console.log('condition true')
                    setapidate('')
                    //console.log('if****===>>>',apidate)
        }else{
            let newStr = string.substr(2, string.length - 1); 
            //console.log(newStr)
            const apidate =newStr.replace(/ /g,'')
            setSelectedStartDate(apidate);
            //console.log('else****===>>>',apidate)
            setapidate(apidate)
        }
};



     const showDatePicker = () => {
        setDatePicker(true);
    };
    const register = () => {
        setIsRegister('1')
    }

    const data = [
        { label: 'General Servicings', value: 'General Servicings' },
        { label: 'Inspection', value: 'Inspection' },
        { label: 'Others', value: 'Others' },
    ]

    const conform = async () => {

        const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)
        //console.log('servic===', value, 'date====',apidate, 'mess=====', mess, 'time=====', select)
       
        setsubmitted(true)
        if (value !== null && mess !== '' && apidate !== '' && select !== '' && name!=='' && mobile!=='' ) {

            fetch(global.url + 'addappointment.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: screenData.id,
                    car_id: screenData.id,
                    service_type: value,
                    adate: apidate,
                    atime: select,
                    message: mess,
                    name:name,
                    mobile_number:mobile

                }),
            })
                .then((res) => res.json())
                .then(async (json) => {
                    //console.log('Response =>', json)
                    if (json.ResponseCode == '1') {
                        //console.log(json)
                        
                        // Alert.alert('',json.ResponseMsg)
                        navigation.navigate('Conformation')
                    }
                    else {
                        Alert.alert('',json.ResponseMsg)
                    }
                })
                .catch((err) => {
                    //console.log(err);
                    //console.log(err)
                });
             }
    }
 return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 20 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ marginTop: 10, fontSize: 25, color: 'black' }}>
                        {t('New Appointments')}
                    </Text>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ fontSize: 17 }}>{t('Create new servicing appointment.')}</Text>
                    <View style={{ height: 10 }}></View>
                    <View style={isregister == '0' ? styles.showinput : styles.showinput1}>
                        {isregister == '0' ?
                            <Image style={styles.ficon} source={require('../../../image/type.png')} />
                            :
                            <Image style={styles.ficon} source={require('../../../image/type1.png')} />
                        }
                        <View style={{ width: '80%', marginHorizontal: 15, letterSpacing: 1.5, fontSize: 18 }}>
                            <Dropdown
                                style={[styles.dropdown]}
                                placeholderStyle={styles.placeholderStyle}
                                selectedTextStyle={styles.selectedTextStyle}
                                iconStyle={styles.iconStyle}
                                data={data}
                                maxHeight={300}
                                labelField="label"
                                valueField="value"
                                placeholder={!isFocus ? 'Type of Servicing' : '...'}
                                value={value}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => setIsFocus(false)}
                                onChange={(item) => {
                                    setValue(item.value);
                                    setIsFocus(false);
                                }}
                            />
                        </View>
                    </View>
                    {value === null && submitted ? <Text style={styles.validate}>{t('Please Select Servicing')}</Text> : null}
                    <View style={{ height: 10 }}></View>

                    <View style={{ borderWidth: 1,  padding: '0%', borderColor: '#000000', borderRadius: 10,  }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 5 }} source={require('../../../image/call.png')} />
                                <TextInput onChangeText={(value) => setname(value)} value={name} placeholder={t("Name")} fontSize={15} marginTop={2} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>

                            </View>

                        </View>
                    {name === '' && submitted ? <Text style={styles.validate}>{t('Please Enter Name')}</Text> : null}


                    <View style={{ height: 15 }}></View>

                    <View style={{ borderWidth: 1, padding: '0%', borderColor: '#000000', borderRadius: 10, }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 5 }} source={require('../../../image/call.png')} />
                                <TextInput onChangeText={(value) => setmobile(value)} value={mobile} placeholder={t("Mobile Number")} fontSize={15} marginTop={2} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>

                            </View>
                        </View>
                    {mobile === '' && submitted ? <Text style={styles.validate}>{t('Please Enter Mobile Number')}</Text> : null}


                    <View style={{ height: 15 }}></View>

                    <View style={isregister == '0' ? styles.email : styles.email1}>
                        <View style={{ width: '20%' }}>

                            {isregister == '0' ?
                                <Image style={styles.ficon} source={require('../../../image/emailnew.png')} />
                                :
                                <Ionicons name="mail-outline" size={25} style={{ margin: 10 }} />
                            }
                        </View>
                        <View style={{ width: '80%' }}>
                            <TextInput
                                multiline={true}
                                numberOfLines={5}
                                keyboardType='default'
                                placeholder="Enter here"
                                onChangeText={(value) => setMess(value)} value={mess}
                                style={{ height: 120, textAlignVertical: 'top', borderRadius: 10 }} />
                        </View>
                    </View>
                    {mess === undefined && submitted ? <Text style={styles.validate}>{t('Please Enter Message')}</Text> : null}
                    <View style={{ height: 10 }}></View>
                    <Text style={{ fontSize: 18, color: 'gray' }}>{t('Select your date & time(DD-M-YYYY)')}</Text>
                    <View style={{ height: 10 }}></View>
                   
                    <TouchableOpacity onPress={showDatePicker}>
                    <View style={styles.date1}>
                       
                                <Image style={styles.ficon} source={require('../../../image/datenew1.png')} />
                                {selectsat=='7' || holi=='1'?
                                <Text style={{alignSelf:'center',fontSize:16}}>null</Text>
                             

                                :
                                <Text style={{alignSelf:'center',fontSize:16}}>{selectedStartDate.toString()}</Text>
                                }
                       </View>
                    </TouchableOpacity>

             <SafeAreaView>       
      <View style={styles.container}>
       
        {datePicker?
        <CalendarPicker
          startFromMonday={true}
        //   allowRangeSelection={true}
          minDate={new Date(2018, 1, 1)}
          maxDate={new Date(2050, 6, 3)}
          weekdays={weekdays}
        //   disabledDates={disable}//year month date
        
          months={[
            'January',
            'Febraury',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December',
          ]}
          previousTitle="Previous"
          nextTitle="Next"
          todayBackgroundColor="#e6ffe6"
          selectedDayColor="#66ff33"
          selectedDayTextColor="#000000"
        //   scaleFactor={375}
          textStyle={{
            fontFamily: 'Cochin',
            color: '#000000',
          }}
        //   onDateChange={onDateSelected}
          onDateChange={(res) => onDateSelected(moment(res).format(" E DD - M - YYYY"))}
          

        //   disabledDates={weekdays}
        //   value={date}
        />:null}
    
      </View>
      </SafeAreaView>  
    
{
                        isregister == '1' ?
                            <View>
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                    <TouchableOpacity onPress={changetime1} style={time1 ? styles.yesfill : styles.noout}>
                                        <Text style={time1 ? styles.yes : styles.no}>
                                        9am - 10:30am
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime2} style={time2 ? styles.yesfill : styles.noout}>
                                        <Text style={time2 ? styles.yes : styles.no}>
                                           10:30am - 12pm
                                        </Text>
                                    </TouchableOpacity>
                                 
                                </View>
                                <View style={{ height: 10 }}></View>
                                {selectsat != 6?
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                <TouchableOpacity onPress={changetime3} style={time3 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time3 ? styles.yes2 : styles.no2}>

                                            1pm - 2:30pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime4} style={time4 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time4 ? styles.yes2 : styles.no2}>
                                           2:30pm - 4pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime5} style={time5 ? styles.yesfill3 : styles.noout3}>
                                        <Text style={time5 ? styles.yes3: styles.no3}>
                                           4pm -6pm
                                        </Text>
                                    </TouchableOpacity>
                                    
                                </View>
                                :
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                <TouchableOpacity onPress={changetime3} style={time3 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time3 ? styles.yes2 : styles.no2}>

                                            1pm - 3pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime4} style={time4 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time4 ? styles.yes2 : styles.no2}>
                                           3pm - 5pm
                                        </Text>
                                    </TouchableOpacity>
                                  </View>
                                
                                }
                            </View>

                            : null
                    }
                    {select === '' && submitted ? <Text style={styles.validate}>{t('Please Enter time')}</Text> : null}

                    <View style={{ height: 50 }}></View>
                    {
                        isregister == '0' ?
                            <TouchableOpacity style={styles.btn} onPress={register}>
                                <Text style={styles.btninner}>
                                    {t('Register')}
                                </Text>
                            </TouchableOpacity>
                            :
                            <TouchableOpacity style={styles.btn} onPress={conform}>
                                <Text style={styles.btninner}>
                                    {t('Confirm')}
                                </Text>
                            </TouchableOpacity>
                    }
                </View>
            </ScrollView>
        </View>
    );
};