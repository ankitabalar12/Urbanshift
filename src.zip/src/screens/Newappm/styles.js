import { StyleSheet, Platform } from "react-native";


export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    showinput: {
        flexDirection: 'row',
        borderColor:'gray',
        marginBottom: 10,
        borderColor: 'gray',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    showinput1: {
        flexDirection: 'row',
        borderColor:'black',
        marginBottom: 10,
        borderColor: 'black',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    textInput: {
        color: 'gray',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    textInput1: {
        color: 'black',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    ficon:{
        width:25,
        height:25,
        margin:9,
       
    },
    email:{
        borderWidth: 1, height: 150, borderColor: 'gray', borderRadius: 10, width: '100%', flexDirection: 'row'
       
    },
    email1:{
        borderWidth: 1, height: 150, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row'
    },
    date:{
        borderWidth: 1, borderColor: 'gray', borderRadius: 10, width: '100%', flexDirection: 'row',marginLeft:10 
    },
    date1:{
        borderWidth: 1, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row'
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696',
      marginTop:100
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    yes: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill: {
        borderWidth: 1,
        width: '41%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'2%'
    },
    no: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout: {
        borderWidth: 1,
        width: '41%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'2%'
    },
    iconStyle:{
        color:'black'
    },
    validate:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start'
    },
    yes2: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill2: {
        borderWidth: 1,
        width: '35%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'1%'
    },
    no2: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout2: {
        borderWidth: 1,
        width: '35%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'1%'
    },
    container: {
        flex: 1,
        paddingTop: 30,
        // backgroundColor: '#ffffff',
        
        // padding: 16,
        // borderWidth:1
      },
      textStyle: {
        marginTop: 10,
      },
      titleStyle: {
        textAlign: 'center',
        fontSize: 20,
        margin: 20,
      },
      yes3: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill3: {
        borderWidth: 1,
        width: '27%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'1%'
    },
    no3: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout3: {
        borderWidth: 1,
        width: '27%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'1%'
    },
    placeholderStyle:{
        fontSize:16,
        marginTop:5,
        color:'#afb0b6'
    },
    selectedTextStyle:{
        color:'#000000',
        fontSize:16,
        marginTop:5,
    }
})