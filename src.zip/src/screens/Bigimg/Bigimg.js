import React, { useState, useEffect } from "react";
import {
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
  ActivityIndicator
} from "react-native";
import Ionicons from 'react-native-vector-icons/Ionicons';
import FastImage from 'react-native-fast-image';
const Bigimg = ({ navigation, route }) => {
  const [img, setimg] = useState('')
  useEffect(() => {
    async function fetchData() {
      const big = route.params
      console.log('big>>', big)
      global.img = big
      setimg(big)
    }
    fetchData();
  }, [])
  return (
    <View>
      <TouchableOpacity style={{ marginTop: 0, backgroundColor: '#000000' }} onPress={() => navigation.goBack()}>
        <Ionicons name="chevron-back" size={35} style={{ color: '#ffffff', marginLeft: 15 }} />
      </TouchableOpacity>
      <View style={{ backgroundColor: '#000000', width: '100%', height: '95%', justifyContent: 'center' }}>
        <StatusBar backgroundColor='#000000' barStyle="dark-content" />
        <View style={{ height: 210, width: '100%', alignSelf: 'center' }}>
          <FastImage resizeMode='stretch' style={{ flex: 1 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/admin/${img}` }} />
        </View>
      </View>
    </View>
  )
}
export default Bigimg;
