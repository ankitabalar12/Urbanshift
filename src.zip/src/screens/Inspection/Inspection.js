import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    SafeAreaView,
    Dimensions,
    ActivityIndicator,
    Alert
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Dropdown } from "react-native-element-dropdown";
import FastImage from 'react-native-fast-image';
import AsyncStorage from '@react-native-community/async-storage';
import Modal from "react-native-modal";
var ImagePicker = require('react-native-image-picker');
import { PureRoundedCheckbox } from "react-native-rounded-checkbox";
import '../../../i18n';
import { useTranslation } from 'react-i18next';
const Inspection = ({ navigation, route }) => {
    const [date, setDate] = useState(new Date());
    const [datePicker, setDatePicker] = useState(false);
    const [To, setTo] = useState(new Date());
    const [show, setShow] = useState(false);
    const [From1, setFrom1] = useState('');
    const [loading, setLoading] = useState(false);
    const [From2, setFrom2] = useState('');
    const [currentSetting2, setcurrentSetting2] = useState('from');
    const [isFocus, setIsFocus] = useState(false);
    const [value, setValue] = useState('');
    const [isFocus1, setIsFocus1] = useState(false);
    const [value1, setValue1] = useState('');
    const [width, setWidth] = useState('');
    const [m4, setM4] = useState(0);
    const [category, setCategory] = useState('');
    const [category2, setCategory2] = useState('');
    const [vnum, setvnum] = useState('');
    const [vbrand, setvbrand] = useState('');
    const [vmodel, setvmodel] = useState('');
    const [profileimg1, setProfile1] = useState('');
    const [profileimg2, setProfile2] = useState('');
    const [profileimg3, setProfile3] = useState('');
    const [profileimg4, setProfile4] = useState('');
    const [profileimg5, setProfile5] = useState('');
    const [profileimg6, setProfile6] = useState('');
    const [profileimg7, setProfile7] = useState('');
    const [profileimg8, setProfile8] = useState('');
    const [profileimg9, setProfile9] = useState('');
    const [remark, setremark] = useState([]);
    const [isModalVisible, setModalVisible] = useState(false);
    const [clickval, setclickval] = useState([]);
    const [dropDownData, setdropDownData] = useState([]);
    const [checkedCount, setCheckedCount] = useState(0);
    const [checkedCount2, setCheckedCount2] = useState(1);
    const [mill, setmill] = useState('');
    const [com, setcom] = useState('');
    const [driver, setdriver] = useState('');
    const [con, setcon] = useState('');
    const [to, setto] = useState('');
    const [time, settime] = useState('');
    const [chit, setchit] = useState('');
    const [rem, setrem] = useState('');
    const [done, setdone] = useState('');
    const [des, setdes] = useState('');
    const [req, setreq] = useState('');
    const [is_draft1, setisdarff1] = useState(1);
    const [is_draft0, setisdarff0] = useState(0);
    const [pic, sedtpic] = useState([]);
    const [rmark1, setrmark1] = useState('');
    const [rmark2, setrmark2] = useState('');
    const [rmark3, setrmark3] = useState('');
    const [rmark4, setrmark4] = useState('');
    const [rmark5, setrmark5] = useState('');
    const [rmark6, setrmark6] = useState('');
    const [rmark7, setrmark7] = useState('');
    const [rmark8, setrmark8] = useState('');
    const [rmark9, setrmark9] = useState('');
    const [passid, setpassid] = useState('');
    const [mac, setmec] = useState('');
    const [datepass, setdatepass] = useState('');
    const [timepass, settimepass] = useState('');
    const [time1, settime1] = useState('');
    const [mecanic, setmecanic] = useState('');
    const [getDeviceName, setgetDeviceName] = useState([]);
    const { t, i18n } = useTranslation();
    // const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const box1 = (label, checked) => {
        if (checked === true) {
            setCheckedCount(checkedCount);//0 pass
        }
        if (checked == false) {
            setCheckedCount2(checkedCount2);// 1 pass
        }
        if (!clickval.includes(label)) {
          clickval.push(label)
          ////console.log('clickval>>>',clickval)
        const arrayOfNumbers =clickval.toString()
          ////console.log('arrayOfNumbers>>',arrayOfNumbers)
          const replace =arrayOfNumbers.replace(/^./, "")
          setmecanic(replace)
        //  global.newStr = arrayOfNumbers.replace(/^./, "");
          ////console.log('newStr>>>',global.newStr)
        //   clickval.push(global.newStr)
        } else {
            Alert.alert(
                'This Mechanic Already Selected',
                'You Remove This Mechanic?',
                [
                    {
                        text: 'Yes',
                        onPress: () => {
                            var index = clickval.indexOf(label)
                            clickval.splice(index, 1);
                            box1();
                        },

                    },
                    {
                        text: 'No',
                        onPress: () => setModalVisible(!isModalVisible)
                    },
                ]
            );

        }
    }
    useEffect(() => {
        navigation.addListener('focus', async() => {
            setLoading(true)
            const typee = await AsyncStorage.getItem('type');
            ////console.log('type== => ', typee);
            selectlan(typee)
        setWidth(Dimensions.get('screen').width);
        const Repairarray = route.params.Repair
        const screenData = JSON.parse(Repairarray);

        var data = screenData.map(function (item) {
            return {
                key: item.id,
                label: item.name
            };
        });

        if (data[23].label != '') {

            setdes(data[23].label)
            global.desc = data[23].label
        }
        if (data[18].label) {
            setProfile1(data[18].label.split(',')[0])
            setProfile2(data[18].label.split(',')[1])
            setProfile3(data[18].label.split(',')[2])
            setProfile4(data[18].label.split(',')[3])
            setProfile5(data[18].label.split(',')[4])
            setProfile6(data[18].label.split(',')[5])
            setProfile7(data[18].label.split(',')[6])
            setProfile8(data[18].label.split(',')[7])
            setProfile9(data[18].label.split(',')[8])
        }
        settime1(data[22].label)//ins time
        if (data[14].label) {
            setDate(new Date(data[14].label))
        }
        // if(data[0].label){
            setvnum(data[0].label)
        // }
    //    alert(vnum)
        setvbrand(data[1].label)
        setvmodel(data[2].label)
        setmill(data[3].label)
        setcom(data[6].label)
        setdriver(data[7].label)
        setcon(data[8].label)
        setto(data[11].label)
        settime(data[10].label)
        setchit(data[12].label)
        setFrom1(data[16].label)
        setFrom2(data[17].label)
        setrmark1(data[19].label.split(',')[0])
        setrmark2(data[19].label.split(',')[1])
        setrmark3(data[19].label.split(',')[2])
        setrmark4(data[19].label.split(',')[3])
        setrmark5(data[19].label.split(',')[4])
        setrmark6(data[19].label.split(',')[5])
        setrmark7(data[19].label.split(',')[6])
        setrmark8(data[19].label.split(',')[7])
        setrmark9(data[19].label.split(',')[8])
        setpassid(data[21].label)
        console.log('data[20].label>>>',data[20].label)
        // setmec(data[20].label)
        setmecanic(data[20].label)
        // clickval.push(data[20].label)
        if (data[23].label == '') {
        const desc = route.params.des
        // //console.log('desc insepectionb>>>>>>>>>>>>',desc)
        global.desc = desc
        }
        getmac();
        addreport();
        global.draffid = global.id
        setLoading(false)
    })
    }, []);

    const selectlan = async (value) => {
        ////console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
	 const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const model = () => {
        setModalVisible(!isModalVisible);
    }
    const addreport = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData2 = JSON.parse(result1)
        const Repairarray = route.params.Repair
        const screenData = JSON.parse(Repairarray);
        var data = screenData.map(function (item) {
            return {
                key: item.id,
                label: item.name
            };
        });
        setdatepass(data[4].label)
        settimepass(data[5].label)
        //console.log('data[23].label>>',data[23].label)
        // if (data[23].label == '') {
                const desc = route.params.des
                //console.log('desc>>>',desc)
                for(var i = 0;i<desc.length;i++){
                            // //console.log('desc name>>>',desc[i].label)
                            getDeviceName.push(desc[i].label)
                }
                // const descarray = desc.toString();
                const descarray = desc;
                
                setdes(descarray)
        // }
        const Remark = route.params.rem
        const remarkarray = Remark.toString();
        setrem(remarkarray)
        const done = route.params.done
        setdone(done)
        const donekarray = done.toString();
        const req = route.params.requirement
        setreq(req)
        const reqkarray = req.toString();
    }
    const getmac = () => {
        setLoading(true);
        fetch(global.url + 'getmechanics.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: 10
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                    await AsyncStorage.setItem('Qasmac', JSON.stringify(json.upcomming));

                    var count = Object.keys(json.upcomming).length;

                    for (var i = 0; i < count; i++) {
                        dropDownData.push({ value: json.upcomming[i].id, label: json.upcomming[i].full_name }); // Create your array of data
                    }
                    setCategory(dropDownData);
                    setCategory2(dropDownData)
                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }
    const onChange = (event, selectedDate) => {

        setShow(false)
        const currentDate = selectedDate;

        let str = currentDate.toLocaleTimeString();
        str = str.substring(0, str.length - 3);
        settime1(str)
    };
    const showTimepicker = (current) => {
        setShow(true);

    };
    const onDateSelected = (event, value) => {

        setDate(value);
        setDatePicker(false);
    };
    const valueformatedate = (value) => {

        var month = ["January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"];
        var strSplitDate = String(value).split(' ');
        var dates = new Date(strSplitDate[0]);
        var dd = date.getDate();
        var mm = month[date.getMonth()];
        var yyyy = date.getFullYear();
        var conformdate = dd + ' ' + mm + ' ' + yyyy

        global.dateout = conformdate
        return conformdate
    }
    const showDatePicker = () => {
        setM4(1)
        setDatePicker(true);
    };
    const placeholderText2 = 'Time Out'
    const placeholderText4 = 'Date Out'
    function selectimage(imgid) {

        Alert.alert("Alert", "Choose an option", [
            {
                text: 'Back',
                onPress: () => { },
            },
            {
                text: 'Camera',
                onPress: () => openCamera(imgid),
            },
            {
                text: 'Library',
                onPress: () => openLibrary(imgid)
            },
        ]);
    }
    const openCamera = (imgid) => {

        var options = {
            mediaType: 'photo',
            includeBase64: true,
            quality: 1,
            maxHeight: 500,
            maxWidth: 500,
            cameraType: 'back'
        }
        ImagePicker.launchCamera(options, (response) => {
            if(response.didCancel != true){
            let base64Image = response.assets[0].base64;

            setLoading(true)
            fetch(global.url + 'imageupload.php',
                {
                    method: 'post',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        base64: base64Image
                    }),
                })

                .then((res) => res.json())
                .then((json) => {

                    if (json.ResponseCode == '1') {

                        if (imgid == '1') {
                            let userpic1 = json.image_url
                            setProfile1(userpic1)
                        }
                        if (imgid == '2') {
                            let userpic2 = json.image_url
                            setProfile2(userpic2)
                        }
                        if (imgid == '3') {
                            let userpic3 = json.image_url
                            setProfile3(userpic3)
                        }
                        if (imgid == '4') {
                            let userpic4 = json.image_url
                            setProfile4(userpic4)
                        }
                        if (imgid == '5') {
                            let userpic5 = json.image_url
                            setProfile5(userpic5)
                        }
                        if (imgid == '6') {
                            let userpic6 = json.image_url
                            setProfile6(userpic6)
                        }
                        if (imgid == '7') {
                            let userpic7 = json.image_url
                            setProfile7(userpic7)
                        }
                        if (imgid == '8') {
                            let userpic8 = json.image_url
                            setProfile8(userpic8)
                        }
                        if (imgid == '9') {
                            let userpic9 = json.image_url
                            setProfile9(userpic9)
                        }

                        setLoading(false)
                    }
                })
                .catch((err) => {
                    setLoading(false)

                })
            }
        },
        )
    }
    const openLibrary = async (imgid) => {
        var options = {
            mediaType: 'photo',
            includeBase64: true,
            quality: 1,
            maxHeight: 500,
            maxWidth: 500,
        }
        ImagePicker.launchImageLibrary(options, response => {
            if(response.didCancel != true){
            let base64Image = response.assets[0].base64;
            setLoading(true)
            fetch(global.url + 'imageupload.php',
                {
                    method: 'post',
                    headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        base64: base64Image
                    }),
                })
                .then((res) => res.json())
                .then((json) => {
                    if (json.ResponseCode == '1') {
                        if (imgid == '1') {
                            let userpic1 = json.image_url
                            setProfile1(userpic1)
                        }
                        if (imgid == '2') {
                            let userpic2 = json.image_url
                            setProfile2(userpic2)
                        }
                        if (imgid == '3') {
                            let userpic3 = json.image_url
                            setProfile3(userpic3)
                        }
                        if (imgid == '4') {
                            let userpic4 = json.image_url
                            setProfile4(userpic4)
                        }
                        if (imgid == '5') {
                            let userpic5 = json.image_url
                            setProfile5(userpic5)
                        }
                        if (imgid == '6') {
                            let userpic6 = json.image_url
                            setProfile6(userpic6)
                        }
                        if (imgid == '7') {
                            let userpic7 = json.image_url
                            setProfile7(userpic7)
                        }
                        if (imgid == '8') {
                            let userpic8 = json.image_url
                            setProfile8(userpic8)
                        }
                        if (imgid == '9') {
                            let userpic9 = json.image_url
                            setProfile9(userpic9)
                        }
                        setLoading(false)
                    }
                })
                .catch((err) => {
                    setLoading(false)
                })
            }
        })
    };
    const setremarkvalue = (val, index) => {
        remark.push(val);
    }
    const setremarkvalue1 = (val, index1) => {
        setrmark1(val);
    }
    const setremarkvalue2 = (val, index1) => {
        setrmark2(val);
    }
    const setremarkvalue3 = (val, index1) => {
        setrmark3(val);
    }
    const setremarkvalue4 = (val, index1) => {
        setrmark4(val);
    }
    const setremarkvalue5 = (val, index1) => {
        setrmark5(val);
    }
    const setremarkvalue6 = (val, index1) => {
        setrmark6(val);
    }
    const setremarkvalue7 = (val, index1) => {
        setrmark7(val);
    }
    const setremarkvalue8 = (val, index1) => {
        setrmark8(val);
    }
    const setremarkvalue9 = (val, index1) => {
        setrmark9(val);
    }
    const okk = () => {
        setModalVisible(!isModalVisible);
    }
    const nodraff = () => {
        imges();
        const alldata = {
            vehicle_number: vnum,
            vehicle_brand: vbrand,
            vehicle_model: vmodel,
            mileage: mill,
            company_name: com,
            driver_name: driver,
            contact_number: con,
            towing_date: to,
            time_in: time,
            tow_chit_no: chit,
            description: global.desc,
            req_attn: req,
            done: done,
            remarks: rem,
            date_out: global.dateout,
            time_out: time1,
            // completed_by: clickval.toString(),
            completed_by:mecanic,
            inspected_by: value1,
            mileage_in: From1,
            mileage_out: From2,
            images: pic.toString(),
            image_remark: remark.toString(),
            is_draft: is_draft0,
            sdate: datepass,
            stime: timepass
        }
        navigation.navigate('Description2', alldata)
    }
    const pass = async (passid) => {
        imges();
        const alldata = {
            vehicle_number: vnum,
            vehicle_brand: vbrand,
            vehicle_model: vmodel,
            mileage: mill,
            company_name: com,
            driver_name: driver,
            contact_number: con,
            towing_date: to,
            time_in: time,
            tow_chit_no: chit,
            description: global.desc,
            req_attn: req,
            done: done,
            remarks: rem,
            date_out: global.dateout,
            time_out: time1,
            // completed_by: clickval.toString(),
            completed_by: mecanic,
            inspected_by: value1,
            mileage_in: From1,
            mileage_out: From2,
            images: pic.toString(),
            image_remark: remark.toString(),
            is_draft: is_draft0,
            sdate: datepass,
            stime: timepass,
            deletedraftid:passid
        }
        navigation.navigate('Description2', alldata)
                   
    }

    let Repairarray = [

        { "id": 0, 'name': vnum },

    ];
    const imges = () => {
        if (profileimg1) {
            pic.push(profileimg1)
        }
        if (profileimg2) {
            pic.push(profileimg2)
        }
        if (profileimg3) {
            pic.push(profileimg3)
        }
        if (profileimg4) {
            pic.push(profileimg4)
        }
        if (profileimg5) {
            pic.push(profileimg5)
        }
        if (profileimg6) {
            pic.push(profileimg6)
        }
        if (profileimg7) {
            pic.push(profileimg7)
        }
        if (profileimg8) {
            pic.push(profileimg8)
        }
        if (profileimg9) {
            pic.push(profileimg9)
        }
    }
    const draff = async () => {
        imges();
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData2 = JSON.parse(result1)
        global.id = screenData2.id
        setLoading(true)
        fetch(global.url + 'addreport.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData2.id,
                vehicle_number: vnum,
                vehicle_brand: vbrand,
                vehicle_model: vmodel,
                mileage: mill,
                company_name: com,
                driver_name: driver,
                contact_number: con,
                towing_date: time,//secound date
                time_in: to,//secoynd time
                tow_chit_no: chit,
                description: getDeviceName.toString(),
                // description:  global.desc.to,
                req_attn: req.toString(),
                date_out: global.dateout,
                time_out: time1,
                // completed_by: clickval.toString(),
                completed_by: mecanic,
                inspected_by: '',
                mileage_in: From1,
                mileage_out: From2,
                images: pic.toString(),
                image_remark: remark.toString(),
                is_draft: is_draft1,
                sdate: datepass,//this is frist date
                stime: timepass
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                    navigation.navigate('Draff', JSON.stringify(Repairarray))
                    setLoading(false)
                }
                else {
                    alert(json.ResponseMsg)
                }
            })
            .catch((err) => {
            });
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity style={{width:'20%'}} onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />

                        {/* <Image style={styles.ficon} source={require('../../../image/back.png')} /> */}
                    </TouchableOpacity>
                    <Text style={{ fontSize: 22, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, borderWidth: 0 }}>{t('Van Inspection Report')}</Text>

                </View>
                <View style={{ marginTop: -10 }}>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>{t('Vehicle Number')}</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>{vnum}</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>{t('Brand')}</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>{vbrand}</Text>
                        </View>
                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>{t('Model')}</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>{vmodel}</Text>
                        </View>
                    </View>
                </View>
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                {/* **************************************************************************************************************************************** */}
                {width < '700' ?
                    <View style={{ borderWidth: 0 }}>
                        <TouchableOpacity onPress={showDatePicker}>
                            <View style={{ flexDirection: 'row' }}>

                                <View style={{ width: '10%', marginRight: 0, marginLeft: 22, borderBottomWidth: 2, borderLeftWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopLeftRadius: 10, borderBottomLeftRadius: 10 }}>
                                    <TouchableOpacity >
                                        <Image style={styles.ficon2} source={require('../../../image/datenew.png')} />
                                    </TouchableOpacity>
                                </View>
                                <View style={{ width: '40%', borderBottomWidth: 2, borderRightWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopRightRadius: 10, borderBottomRightRadius: 10 }}>
                                    {datePicker
                                        ?
                                        <DateTimePicker

                                            value={date}

                                            mode={'date'}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={true}
                                            onChange={onDateSelected}
                                        />
                                        :
                                        // <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{valueformatedate(date.toDateString())}</Text>
                                        null
                                    }
                                    {date &&
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{valueformatedate(date.toDateString())}</Text>
                                    }
                                </View>
                            </View>
                        </TouchableOpacity>
                        <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity onPress={showTimepicker}>
                                <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                            </TouchableOpacity>
                        </View>
                        {show ?
                            <DateTimePicker
                                testID="dateTimePicker"
                                value={To}
                                mode={'time'}
                                is24Hour={true}
                                display="default"
                                onChange={onChange}
                            /> :
                            // <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '20%', left: '18%', marginTop: -30 }}>{To.toLocaleTimeString()}</Text>
                            null

                        }
                        {time1 ?
                            <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '20%', left: '18%', marginTop: -33 }}>{time1}</Text>
                            :
                            <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '25%', left: '18%', marginTop: -33 }}>{t('Select time')}</Text>

                        }
                        <View style={{ borderWidth: 0, width: '97%', marginTop: 0, marginLeft: 6 }}>
                            <TouchableOpacity>
                                <Image style={styles.ficon3} source={require('../../../image/per.png')} />
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.dropdown} onPress={model}>
                                <ScrollView style={{ borderWidth: 0, width: '80%', marginLeft: 50, position: 'absolute', top: 5 }} horizontal={true}>
                                    <View>
                                        {clickval  !== ''?
                                            <View style={{ borderWidth: 0 }}>
                                                <Text style={{ borderWidth: 0, marginLeft: 0, fontSize: 16, paddingTop: 2, }}>{mecanic}</Text>
                                            </View>
                                            :
                                            <View>
                                            <Text style={{ borderWidth: 0, marginLeft: 2, fontSize: 16, paddingTop: 2, color: 'black' }}>{t('Select mechanic')}</Text>
                                            </View>
                                        }
                                    </View>
                                </ScrollView>
                            </TouchableOpacity>

                            <Modal isVisible={isModalVisible}>
                                <View style={{borderWidth:0, justifyContent: 'center', backgroundColor: '#fff', width: '75%', height: 300, marginLeft: '15%' }}>

                                    <View style={{ height: 30, margin: 5, marginLeft: -5,borderWidth:0 }}>
                                        {category ?
                                            <View>
                                                {category.map((click, index) => (

                                                    <View style={{ paddingBottom: 15, flexDirection: 'row', marginLeft: 20 ,borderWidth:0,marginTop:-5}}>
                                                        <View>
                                                            <PureRoundedCheckbox
                                                                key={click.label}

                                                                borderColor={'#ffff'}
                                                                backgroundColor={"#ffff"}
                                                                iconColor={'white'}
                                                                text={'✔'}
                                                                innerStyle={{ height: 25, width: 25 }}
                                                                outerStyle={{ height: 25, width: 25 }}
                                                                onPress={(checked) => box1(click.label, checked)}
                                                                checkedColor={'#49c2c6'}
                                                            />
                                                        </View>
                                                        <View>
                                                            <Text style={{ marginHorizontal: 20 }}>{click.label}</Text>
                                                        </View>
                                                    </View>

                                                ))}
                                            </View>
                                            : null}
                                    </View>
                                    <TouchableOpacity style={{ borderWidth: 0, flex: 0, flexDirection: 'row', justifyContent: 'flex-end', marginTop: '70%' }} onPress={okk}>
                                        <View>
                                            <Text style={{ fontSize: 20, paddingRight: 15, color: '#3c6899' }}>{t('ok')}</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </Modal>

                        </View>


                    </View>
                    ://device width condition 

                    <View style={{ borderWidth: 0 }}>
                    <TouchableOpacity onPress={showDatePicker}>
                        <View style={{ flexDirection: 'row' }}>

                            <View style={{ width: '10%', marginRight: 0, marginLeft: 22, borderBottomWidth: 2, borderLeftWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopLeftRadius: 10, borderBottomLeftRadius: 10 }}>
                                <TouchableOpacity >
                                    <Image style={styles.ficon2} source={require('../../../image/datenew.png')} />
                                </TouchableOpacity>
                            </View>
                            <View style={{ width: '40%', borderBottomWidth: 2, borderRightWidth: 2, borderTopWidth: 2, borderColor: '#AFB0B6', borderTopRightRadius: 10, borderBottomRightRadius: 10 }}>
                                {datePicker
                                    ?
                                    <DateTimePicker

                                        value={date}

                                        mode={'date'}
                                        display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                        is24Hour={true}
                                        onChange={onDateSelected}
                                    />
                                    :
                                    // <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{valueformatedate(date.toDateString())}</Text>
                                    null
                                }
                                {date &&
                                    <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{valueformatedate(date.toDateString())}</Text>
                                }
                            </View>
                        </View>
                    </TouchableOpacity>
                    <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                        <TouchableOpacity onPress={showTimepicker}>
                            <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                        </TouchableOpacity>
                    </View>
                    {show ?
                        <DateTimePicker
                            testID="dateTimePicker"
                            value={To}
                            mode={'time'}
                            is24Hour={true}
                            display="default"
                            onChange={onChange}
                        /> :
                        // <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '20%', left: '18%', marginTop: -30 }}>{To.toLocaleTimeString()}</Text>
                        null

                    }
                    {time1 ?
                        <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '20%', left: '18%', marginTop: -33 }}>{time1}</Text>
                        :
                        <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '25%', left: '18%', marginTop: -33 }}>{t('Select time')}</Text>

                    }
                    <View style={{ borderWidth: 0, width: '97%', marginTop: 0, marginLeft: 6 }}>

                        <TouchableOpacity>
                            <Image style={styles.ficon3} source={require('../../../image/per.png')} />
                        </TouchableOpacity>




                        <TouchableOpacity style={styles.dropdown} onPress={model}>
                            <ScrollView style={{ borderWidth: 0, width: '80%', marginLeft: 50, position: 'absolute', top: 5 }} horizontal={true}>
                                <View>
                                    {clickval ?
                                        <View style={{ borderWidth: 0 }}>
                                            <Text style={{ borderWidth: 0, marginLeft: 0, fontSize: 16, paddingTop: 2, }}>{mecanic}</Text>
                                        </View>
                                        :
                                        <Text style={{ borderWidth: 0, marginLeft: 2, fontSize: 16, paddingTop: 2, color: 'black' }}>{t('Select mechanic')}</Text>
                                    }
                                </View>
                            </ScrollView>
                        </TouchableOpacity>

                        <Modal isVisible={isModalVisible}>
                            {/* <View style={{  backgroundColor: '#fff', height: 300, marginLeft: '15%',borderWidth:1 }}> */}

                                {/* <View style={{ height: 30, margin: 5, marginLeft: -5,alignSelf:'center' }}> */}
                                    {category ?
                                        <View style={{borderWidth:0,backgroundColor: '#fff',alignSelf:'center',margin:10,}}>
                                            {category.map((click, index) => (

                                                <View style={{ paddingBottom: 15, flexDirection: 'row', marginLeft: 20 ,marginTop:7}}>
                                                    <View>
                                                        <PureRoundedCheckbox
                                                            key={click.label}

                                                            borderColor={'#ffff'}
                                                            backgroundColor={"#ffff"}
                                                            iconColor={'white'}
                                                            text={'✔'}
                                                            innerStyle={{ height: 25, width: 25 }}
                                                            outerStyle={{ height: 25, width: 25 }}
                                                            onPress={(checked) => box1(click.label, checked)}
                                                            checkedColor={'#49c2c6'}
                                                        />
                                                    </View>
                                                    <View>
                                                        <Text style={{ marginHorizontal: 20 }}>{click.label}</Text>
                                                    </View>
                                                </View>

                                            ))}
                                                                            <TouchableOpacity style={{ borderWidth: 0,flexDirection:'row',marginBottom:10 }} onPress={okk}>
                                 <View  style={{borderWidth:0,  width:'100%',justifyContent:'flex-end',flex:1,flexDirection:'row',marginRight:20}}>
                                        <Text style={{ fontSize: 20, color: '#3c6899' }}>{t('ok')}</Text>
                                        </View>
                                </TouchableOpacity>
                                        </View>
                                        : null}

                                {/* </View> */}
                            {/* </View> */}
                        </Modal>

                    </View>


                </View>

                }


                {/* ******************************************************************************************************/}

                {width < '700' ?
                    <View style={{ borderWidth: 0 }}>
                        <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 10, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity>
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom1(value)} value={From1} placeholder={t("Mileage In")} fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={{ width: '50%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 20, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity>
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom2(value)} value={From2} placeholder={t("Mileage out")} fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>


                            </TouchableOpacity>
                        </View>


                    </View>


                    ://device width condition 

                    <View style={{ borderWidth: 0, flexDirection: 'row', width: '100%' }}>


                        <View style={{height:50, width: '30%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 19, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity>
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom1(value)} value={From1} placeholder={t("Mileage In")} fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={{ width: '30%', marginRight: 0, borderWidth: 2, marginLeft: 20, marginTop: 20, borderColor: '#AFB0B6', borderRadius: 10 }} >
                            <TouchableOpacity>
                                <Image style={styles.ficon1} source={require('../../../image/timer.png')} />
                                <TextInput onChangeText={(value) => setFrom2(value)} value={From2} placeholder={t("Mileage out")} fontSize={16} placeholderTextColor={'black'} style={{ borderWidth: 0, position: 'absolute', marginLeft: 40, height: 40, marginTop: 3, color: 'black', paddingLeft: 12 }}></TextInput>
                                <Text style={{ position: 'absolute', right: 10, top: 10 }}>KM</Text>
                            </TouchableOpacity>
                        </View>


                    </View>

                }
                {/* *************************************************************************************** */}

                <View style={{ borderWidth: 0, marginTop: 20 }}>
                    <Text style={{ fontSize: 21, paddingLeft: '4%', color: '#1d334c', fontWeight: 'bold' }}>
                        {t('Upload Image')}
                    </Text>
                </View>
                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 1, flexDirection: 'row', marginTop: 10, marginLeft: 10 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('1')}>
                            {profileimg1 ?

                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg1}` }} />
                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg1}` }} />

                            }
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue1(text, 1)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 1)}
                            value={rmark1} placeholder={t("Remarks")} style={styles.textinput}></TextInput>
                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('2')}>
                            {profileimg2 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg2}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg2}` }} />

                            }
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue2(text, 2)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 2)} value={rmark2} placeholder={t("Remarks")} style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('3')}>
                            {profileimg3 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg3}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg3}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue3(text, 3)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 3)} value={rmark3} placeholder={t("Remarks")} style={styles.textinput}></TextInput>
                    </View>
                </View>
                {/* ************************************************************************************* */}

                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 1, flexDirection: 'row', marginTop: -10, marginLeft: 10 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('4')}>
                            {profileimg4 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg4}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg4}` }} />
                            }
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue4(text, 4)}
                            placeholder={t("Remarks")} onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 4)} value={rmark4} style={styles.textinput}></TextInput>
                    </View>

                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('5')}>
                            {profileimg5 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg5}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg5}` }} />
                            }
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue5(text, 5)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 5)} value={rmark5} placeholder={t("Remarks")} style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('6')}>
                            {profileimg6 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg6}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg6}` }} />
                            }
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue6(text, 6)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 6)} value={rmark6} placeholder={t("Remarks")} style={styles.textinput}></TextInput>

                    </View>
                </View>
                {/* ************************************************************************************** */}

                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 1, flexDirection: 'row', marginTop: -10, marginLeft: 10 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('7')}>
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                            {profileimg7 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg7}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg7}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue7(text, 7)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 7)} value={rmark7} placeholder={t("Remarks")} style={styles.textinput}></TextInput>
                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('8')}>
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                            {profileimg8 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg8}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg8}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue8(text, 8)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 8)} value={rmark8} placeholder={t("Remarks")} style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 130 }}>
                        <TouchableOpacity onPress={() => selectimage('9')}>
                            {/* <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} /> */}
                            {profileimg9 ?
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg9}` }} />

                                :
                                <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profileimg9}` }} />
                            }
                        </TouchableOpacity>
                        <TextInput
                            onChangeText={text => setremarkvalue9(text, 9)}
                            onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, 9)} value={rmark9} placeholder={t("Remarks")} style={styles.textinput}></TextInput>
                    </View>
                </View>

                <View style={{ borderWidth: 0, bottom: 10, marginLeft: 0, flex: 1, flexDirection: 'row', justifyContent: 'center' }}>
                    <TouchableOpacity style={styles.btn} onPress={draff} >
                        <Text style={styles.btninner}>
                            {t('Save Draft')}
                        </Text>
                    </TouchableOpacity>
                    <View style={{ width: 15 }}></View>
                    {passid ?
                        <TouchableOpacity style={styles.btn} onPress={() => pass(passid)} >
                            <Text style={styles.btninner}>
                                {t('Submit')}
                            </Text>
                        </TouchableOpacity>
                        :
                        <TouchableOpacity style={styles.btn} onPress={() => nodraff()} >
                            <Text style={styles.btninner}>
                               {t('Submit')}
                            </Text>
                        </TouchableOpacity>
                    }

                </View>

            </ScrollView>
        </View>

    )

}
export default Inspection;