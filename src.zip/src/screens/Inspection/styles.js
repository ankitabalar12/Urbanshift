import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    main:{
        width: '100%', flexDirection: 'row' ,marginLeft:30,marginBottom:10,marginTop:-5,borderWidth:0
    },
    sub:{
        width: '35%' 
    },
    frist:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18
    },
    fline:{
        textAlign: 'left', color: '#526578', fontSize: 18
    },
    view:{
        width: '35%',marginLeft:10
    },
    ficon:{
        width:25,
        height:25,
        margin:9,
    },
    ficon2:{
      width:27,
      height:27,
      margin:9,
  },
    ficon1:{
        width:25,
        height:25,
        margin:9,
    },
    dropdown: {
        // height: 50,
        borderColor: '#AFB0B6',
        // borderWidth: 0.5,
        borderRadius: 10,
        paddingHorizontal: 8,
        borderWidth:2,
        // borderBottomWidth:1,
        width:'52%',
        // alignSelf:'center',
        borderStyle: 'solid',
        paddingLeft:'2%',
        marginTop:20,
        marginLeft:13,
        height:42,
      },
      dropdown2: {
        // height: 50,
        borderColor: '#AFB0B6',
        // borderWidth: 0.5,
        borderRadius: 10,
        paddingHorizontal: 8,
        borderWidth:2,
        // borderBottomWidth:1,
        width:'52%',
        // alignSelf:'center',
        borderStyle: 'solid',
        paddingLeft:'2%',
        marginTop:10,
        marginLeft:13,
        height:52,
      },
      placeholderStyle: {
        fontSize: 18,
        color: '#AFB0B6',
        fontFamily:'Poppins-bold',
        marginLeft:36
        // borderWidth:1
      },
      selectedTextStyle: {
        fontSize: 17,
        color:'black',
        fontFamily:'Poppins-bold',
        marginLeft:36

        // borderWidth:1
      },
      ficon3:{
        width:35,
        height:35,
        margin:9,
        position:'absolute',
        top:15,
        left:10
      },
      ficoncolum:{
        width:35,
        height:35,
        margin:9,
        position:'absolute',
        top:9,
        left:10
      },
 
     
        ficon4:{
            width:35,
            height:35,
            margin:9,
            position:'absolute',
           top:-7,
           left:-5
      },
      selectedText1Style:{
        fontSize: 17,
        color:'black',
        fontFamily:'Poppins-bold',
        marginLeft:45
      },
      textinput:{
        borderWidth:2,
        marginTop:30,
        fontSize:16,
        borderColor:'#a3a3a3',
        borderRadius:10,
        height:'45%',
        textAlignVertical:'top'
        // paddingTop:-5
        
      },
      btn:{
        height:45,
        borderRadius:3,
        backgroundColor:'#346696',
        width:'40%',
        alignSelf:'center'
     
    },
    btninner:{
        textAlign:'center',
        color:'white',
        fontSize:18,
        fontWeight:'bold',
        marginTop:7,
      
    },
    spinner: {
      flex: 1,
      justifyContent: 'center',
      backgroundColor:'rgba(24, 24, 24, 0.075)',
      position:'absolute',
      top:0,
      zIndex:9999,
      height:'100%',
      width:'100%',
      // borderWidth:1
     
    },
    checkbox:{
      borderWidth: 1, width: 15, height: 15, borderColor: 'gray', borderRadius: 3, margin: 5, marginLeft: 10 
    },
    profileimg: {
      borderWidth: 0, width: '100%', borderRadius: 10, height: 130 
       
      // marginLeft:'75%'
  },
     
})
