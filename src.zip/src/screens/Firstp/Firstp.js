import React from 'react';
import { ScrollView, Text, View, Image, TouchableOpacity,StatusBar } from 'react-native';
import { styles } from './styles';
import { LogBox } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import FastImage from 'react-native-fast-image';
LogBox.ignoreAllLogs();


export default function Firstp({ navigation }) {

    return (
        <View style={styles.maincontainer}>
            <ScrollView>
            <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                  
                    <View style={styles.img}>
                        <FastImage resizeMode='stretch' style={{flex:1}} source={require('../../../image/first.jpeg')} />
                    </View>
                    <View style={{ height: 30 }}></View>
                    <Text style={styles.qty}>
                        Quality servicing just for you.
                    </Text>
                    <View style={{ height: 18 }}></View>
                    <Text style={{ fontSize: 16, lineHeight: 25, letterSpacing: 1 }}>
                        Keep your appointments up to date and be notified of upcoming appointments.
                    </Text>
                    <View style={{ height: 25 }}></View>
                    <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Loginoption')}>
                        <Text style={styles.btninner}>
                            Explore
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
}

