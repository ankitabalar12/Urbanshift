import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
      
    },
    qty:{
        textAlign:'left',fontSize:35,color:'black',fontWeight:'bold'
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    img:{
        height:390,width:'100%',borderWidth:0,alignSelf:'center'
      }
})