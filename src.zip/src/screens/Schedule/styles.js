import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        // backgroundColor: '#fafafd',
        // height,
        // marginTop: Platform.OS === "ios" ? 35 : 0,
        backgroundColor:'#3c6899',
        // borderWidth:1
    },
    main1:{
              marginTop: Platform.OS === "ios" ? 35 : 0,
              //  backgroundColor: '#fafafd',
              //  height:'100%',
              //  borderWidth:1
    },
    container: {
        flex: 1,
        paddingTop: 30,
        backgroundColor: '#3c6899',
        padding: 16,
      },
      textStyle: {
        marginTop: 10,
      },
      titleStyle: {
        textAlign: 'center',
        fontSize: 20,
        margin: 20,
      },
      ficon1:{
        height:23,
        width:23,
        position:'absolute',
        left:'30%',
      marginTop:125,
        borderRadius:20,
      
        
      },
      spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
      mainbox:{
        // borderWidth:1,
    justifyContent:'flex-end',
        width:'100%',
        flex:1,
        flexDirection:'row',
       paddingRight:10
      }
})