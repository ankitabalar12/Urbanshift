import React, { useState,useEffect } from "react";
import {
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  StatusBar,
  SafeAreaView,
  ActivityIndicator
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import CalendarPicker from "react-native-calendar-picker";
import AsyncStorage from "@react-native-community/async-storage";
import moment from 'moment';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
const Schedule = ({ navigation }) => {
    const [utype, setUsertype] = useState('');
    const [loading, setLoading] = useState(false);
    const [upcomming,setUpcomming]=useState([]);
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [Value2, setValue2] = useState('');
    useEffect(() => {
            async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
        var date = new Date().getDate();
        var month = new Date().getMonth() + 1; 
        var year = new Date().getFullYear(); 
        global.currentDate =  year + '0' + month + '' + date 
            const type = await AsyncStorage.getItem('usertype')
            setUsertype(type);
            onDateChange(global.currentDate,0);
         }
        fetchData();
    }, [])
    const selectlan = async (value) => {
        setValue2(value)
          if (value == '1') {
              changeLanguage('en')
          }
          if (value == '2') {
              changeLanguage('hi')
          }
        }
        const changeLanguage = value => {
            i18n
                .changeLanguage(value)
                .then(() => setLanguage(value))
                .catch(err => console.log(err));
        };
    const onDateChange = (date, type) => {
            global.res = date.replace(/-/g,'')
            Upcomming()
    };
    const Upcomming =async()=>{
    const result1 = await AsyncStorage.getItem('QasLogin')
    const screenData = JSON.parse(result1)
    const data =[];
        setLoading(true)
     fetch(global.url+'getappointment.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id:screenData.id,
            }),
        })
        .then((res) => res.json())
            .then(async(json) => {
                if (json.ResponseCode == '1') {
                    var count =json.upcomming
                    if(json.upcomming!==null){
                    for (var i=0;i<count.length;i++){
                        const datess=count[i].date
                     const api = datess.replace(/-/g,'')
                            if(api===global.res){
                                data.push(json.upcomming[i])
                              }
                          }
                        }else{
                            setUpcomming(null)
                        }
                        setUpcomming(data)
                        global.found=data
                      setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
                //console.log(err)
            });
 }

return(
  <View style={styles.main1}>
    <ScrollView  style={{bottom:10}}>
    <View style={styles.maincontainer}>
    <StatusBar backgroundColor='#3c6899' barStyle="dark-content" />
        <View style={{ margin: 30 }}>
            <View style={{ height: 10 }}></View>
            <TouchableOpacity onPress={() => navigation.goBack()}>
                <Ionicons name="chevron-back" size={35}  style={{color:'#ffffff',marginLeft:-10}}/>
                </TouchableOpacity>
                <View style={{flex:1,width:'100%'}}>
                    <Text style={{ fontSize: 25, color: '#ffffff', fontWeight: 'bold',borderWidth:0 }}>{t('My Schedule')}</Text>
                    <TouchableOpacity  onPress={()=>navigation.navigate('Macappointment') } style={{ borderWidth:0,flexDirection:'row',position:'absolute',right:3,marginTop:5}} >
                        <Text style={{ fontSize: 18, color: '#ffffff', fontWeight: 'bold',alignSelf:"center",textAlign:'center' }}>{t('View All')}</Text>
                    </TouchableOpacity>
                    </View>
                        </View>
                        <SafeAreaView style={styles.container}>
      <View style={styles.container}>
       <CalendarPicker
          startFromMonday={true}
          allowBackwardRangeSelect={true}
          minDate={new Date(2018, 1, 1)}
          maxDate={new Date(2050, 6, 3)}
          weekdays={
            [
              'M', 
              'T', 
              'W', 
              'T', 
              'F', 
              'S', 
              'S'
            ]
        }
          months={
            [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec',
          ]
        }
        previousTitle=""
        nextTitle="."
        todayBackgroundColor="#202642"
        todayTextStyle="#ffffff"
        selectedDayStyle={{
        selectedDayTextColor:"#3c6899",
          }}
          scaleFactor={375}
          headerWrapperStyle={{backgroundColor:'#3c6899',marginTop:-80}}
          textStyle={{
            fontFamily: 'Cochin',
            color: '#ffffff',
          }}
          dayLabelsWrapper={{
            borderBottomWidth:0,
            borderTopWidth:0,
            backgroundColor:'#3c6899',
            width:500,
            marginTop:-15,
            }}
            onDateChange={(res) => onDateChange(moment(res).format("YYYY-MM-DD"))}
        />
      </View>
    </SafeAreaView>
    </View>
    {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                       
                    </View>
                    : null}
            {upcomming !== null?
                    <View style={{borderWidth:0}}>
                 {upcomming.map((up, index) => (
                        <View key={index}>
                                    <TouchableOpacity style={styles.mainbox}  onPress={() => navigation.navigate('Appodetail',up)}>
                                    <View style={{borderRadius: 20,  marginTop: 10,borderWidth:2,borderColor:'#1d334c' ,width:'70%'}}>
                                        <View style={{ height: 20 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                                            </View>
                                            <View style={{ width: '70%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.message}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.date}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.service_type}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 15 }}></View>
                                    </View>
                                    </TouchableOpacity>
                                    <View style={{position:'absolute',top:'40%',left:20,width:'19%',textAlign:'center'}}>
                                        <Text style={{fontSize:20,color:'#495b6f',borderWidth:0}}>{up.time}</Text>
                                    </View>
                             </View>
                    ))}
              </View>  
                    :
                    <View style={{margin:5,marginTop:30}}>
                    <Text style={{borderWidth:0,alignSelf:'center',fontSize:23,textAlign:'center'}}>{t('You have no upcomming appointment')}</Text>
                    </View>
              
                    }
                        {global.found!=''?
                          null      
                     :
                     <View style={{margin:5,marginTop:30}}>
                    <Text style={{borderWidth:0,alignSelf:'center',fontSize:23,textAlign:'center'}}>{t('No appointment found for selected date')}</Text>
                    </View>
                     }
               </ScrollView>
            </View>
)
}
export default Schedule;