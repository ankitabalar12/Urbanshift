import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    ActivityIndicator
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-community/async-storage';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
const Appodetail = ({ navigation, route }) => {
    const [mess, setmess] = useState('')
    const [date, setdate] = useState('')
    const [time, settime] = useState('')
    const [type, settype] = useState('')
    const [vnum, setvnum] = useState('')
    const [iunum, setiunum] = useState('')
    const [brand, setbrand] = useState('')
    const [model, setmodel] = useState('')
    const [road, setroad] = useState('')
    const [coe, setcoe] = useState('')
    const [inspection, setinspection] = useState('')
    const [service, setservice] = useState('')
    const [chassis, setchassis] = useState('')
    // const [status, setstatus] = useState('')
    const [st, setst] = useState(1)
    const [st1, setst1] = useState(0)
    const [id, setid] = useState('')
    const [status1, setstatus1] = useState(0)
    const [passup, setpassup] = useState('')
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [cusname, setcusname] = useState('');
    const [cusmobile, setcusmobile] = useState('');
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        const Upcomming = route.params
        setpassup(Upcomming)
        setmess(Upcomming.message)
        setdate(Upcomming.date)
        settime(Upcomming.time)
        settype(Upcomming.service_type)
        setcusname(Upcomming.customer_name)
        setcusmobile(Upcomming.customer_mobile)
        setid(Upcomming.id)
        setvnum(Upcomming.cardetail.vehicle_number)
        setiunum(Upcomming.cardetail.car_iu_number)
        setbrand(Upcomming.cardetail.car_brand)
        setmodel(Upcomming.cardetail.car_model)
        setroad(Upcomming.cardetail.road_tax_expiry_date)
        setcoe(Upcomming.cardetail.coe_expiry_date)
        setinspection(Upcomming.cardetail.inspection_due_date)
        setservice(Upcomming.cardetail.last_service_date)
        setchassis(Upcomming.cardetail.chassis_number)

    })
    useEffect(() => {
        navigation.addListener('focus', async () => {
            const typee = await AsyncStorage.getItem('type');

            selectlan(typee)
        })
    })
    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const up = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setLoading(true)
        fetch(global.url + 'upcommingappointment.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,

            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                    var count = Object.keys(json.upcomming).length;
                    for (var i = 0; i < count; i++) {
                        if (json.upcomming[i].id == id) {
                           var change = json.upcomming[i]
                            change.status = 1
                        }
                    }
                    setstatus1(change)
                    work();
                    setLoading(false)
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }
    const work = async (st) => {
        const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)

        fetch(global.url + 'startwork.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: screenData.id,

            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                }
                else {
                    alert(json.ResponseMsg)
                }
            })
            .catch((err) => {
            });
    }
    const alldata = {
        pass: passup,
        number: 1
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 20 }}>{t("Appointment Details")}</Text>
                        </View>
                <View>
                    <View style={{ backgroundColor: '#b3c5d9', borderRadius: 20, margin: 25, marginTop: 0 }}>
                        <View style={{ height: 20 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                            </View>
                            <View style={{ width: '70%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>{vnum}</Text>
                            </View>
                        </View>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                            </View>
                            <View style={{ width: '80%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>{date}</Text>
                            </View>
                        </View>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clockapp.png')} />
                            </View>
                            <View style={{ width: '80%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>{time}</Text>
                            </View>
                        </View>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                            </View>
                            <View style={{ width: '80%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>{type}</Text>
                            </View>
                        </View>
                        <View style={{ height: 15 }}></View>
                    </View>
                </View>
                <Text style={{ fontSize: 25, color: '#9b9ba7', fontWeight: 'bold', marginLeft: 25 }}>{t('Customer Details')}</Text>
                <View style={{ borderRadius: 20, margin: 5, marginTop: 10 }}>
                    <View style={{ height: 20 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                        <View style={{ width: '15%' }}>
                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/pr.png')} />
                        </View>
                        <View style={{ width: '70%' }}>
                            <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>{cusname}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                        <View style={{ width: '15%' }}>
                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/mail.png')} />
                        </View>
                        <View style={{ width: '80%' }}>
                            <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>{date}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                        <View style={{ width: '15%' }}>
                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/phone.png')} />
                        </View>
                        <View style={{ width: '80%' }}>
                            <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>{cusmobile}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                        <View style={{ width: '15%' }}>
                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/report.png')} />
                        </View>
                        <View style={{ width: '80%' }}>
                            <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>{mess}</Text>
                        </View>
                    </View>
                    <View style={{ height: 15 }}></View>
                </View>
                <Text style={{ fontSize: 25, color: '#9b9ba7', fontWeight: 'bold', marginLeft: 25 }}>{t('Full Car Details')}</Text>
                <View style={{ height: 15 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('License Plate')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{vnum}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('IU Number')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{iunum}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('Brand')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{brand}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('Model')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{model}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('Road Tax Expiry')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{road}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('COE Expiry')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{coe}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('Inspection Due Date')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{inspection}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('Last Service Date')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{service}</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>{t('Chassis Number')}</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>{chassis}</Text>
                    </View>
                </View>

                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />

                    </View>
                    : null}
                {status1 == '0' ?
                    <TouchableOpacity style={styles.btn} onPress={() => up()} >
                        <Text style={styles.btninner}>
                            {t('Start Work')}
                        </Text>
                    </TouchableOpacity>
                    :
                    <TouchableOpacity style={styles.btn} onPress={() => { navigation.navigate('Repair', alldata, 1) }} >
                        <Text style={styles.btninner}>
                            {t('Upload Report')}
                        </Text>
                    </TouchableOpacity>
                }
            </ScrollView>
        </View>
    )

}
export default Appodetail;