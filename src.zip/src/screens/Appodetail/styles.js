import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    frow:{
        width: '100%', flexDirection: 'row',borderWidth:0
    },
    fw:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18,marginLeft:24,borderWidth:0
    },
    sw:{
        textAlign: 'right', color: '#526578', fontSize: 18
    },
    sw1:{
        textAlign: 'right', color: '#526578', fontSize: 18
    },
    view:{
        width: '35%',marginLeft:10
    },
    btn:{
        height:50,borderRadius:3,backgroundColor:'#346696',width:'95%',marginTop:15,margin:'3%'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:20,fontWeight:'bold',marginTop:7
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
})