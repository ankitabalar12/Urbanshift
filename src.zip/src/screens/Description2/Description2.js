import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    SafeAreaView,
    ActivityIndicator,
    Alert
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import RadioGroup from "react-native-radio-buttons-group/lib/RadioGroup";
import Inspection from "../Inspection/Inspection";
import AsyncStorage from '@react-native-community/async-storage';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import { PureRoundedCheckbox } from "react-native-rounded-checkbox";
import _isEqual from 'lodash/isEqual';





const Description2 = ({ navigation, route }) => {
    const [click, setClick] = useState(0)
    const [select, setSelect] = useState(0);
    const [selectdone, setSelectdone] = useState(1);
    const [desc, setdesc] = useState([]);
    const [req, setreq] = useState([]);
    const [Remark, setremark] = useState([]);
    const [Remarkid, seRemarkid] = useState([]);
    const [data, setData] = useState('');
    const [done, setdone] = useState([]);

    // const initialArray = Array.from({ length: 10 }, (_, index) => `Value ${index + 1}`);
    const [newdesc, setnewdesc] = useState([]);
    const [vnum, setvnum] = useState('');
    const [deldraf, setdeldraf] = useState('');
    const [vbrand, setvbrand] = useState('');
    const [vmodel, setvmodel] = useState('');
    const [mill, setmill] = useState('');
    const [com, setcom] = useState('');
    const [driver, setdriver] = useState('');
    const [con, setcon] = useState('');
    const [to, setto] = useState('');
    const [time, settimein] = useState('');
    const [chit, setchit] = useState('');
    const [date, setdate] = useState('');
    const [From, setFrom] = useState('');
    const [clickval, setclickval] = useState('');
    const [From1, setFrom1] = useState('');
    const [From2, setFrom2] = useState('');
    const [pic, setpic] = useState('');
    const [imgremark, setimgremark] = useState('');
    const [loading, setLoading] = useState(false);
    const [final, setfinal] = useState('');
    const [draf, setdraf] = useState('');
    const [compulsory, setcompulsory] = useState('');
    const [submitted, setsubmitted] = useState(false)
    const [st, setst] = useState('');
    const [sdatepass, setsdate] = useState('');
    const [stimepass, setstime] = useState('');
    const [description, setdescription] = useState('');
    const [req1, setreq1] = useState('');
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [dd, setdd] = useState('');
    const [newdescription, setnewdescription] = useState([]);
    const [oldarray, setoldarray] = useState('');
    const [reqatten, setreqatten] = useState('');
    // let newreq = [];
    useEffect(() => {

        navigation.addListener('focus', async () => {

            setLoading(true)
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)

            const vnum = route.params.vehicle_number
            setvnum(vnum)
            const deletedraft = route.params.deletedraftid
            setdd(route.params.deletedraftid)
            setdeldraf(deletedraft)
            console.log('deldraf>>>', deldraf)
            console.log('route.params.deletedraftid>>>', route.params.deletedraftid)
            const vbrand = route.params.vehicle_brand
            setvbrand(vbrand)
            const vmodel1 = route.params.vehicle_model
            setvmodel(vmodel1)
            const mill = route.params.mileage
            setmill(mill)
            const com = route.params.company_name
            setcom(com)
            const driver = route.params.driver_name
            setdriver(driver)
            const con = route.params.contact_number
            setcon(con)
            const to = route.params.towing_date
            setto()
            const timein = route.params.time_in
            settimein(timein)
            const chit = route.params.tow_chit_no
            setchit(chit)
            const draff = route.params.is_draft
            setdraf(draff)
            const desc = route.params.description

            //console.log('route.params.description>>>',route.params.description)
            let descArray = [];

            if (!Array.isArray(desc)) {
                const convertarray = desc.split(',')
                for (var m = 0; m < convertarray.length; m++) {

                    descArray.push({ label: convertarray[m], value: m, selected: '' })
                }
                //  global.req = route.params.req_attn
                setreqatten(route.params.req_attn)

            } else {
                descArray = desc;
                // global.req = route.params.req_attn.split(',')
                setreqatten(route.params.req_attn.split(','))
                // global.minusornot = '1'
            }

            const convertstring = route.params.req_attn.toString()
            const conv = convertstring.split(',')
            //    setnewdesc([]);
            // setnewdesc([...newdesc]);
            for (var i = 0; i < descArray.length; i++) {
                conv.some(element => {
                    // if(descArray[i].value){
                    if (descArray[i].value == element) {
                        newdesc[i] = { label: descArray[i].label, value: descArray[i].value, selected: true };
                        return true;
                    } else {
                        newdesc[i] = { label: descArray[i].label, value: descArray[i].value, selected: false };
                    }
                    // }
                })
                newdescription.push(descArray[i].label);
            }
            console.log('newdesc[i]>>>', newdesc)

            //console.log('description >> ',newdesc)
            const myArray = desc
            const req1 = route.params.req_attn
            const string = req1.toString()
            setst(string)
            const comma = string.split(',')
            setreq1(req1.toString())
            ////console.log('res1>>>>',req1)
            const remark = route.params.remarks
            const dateout = route.params.date_out
            setdate(dateout)
            const timeout = route.params.time_out
            // ////console.log('----->>>>timeout==', timeout)
            setFrom(timeout)
            const comby = route.params.completed_by

            setclickval(comby)
            const ins = route.params.inspected_by

            const millin = route.params.mileage_in

            setFrom1(millin)
            const milout = route.params.mileage_out

            setFrom2(milout)
            const img = route.params.images

            setpic(img)
            const sdate = route.params.sdate

            setsdate(sdate)
            const stime = route.params.stime

            setstime(stime)
            const imgmark = route.params.image_remark

            setimgremark(imgmark)
            setLoading(false)
        })
    }, [])


    const selectlan = async (value) => {
        ////console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }


    }
    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const checkTextInput = async () => {

        const mergedArray = done.concat(Remarkid);
        const uniqueArray = Array.from(new Set(mergedArray));
        global.newreq = [];
        reqatten.forEach(element => {
            newreq.push(element)
        });
        // console.log('JJ---', newreq)
        const test = newreq.toString();

        const remarkArray = uniqueArray.toString();
        const newunique = remarkArray.split(',');

        const sortedArr1 = newunique.slice().sort();
        const sortedArr2 = test.split(',').slice().sort();

        //console.log('sortedArr1',sortedArr1);
        //console.log('sortedArr2',sortedArr2);


        const result = _isEqual(sortedArr1, sortedArr2);
        //console.log('result',result);
        if (result) {

            apicall();
        } else {

            Alert.alert(
                'Error',
                'Please ensure that you have completed all requirements, else please input the remarks before submitting.',
                [

                    { text: 'OK', onPress: () => console.log('OK Pressed') },
                ]
            );
        }
    }
    const apicall = async () => {


        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData2 = JSON.parse(result1)
        //console.log('newdescription>>>',newdescription)

        // ////console.log('***************apifinal==>>>', final)
        setLoading(true)

        fetch(global.url + 'addreport.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData2.id,
                vehicle_number: vnum,
                vehicle_brand: vbrand,
                vehicle_model: vmodel,
                mileage: mill,
                company_name: com,
                driver_name: driver,
                contact_number: con,
                towing_date: to,
                time_in: time,
                tow_chit_no: chit,
                description: newdescription.toString(),
                req_attn: global.newreq.toString(),
                done: done.toString(),
                remarks: Remark.toString(),
                date_out: date,
                time_out: From,
                completed_by: clickval.toString(),
                inspected_by: '',
                mileage_in: From1,
                mileage_out: From2,
                images: pic,
                image_remark: imgremark,
                is_draft: draf,
                sdate: sdatepass,
                stime: stimepass
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                console.log('J', json)
                if (json.ResponseCode == '1') {
                    Alert.alert(
                        '',
                        json.ResponseMsg,
                        [
                            {

                            },
                            {
                                text: (t('OK')),

                                onPress: () =>
                                    navigation.navigate('Home')
                            },
                        ]
                    );
                    console.log('dd>>>', dd)
                    if (dd !== undefined) {
                        dffdelete(deldraf);
                    }
                    setLoading(false)
                }
                else {
                    alert(json.ResponseMsg)
                }
            })
            .catch((err) => {
                console.log('====', err);
                ////console.log(err)
            });



    }

    const dffdelete = (deldraf) => {
        fetch(global.url + 'deletefromdraft.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: deldraf,

            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                    console.log('delete draft >>>', json)
                }
                else {
                    alert(json.ResponseMsg)
                }

            })
            .catch((err) => {

            });

    }


    const setremarkvalue = (val, id) => {
        //console.log(id)
        //console.log('Remark>>>',Remark)
        Remark.push(val + '-' + id);
        Remarkid.push(id);


        ////console.log('remark value', Remark)

    }
    const handleToggleCheckboxtwo = (label, index, othertext) => {

        //console.log('index>>',index)
        // done.push(index)

        if (!done.includes(index)) {
            done.push(index)
            const filteredArray = done.filter((item) => item !== undefined);
            // //console.log('filteredArray>>', filteredArray)
            //global.finalreq = filteredArray
            //const final = filteredArray.toString()
            //setfinalreq(final)
            // //console.log('finalreq>', final)
            // //console.log('newdesc select>>>',newdesc)

        } else {
            var indexx = done.indexOf(index)
            done.splice(indexx, 1);

        }

    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#fafafd' }}>

            <View style={styles.maincontainer}>
                <ScrollView style={{ marginBottom: 15 }}>
                    <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                    <View style={{ margin: 30 }}>
                        <View style={{ height: 10 }}></View>
                        <TouchableOpacity style={{ width: '20%' }} onPress={() => navigation.goBack()}>
                            <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.btn} onPress={checkTextInput}>
                            <Text style={styles.btninner}>
                                {t('Next')}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.hadding}>
                        <View style={styles.h1}><Text style={{ fontSize: 16, fontWeight: 'bold' }}>{t('Description')}</Text></View>
                        <View style={styles.h2}><Text style={{ fontSize: 16, fontWeight: 'bold', textAlign: 'center' }}>{t('Req Attn')}</Text></View>
                        <View style={styles.h3}><Text style={{ fontSize: 16, fontWeight: 'bold', textAlign: 'center' }}>{t('Done')}</Text></View>
                        <View style={styles.h4}><Text style={{ fontSize: 16, fontWeight: 'bold', textAlign: 'center' }}>{t('Remarks')}</Text></View>
                    </View>




                    {newdesc ?
                        <View>
                            {newdesc.map((o, index) => (


                                <View key={index} style={styles.rows}>
                                    {o.value > 32 ?
                                        // <TextInput onChangeText={(value) => handleToggleCheckboxtwo(value,onetimeadd)}  style={styles.text2}></TextInput>
                                        <TextInput style={styles.text2} value={o.label}></TextInput>
                                        :
                                        <Text style={styles.text}>{o.label}</Text>

                                    }
                                    <View style={styles.redio}>

                                        <PureRoundedCheckbox
                                            borderColor={'gray'}
                                            backgroundColor={"white"}
                                            iconColor={'#5c8ee0'}
                                            isChecked={o.selected}
                                            // isChecked={index}
                                            // isChecked={seloccu.includes(o.label)}
                                            text=''
                                            // textStyle={{ width: 150, fontSize: 17, height: 30, borderWidth: 0, marginLeft: 170, paddingLeft: 15 }}
                                            uncheckedTextColor='gray'
                                            checkedTextColor='gray'
                                            innerStyle={{ height: 18, borderWidth: 1, width: 18, borderColor: 'gray' }}
                                            outerStyle={{ height: 15, width: 15, borderWidth: 0, marginTop: 0 }}
                                            checkedColor={'#5c8ee0'}
                                            disabled={true}
                                        />
                                    </View>
                                    <View style={styles.disableredio}>
                                        <PureRoundedCheckbox
                                            borderColor={'gray'}
                                            backgroundColor={"white"}
                                            iconColor={'#5c8ee0'}
                                            text=''
                                            innerStyle={{ height: 18, borderWidth: 1, width: 18, borderColor: 'gray' }}
                                            outerStyle={{ height: 15, width: 15, borderWidth: 0, marginTop: 0 }}
                                            onPress={(checked) => handleToggleCheckboxtwo(o.label, o.value)}
                                            checkedColor={'#5c8ee0'}
                                            disabled={o.selected !== true && o.selected !== o.value}
                                        />

                                    </View>
                                    <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text, o.value)} editable={o.selected !== false && o.selected !== o.value} style={styles.textinput}></TextInput>
                                </View>
                            ))}
                        </View>
                        : null}
                    <View style={{ borderWidth: 0, width: '100%', justifyContent: 'flex-end', flexDirection: 'row', marginTop: 10 }}>
                        <TouchableOpacity onPress={checkTextInput} style={styles.btn1}>
                            {/* <TouchableOpacity  onPress={checkTextInput} style={styles.btn1}> */}
                            <Text style={styles.btninner1}>
                                {t('Next')}
                            </Text>
                        </TouchableOpacity>
                    </View>

                </ScrollView>
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}

            </View>
        </SafeAreaView>
    )

}
export default Description2;