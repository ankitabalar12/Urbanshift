import React, { useEffect ,useState} from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import FastImage from 'react-native-fast-image';
export default function Conformation({ navigation }) {
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [value,setValue]=useState('');
    useEffect(() => {
        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
        }
        fetchData();
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
     }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <View style={{ margin: 20 }}>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="close" size={35}  style={{color:'black'}}/>
                    </TouchableOpacity>
                    <View style={{ height: 50 }}></View>
                    <View style={{borderWidth:0,height:400, width: 400,alignSelf:'center'}}>
                        <FastImage resizeMode='contain' style={{ flex:1 }} source={require('../../../image/Confirm.jpg')} />
                    </View>
                    <Text style={{ textAlign: 'center', color: 'black', margin: 10, fontSize: 25, fontWeight: 'bold' }}>{t('Confirmation')}</Text>
                    <Text style={{ textAlign: 'center', margin: 10, fontSize: 18 }}>{t('Your appointment has been confirmed.')}</Text>
                    <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Home')}>
                        <Text style={styles.btninner}>
                           {t('Back to Home')} 
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};