import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#ffffff',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    btn: {
        height: 45, borderRadius: 3, backgroundColor: '#346696',
        marginTop: 100
    },
    btninner: {
        textAlign: 'center', color: 'white', fontSize: 18, fontWeight: 'bold', marginTop: 7
    },
})