import React, { useState,useEffect } from 'react';
import { ScrollView, Text, ActivityIndicator,TextInput, TouchableOpacity,Alert, View, Image, StatusBar } from 'react-native';
import { styles } from './styles';
import Modal from "react-native-modal";
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';

export default function Upcomingapp({ navigation }) {
    const [isModalVisible, setModalVisible] = useState(false);
    const [isModalVisible2, setModalVisible2] = useState(false);
    const [isdelete, setIsdelete] = useState('1')
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [mes,setMes]=useState('');
    const [value,setValue]=useState('');
    const [date,setDate]=useState('');
    const [is_select,setSelect]=useState('');
    const [mes1,setMes1]=useState('');
    const [value1,setValue1]=useState('');
    const [date1,setDate1]=useState('');
    const [loading, setLoading] = useState(false);
    const [upcomming,setUpcomming]=useState('');
    const [history,setHistory]=useState('');
    const [pass,setPass]=useState('');
    const [utype, setUsertype] = useState('');
    const [del, setdel] = useState('');
    const [del2, setdel2] = useState('');
useEffect(() => {
        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
            const type = await AsyncStorage.getItem('usertype')
            setUsertype(type); 
            appointment();
            up();
        }
        fetchData();
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
      

    }
    const selectpop = (up) => {
        setModalVisible(true)
        setPass(up)
        setdel(up.id)
 
    }
    const selectpop2= (up) => {
        setModalVisible2(true)
        // setPass(up)
        setdel(up.id)
 
    }
    const rest = () => {
        setModalVisible(false)
        navigation.navigate('Reschle',pass)
    }
    const deletes = () => {
        Alert.alert(t(
           "Are your sure?"),
           (t ("Are you sure you want to Delete?")),
            [
              // The "Yes" button
              {
                text: (t("Yes")),
                onPress: () => {
                    // const del = async(id,index)=>{
                        setLoading(true);
                        fetch(global.url + 'deleteappointment.php', {
                            method: 'POST',
                            headers: {
                                Accept: 'application/json',
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                id:del
            
                            }),
                        })
                            .then((res) => res.json())
                            .then(async (json) => {
                                setLoading(false);
                                if (json.ResponseCode == '1') {
                                   
                                    setModalVisible(false)
                                    setModalVisible2(false)
                                    appointment();
                                    
                                } else {
                                    alert(json.ResponseMsg)
                                    setLoading(false);
                                }
                            })
                            .catch((err) => {
                               
                            });
                    // }
                },
                
              },
              // The "No" button
              // Does nothing but dismiss the dialog when tapped
              {
                text: "No",
                onPress: () => {
                    setModalVisible(false)
                    setModalVisible2(false)

                    appointment();
                }
              
              },
            ]
            );
   

       
    }

    const cancel=()=>{
        setModalVisible(false)
        setModalVisible2(false)
    }

    const appointment =async()=>{
       
        const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)
     setLoading(true);
        fetch(global.url+'getappointment.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
                
            }),
        })
        .then((res) => res.json())
            .then(async(json) => {
                if (json.ResponseCode == '1') {
                    setLoading(true);
                    await AsyncStorage.setItem('startScreen', "loginsucess");
                    // await AsyncStorage.getItem('QasUpdate', JSON.stringify(json.upcomming));
                    
                    setUpcomming(json.upcomming)
                    setHistory(json.history)
                   setLoading(false);
                } else {
                    alert(json.ResponseMsg)

                    setLoading(false);
                }
               
            })
            .catch((err) => {
                console.log(err)
            });
    }

    const up =async()=>{
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setLoading(true);
        // if(utype!='2'){
            // alert('okokokoko')
        fetch(global.url+'upcommingappointment.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id:screenData.id,
                
            }),
        })
        .then((res) => res.json())
            .then(async(json) => {
                if (json.ResponseCode == '1') {
                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)

                    setLoading(false);
                }
               
            })
            .catch((err) => {
                console.log(err)
            });

    // }

    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 20 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Image style={styles.ficon} source={require('../../../image/back.png')} />
                    </TouchableOpacity>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ marginTop: 10, fontSize: 25, color: 'black' }}>
                        {t('Upcoming Appointments')}
                    </Text>
      {utype!='2'?
      <View>
         {upcomming?
            <View>
                 {upcomming.map((up, index) => (
                    <View key={index}>
                           
                                    <View style={{ backgroundColor: '#b3c5d9', borderRadius: 20 ,margin:5}}>
                                        <View style={{ height: 20 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                                            </View>
                                            <View style={{ width: '70%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{t(up.message)}</Text>
                                            </View>
                                            {/* <TouchableOpacity style={{ width: '10%' }} onPress={()=>navigation.navigate('Reschle',up)}  > */}
                                            <TouchableOpacity style={{ width: '10%' }} onPress={()=>selectpop(up)}  >
                                                <Image style={{ height: 20, width: 8 }} source={require('../../../image/dotapp.png')} />
                                            </TouchableOpacity>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.date}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clockapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.time}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.service_type}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 15 }}></View>
                                    </View>
                                    
                            </View>
                  ))}
                 
                 
            </View>  
                    :
                    null}
                  
                    <View style={{ height: 20 }}></View>
                    {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        <Text style={{fontSize:15,color:'#395168',alignSelf:'center',marginTop:'-10%'}}>Not Found Upcoming Data</Text>
                        <Text style={{fontSize:17,color:'#395168',alignSelf:'center',marginTop:'10%'}}>Not Found History Data</Text>
                    </View>
                    : null}
                    <Text style={{ marginTop: 10, fontSize: 25, color: 'black' }}>
                        {t('Appointment History')}
                    </Text>
                    <View style={{ height: 20 }}></View>
                    {history?
                    <View>
                         {history.map((his, index) => (
                    <View style={{ backgroundColor: '#fafafd', borderRadius: 20, borderWidth: 1, borderColor: '#1a334c' ,marginBottom:10,height:100,height:110}}>

                                    <View key={index}>
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10,margin:3 }} source={require('../../../image/carap.png')} />
                                        </View>
                                        <View style={{ width: '70%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.message}</Text>
                                        </View>
                                        {/* <TouchableOpacity style={{ width: '10%' }}  onPress={()=>selectpop2(his)}  >
                                            <Image style={{ height: 20, width: 8 ,marginTop:10}} source={require('../../../image/dots.png')} />
                                        </TouchableOpacity> */}
                                    </View>
                                   
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10,margin:3 }} source={require('../../../image/calapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.date}</Text>
                                        </View>
                                    </View>
                                   
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10 ,margin:3}} source={require('../../../image/toolapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.service_type}</Text>
                                        </View>
                                    </View>
                                    </View>
                               </View>    
                         ))}
                         </View>
                 
                    :null}
                    </View>
// **************************************************************************************************
                   :
                   <View>
                    {upcomming?
                    <View>
                 {upcomming.map((up, index) => (
                    <View key={index}>
                           
                                    <View style={{ backgroundColor: '#b3c5d9', borderRadius: 20 ,margin:5}}>
                                        <View style={{ height: 20 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                                            </View>
                                            <View style={{ width: '70%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{t(up.message)}</Text>
                                            </View>
                                            {/* <TouchableOpacity style={{ width: '10%' }} onPress={()=>navigation.navigate('Reschle',up)}  > */}
                                            <TouchableOpacity style={{ width: '10%' }} onPress={()=>selectpop(up)}  >
                                                <Image style={{ height: 20, width: 8 }} source={require('../../../image/dotapp.png')} />
                                            </TouchableOpacity>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.date}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clockapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.time}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.service_type}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 15 }}></View>
                                    </View>
                                    
                            </View>
                  ))}
                 
                 
            </View>  
                    :
                    null}

                   </View>
                   }
                    <View style={{ height: 20 }}></View>
                   
                    <View style={{ height: 20 }}></View>
                    {utype!='2'?
                    <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Newappm')}>
                        <Text style={styles.btninner}>
                            {t('Add New Appointment')}
                        </Text>
                    </TouchableOpacity>
                    :null}
                    <View style={{ height: 40 }}></View>
                </View>
                <View>
                    <Modal isVisible={isModalVisible}>
                        <View style={{ flex: 0, alignItems: 'center', backgroundColor: 'white', padding: 6,height:'20%',width:200,marginLeft:100}}>
                            
                            <View style={{  width: 170 ,marginTop:10,borderColor:'#cccccc',borderWidth:0}}>
                                <TouchableOpacity style={{borderWidth:0,margin:2,borderBottomWidth:1,borderColor:'#cccccc',marginBottom:10}} onPress={rest}>
                                    <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{t('Reschedule')}</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={{borderWidth:0,borderBottomWidth:1,borderColor:'#cccccc',margin:3,marginBottom:10}}  onPress={deletes}>
                                <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{t('Delete')}</Text>

                                </TouchableOpacity>
                                <TouchableOpacity style={{borderWidth:0,margin:2,borderBottomWidth:1,borderColor:'#cccccc'}}  onPress={cancel}>
                                <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{t('Cancel')}</Text>

                                </TouchableOpacity>
                            </View>
                           
                                    
                            
                        </View>
                        
                    </Modal>
                </View>
                <View>
                    <Modal isVisible={isModalVisible2}>
                        <View style={{ flex: 0, alignItems: 'center', backgroundColor: 'white', padding: 6,height:'16%',width:200,marginLeft:100}}>
                            
                            <View style={{  width: 170 ,marginTop:10,borderColor:'#cccccc',borderWidth:0}}>
                              
                                <TouchableOpacity style={{borderWidth:0,borderBottomWidth:1,borderColor:'#cccccc',margin:3,marginBottom:10}}  onPress={deletes}>
                                <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{t('Delete')}</Text>

                                </TouchableOpacity>
                                <TouchableOpacity style={{borderWidth:0,margin:2,borderBottomWidth:1,borderColor:'#cccccc'}}  onPress={cancel}>
                                <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{t('Cancel')}</Text>

                                </TouchableOpacity>
                            </View>
                           
                                    
                            
                        </View>
                        
                    </Modal>
                </View>
            </ScrollView>
        </View>
    );
};