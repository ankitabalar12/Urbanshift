import React, { useState, useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';

export default function Changepass({ navigation }) {
    const [oldpassword, setOldPassword] = useState('');
    const [newpassword, setNewPassword] = useState('');
    const [password, setPassword] = useState('');
    const [passwordVisibility, setPasswordVisibility] = useState(true);
    const [newpasswordVisibility, setNewPasswordVisibility] = useState(true);
    const [oldpasswordVisibility, setOldPasswordVisibility] = useState(true);
    const [submitted, setsubmitted] = useState(false)
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    useEffect(() => {
        async function fetchData() {
            const result = await AsyncStorage.getItem('lunguage');
            changeLanguage(result)
        }
        fetchData();
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const handlePasswordVisibility = () => {
        setPasswordVisibility(!passwordVisibility);
    };
    const handleNewPasswordVisibility = () => {
        setNewPasswordVisibility(!newpasswordVisibility);
    };
    const handleOldPasswordVisibility = () => {
        setOldPasswordVisibility(!oldpasswordVisibility);
    };
    const update = async () => {
        setsubmitted(true)

        if (oldpassword != '' && newpassword != '' && password != '' && newpassword === password) {
            const result = await AsyncStorage.getItem('QasLogin')
            const screenData = JSON.parse(result)

            fetch(global.url + 'changepassword.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: screenData.id,
                    new_password: newpassword,
                    old_password: oldpassword
                }),
            })

                .then((res) => res.json())
                .then((json) => {

                    if (json.ResponseCode == '1') {
                    } else {
                        alert(json.ResponseMsg)
                    }

                })
                .catch((err) => {
                });

        }
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} />
                    </TouchableOpacity>
                    <View style={{ height: 15 }}></View>
                    <Text style={{ fontSize: 25, color: 'black' }}>{t('Change Password')}</Text>
                    <View style={{ height: 10 }}></View>
                    <Text style={{ textAlign: 'left', color: '#8a97a4', fontSize: 18 }}>{t('Enter your old and new Password below')}</Text>
                    <View style={{ height: 20 }}></View>
                    <Text style={{ fontSize: 18, color: 'black', marginBottom: 15 }}>{t('Old Password')}</Text>
                    <View style={styles.showinput}>
                        <Image style={styles.ficon} source={require('../../../image/pass.png')} />
                        <TextInput
                            style={styles.textInput}
                            name="password"
                            placeholder="Enter password"
                            autoCapitalize="none"
                            autoCorrect={false}
                            textContentType="newPassword"
                            secureTextEntry={oldpasswordVisibility}
                            value={oldpassword}
                            enablesReturnKeyAutomatically
                            onChangeText={value => setOldPassword(value)}
                        />
                        <TouchableOpacity onPress={() => handleOldPasswordVisibility()}>
                            {oldpasswordVisibility == true ?
                                <Ionicons name="eye-off-outline" size={25} style={{ margin: 6 }} />
                                :
                                <Ionicons name="eye" size={25} style={{ margin: 6 }} />
                            }
                        </TouchableOpacity>
                    </View>
                    {oldpassword === '' && submitted ? <Text style={styles.validate}>{t('Please enter old password')} </Text> : null}
                    <View style={{ height: 10 }}></View>
                    <Text style={{ fontSize: 18, color: 'black', marginBottom: 15 }}>{t('New Password')}</Text>
                    <View style={styles.showinput}>
                        <Image style={styles.ficon} source={require('../../../image/pass.png')} />
                        <TextInput
                            style={styles.textInput}
                            name="password"
                            placeholder="Enter password"
                            autoCapitalize="none"
                            autoCorrect={false}
                            textContentType="newPassword"
                            secureTextEntry={newpasswordVisibility}
                            value={newpassword}
                            enablesReturnKeyAutomatically
                            onChangeText={value => setNewPassword(value)}
                        />
                        <TouchableOpacity onPress={() => handleNewPasswordVisibility()}>
                            {newpasswordVisibility == true ?
                                <Ionicons name="eye-off-outline" size={25} style={{ margin: 6 }} />
                                :
                                <Ionicons name="eye" size={25} style={{ margin: 6 }} />
                            }
                        </TouchableOpacity>
                    </View>
                    {newpassword === '' && submitted ? <Text style={styles.validate}>{t('Please enter newpassword')}</Text> : null}
                    <View style={{ height: 10 }}></View>
                    <Text style={{ fontSize: 18, color: 'black', marginBottom: 15 }}>{t('Confirm New Password')}</Text>
                    <View style={styles.showinput}>
                        <Image style={styles.ficon} source={require('../../../image/pass.png')} />
                        <TextInput
                            style={styles.textInput}
                            name="password"
                            placeholder="Enter password"
                            autoCapitalize="none"
                            autoCorrect={false}
                            textContentType="newPassword"
                            secureTextEntry={passwordVisibility}
                            value={password}
                            enablesReturnKeyAutomatically
                            onChangeText={value => setPassword(value)}
                        />
                        <TouchableOpacity onPress={() => handlePasswordVisibility()}>
                            {passwordVisibility == true ?
                                <Ionicons name="eye-off-outline" size={25} style={{ margin: 6 }} />
                                :
                                <Ionicons name="eye" size={25} style={{ margin: 6 }} />
                            }
                        </TouchableOpacity>
                    </View>
                    {password === '' && submitted || password != newpassword && submitted ? <Text style={styles.validate}>{t('Please enter valid confirm password')}</Text> : null}
                    <View style={{ height: 20 }}></View>
                    <TouchableOpacity style={styles.btn} onPress={update}>
                        <Text style={styles.btninner}>
                            {t('Reset Password')}
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>

    );
}
