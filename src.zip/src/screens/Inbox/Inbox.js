import React, { useState,useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image,StatusBar,ActivityIndicator } from 'react-native';
import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
export default function Inbox({ navigation }) {
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [loading, setLoading] = useState(false);
    const [inboxdata, setinboxdata] = useState('');
    const [Value, setValue] = useState('');
 useEffect(() => {

        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            //console.log('type== => ', typee);
            selectlan(typee)
            notification();
        }
        fetchData();
    }, [])

            const notification =async()=>{
                const result = await AsyncStorage.getItem('QasLogin')
                const screenData = JSON.parse(result)
               setLoading(true)
                fetch(global.url+'getnotification.php', {
                    method: 'POST',
                    headers: {
                        Accept: 'application/json',
                        'Content-type': 'application/json',
                    },
                    body:JSON.stringify({
                        user_id:screenData.id ,
                        
                       }),
                }).then((res) => res.json())
                    .then(async(json) => {
                     
                        if (json.ResponseCode == '1' && json.data!==null){
                        //console.log('json>>>',json)
                            setinboxdata(json.data)
                            const words = json.data;
                     
                            const final = words.length;//3 
                            //console.log('****final',final)
                            await AsyncStorage.setItem('Notification', JSON.stringify(final));
                            setLoading(false)
                        }else{
                            setLoading(false)
                        }
                      })
                    .catch((err) => {
                        //console.log(err)
                    })
                    setLoading(false)
                   
            }
const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
      

    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
            <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height:20 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="chevron-back" size={35}  style={{color:'black',marginLeft:-10}}/>
                    </TouchableOpacity>
                    <View style={{ height: 30 }}></View>
                    <Text style={{ fontSize: 25, color: 'black', fontWeight: 'bold' }}>{t('Inbox')}</Text>
                    <View style={{ height: 30 }}></View>
                    <View style={{ height: 10 }}></View>
                   
                    {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        {/* <Text style={{fontSize:17,color:'#395168',alignSelf:'center',marginTop:'10%'}}>Not Found Inbox Data</Text> */}
                    </View>
                    : null}
                    <View style={{ height: 15 }}></View>
                    {inboxdata?
                  <View>
                         {inboxdata.map((up, index) => (
                             <View key={index} style={{ width: '100%', flexDirection: 'row' ,marginBottom:5}}>
                             <View style={{ width: '20%' }}>
                                 <Image style={styles.ficon} source={require('../../../image/persons.png')} />
                             </View>
                             <View style={{ width: '80%' ,paddingTop:8}}>
                                 <Text style={{fontSize:15,color:'black'}}>{up.message}</Text>
                                 <Text style={{fontSize:12}}>{up.created_date}</Text>
                             </View>
                             </View>
                         ))}
                    </View>
                    :   
                     <Text style={{fontSize:20,alignSelf:'center'}}>{t('Your inbox is empty.')}</Text>
                }

                </View>
            </ScrollView>
        </View>
    );
};