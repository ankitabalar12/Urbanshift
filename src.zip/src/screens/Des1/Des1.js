import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    SafeAreaView
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import RadioGroup from "react-native-radio-buttons-group/lib/RadioGroup";
const Des1 = ({ navigation, route }) => {
    const [click, setClick] = useState(0)
    const [select, setSelect] = useState(0);
    const [selectdone, setSelectdone] = useState(1);
    const [desc, setdesc] = useState([]);
    const [req, setreq] = useState([]);
    const [Remark, setremark] = useState([]);
    const [data, setData] = useState('');
    const [done, setdone] = useState([]);
    const [fr, set0] = useState('');
    const [Two, set1] = useState('');
    const [Three, set2] = useState('');
    const [Four, set3] = useState('');
    const [five, set4] = useState('');
    const [six, set5] = useState('');
    const [Seven, set6] = useState('');
    const [Eight, set7] = useState('');
    const [Nine, set8] = useState('');
    const [Ten, set9] = useState('');
    const [Eleven, set10] = useState('');
    const [Twelve, set11] = useState('');
    const [Thirteen, set12] = useState('');
    const [Fourteen, set13] = useState('');
    const [Fifteen, set14] = useState('');
    const [Sixteen, set15] = useState('');
    const [Seventeen, set16] = useState('');
    const [Eighteen, set17] = useState('');
    const [Nineteen, set18] = useState('');
    const [Twenty, set19] = useState('');
    const [Twentyone, set20] = useState('');
    const [Twentytwo, set21] = useState('');
    const [Twentythree, set22] = useState('');
    const [Twentyfour, set23] = useState('');
    const [Twentyfive, set24] = useState('');
    const [Twentysix, set25] = useState('');
    const [Twentyseven, set26] = useState('');
    const [Twentyeight, set27] = useState('');
    const [Twentynine, set28] = useState('');
    const [Thirty, set29] = useState('');
    const [Thirtyone, set30] = useState('');
    const [Thirtytwo, set31] = useState('');
    const [Thirtythree, set32] = useState('');
    const [Thirtyfour, set33] = useState('');
    const Repairarray = route.params
    useEffect(() => {
        const Repairarray = route.params
        const screenData = JSON.parse(Repairarray);
        var data = screenData.map(function (item) {
            return {
                key: item.id,
                label: item.name
            };
        });
        for (var i = 0; i < data[13].label.length; i++) {
            var radioName = 'set' + data[13].label[i];
            if (radioName == 'set0') {
                set0(1);
            }
            if (radioName == 'set1') {
                set1(1);
 }
            if (radioName == 'set2') {
                set2(1);
            }
            if (radioName == 'set3') {
                set3(1);
            }
            if (radioName == 'set4') {
                set4(1);
            }
            if (radioName == 'set5') {
                set5(1);
            }
            if (radioName == 'set6') {
                set6(1);
            }
            if (radioName == 'set7') {
                set7(1);
            }
            if (radioName == 'set8') {
                set8(1);
            }
            if (radioName == 'set9') {
                set9(1);
            }
            if (radioName == 'set10') {
                set10(1);
            }
            if (radioName == 'set11') {
                set11(1);
            }
            if (radioName == 'set12') {
                set12(1);
            }

            if (radioName == 'set13') {
                set13(1);
            }
            if (radioName == 'set14') {
                set14(1);
            }
            if (radioName == 'set15') {
                set15(1);
            }

            if (radioName == 'set16') {
                set16(1);
            }
            if (radioName == 'set17') {
                set17(1);
            }
            if (radioName == 'set18') {
                set18(1);
            }
            if (radioName == 'set19') {
                set19(1);
            }
            if (radioName == 'set20') {
                set20(1);
            }
            if (radioName == 'set21') {
                set21(1);
            }
            if (radioName == 'set22') {
                set22(1);
            }
            if (radioName == 'set23') {
                set23(1);
            }
            if (radioName == 'set24') {
                set24(1);
            }
            if (radioName == 'set25') {
                set25(1);
            }
            if (radioName == 'set26') {
                set26(1);
            }
            if (radioName == 'set27') {
                set27(1);
            }
            if (radioName == 'set28') {
                set28(1);
            }
            if (radioName == 'set29') {
                set29(1);
            }
            if (radioName == 'set30') {
                set30(1);
            }
            if (radioName == 'set31') {
                set31(1);
            }
            if (radioName == 'set33') {
                set33(1);
            }
        }
        const inspection = route.params
    })
const setremarkvalue = (val) => {
        Remark.push(val);
    }
desc.push('Inspection')
    desc.push('Servicing')
    desc.push('Air Filter')
    desc.push('Fule Filetr')
    desc.push('Wiper')
    desc.push('AdBlue/Gear oil')
    desc.push('Bulb')
    desc.push('Aircon Filter')
    desc.push('Ac compressorr')
    desc.push('Ac Condensorr')
    desc.push('Ac Gas/Comp oil')
    desc.push('Battery')
    desc.push('Type/Patch Type')
    desc.push('Type Alignment')
    desc.push('Brake Pad/Disc/oil')
    desc.push('Started/Altetnator')
    desc.push('Clutch')
    desc.push('Radiator')
    desc.push('Belting')
    desc.push('Power Window/Mirror')
    desc.push('Windscreen')
    desc.push('panel Beating')
    desc.push('Wiring/Accessories')
    desc.push('Partition/Box')
    desc.push('Camera/SD Card')
    desc.push('Ventilator')
    desc.push('Polic/Spray paint')
    desc.push('Logo')
    desc.push('Others')
   const [radioButtons, setRadioButtons] = useState([
        {
            id: '1',
            selected: true,
           containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,

                paddingLeft: 15,
                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton(radioButtonsArray) {
        setRadioButtons(radioButtonsArray);
        var id =0
        req.push(id)
      }
    const [radioButtonss, setRadioButtonss] = useState([
        {
            id: '1',
           containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,

                paddingLeft: 15,
                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButtons(radioButtonsArray) {
        setRadioButtonss(radioButtonsArray);
        var id =0
        req.push(id)
      }

    const [radioButtons35, setRadioButtons35] = useState([
        {
            id: '2',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton35(radioButtonsArray) {
        setRadioButtons35(radioButtonsArray);
 done.push(selectdone)
}
    const [radioButtons2, setRadioButtons2] = useState([
        {
            id: '3',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton2(radioButtonsArray) {
        setRadioButtons2(radioButtonsArray);
        var id =1
        req.push(id)
     
        //console.log('selected  req value', req)
    }

    const [radioButtons2s, setRadioButtons2s] = useState([
        {
            id: '3',
            
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton2s(radioButtonsArray) {
        setRadioButtons2s(radioButtonsArray);
        var id =1
        req.push(id)
     
        //console.log('selected  req value', req)
    }
    const [radioButtons36, setRadioButtons36] = useState([
        {
            id: '4',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton36(radioButtonsArray) {
        setRadioButtons36(radioButtonsArray);

        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons3, setRadioButtons3] = useState([
        {
            id: '5',
            selected:true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton3(radioButtonsArray) {
        setRadioButtons3(radioButtonsArray);
        var id =2
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons3s, setRadioButtons3s] = useState([
        {
            id: '5',
          
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton3s(radioButtonsArray) {
        setRadioButtons3s(radioButtonsArray);
        var id =2
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons37, setRadioButtons37] = useState([
        {
            id: '6',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton37(radioButtonsArray) {
        setRadioButtons37(radioButtonsArray);
        var id =3
        done.push(id)
        //console.log('selected value', done)
    }
    const [radioButtons4, setRadioButtons4] = useState([
        {
            id: '7',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton4(radioButtonsArray) {
        setRadioButtons4(radioButtonsArray);
        var id =3
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons4s, setRadioButtons4s] = useState([
        {
            id: '7',
          
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton4s(radioButtonsArray) {
        setRadioButtons4s(radioButtonsArray);
        var id =3
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons38, setRadioButtons38] = useState([
        {
            id: '8',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton38(radioButtonsArray) {
        setRadioButtons38(radioButtonsArray);

        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons5, setRadioButtons5] = useState([
        {
            id: '9',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton5(radioButtonsArray) {
        setRadioButtons5(radioButtonsArray);
        var id =4
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons5s, setRadioButtons5s] = useState([
        {
            id: '9',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton5s(radioButtonsArray) {
        setRadioButtons5s(radioButtonsArray);
        var id =4
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons39, setRadioButtons39] = useState([
        {
            id: '10',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton39(radioButtonsArray) {
        setRadioButtons39(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons6, setRadioButtons6] = useState([
        {
            id: '11',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton6(radioButtonsArray) {
        setRadioButtons6(radioButtonsArray);
        var id =5
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons6s, setRadioButtons6s] = useState([
        {
            id: '11',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton6s(radioButtonsArray) {
        setRadioButtons6s(radioButtonsArray);
        var id =5
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons40, setRadioButtons40] = useState([
        {
            id: '12',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton40(radioButtonsArray) {
        setRadioButtons40(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons7, setRadioButtons7] = useState([
        {
            id: '13',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton7(radioButtonsArray) {
        setRadioButtons7(radioButtonsArray);
        var id =6
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons7s, setRadioButtons7s] = useState([
        {
            id: '13',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton7s(radioButtonsArray) {
        setRadioButtons7s(radioButtonsArray);
        var id =6
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons41, setRadioButtons41] = useState([
        {
            id: '14',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton41(radioButtonsArray) {
        setRadioButtons41(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons8, setRadioButtons8] = useState([
        {
            id: '15',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton8(radioButtonsArray) {
        setRadioButtons8(radioButtonsArray);
        var id =7
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons8s, setRadioButtons8s] = useState([
        {
            id: '15',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton8s(radioButtonsArray) {
        setRadioButtons8s(radioButtonsArray);
        var id =7
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons42, setRadioButtons42] = useState([
        {
            id: '16',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton42(radioButtonsArray) {
        setRadioButtons42(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons9, setRadioButtons9] = useState([
        {
            id: '17',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton9(radioButtonsArray) {
        setRadioButtons9(radioButtonsArray);
        var id =8
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons9s, setRadioButtons9s] = useState([
        {
            id: '17',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton9s(radioButtonsArray) {
        setRadioButtons9s(radioButtonsArray);
        var id =8
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons43, setRadioButtons43] = useState([
        {
            id: '18',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton43(radioButtonsArray) {
        setRadioButtons43(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons10, setRadioButtons10] = useState([
        {
            id: '19',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton10(radioButtonsArray) {
        setRadioButtons10(radioButtonsArray);
        var id =9
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons10s, setRadioButtons10s] = useState([
        {
            id: '19',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton10s(radioButtonsArray) {
        setRadioButtons10s(radioButtonsArray);
        var id =9
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons44, setRadioButtons44] = useState([
        {
            id: '20',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton44(radioButtonsArray) {
        setRadioButtons44(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons11, setRadioButtons11] = useState([
        {
            id: '21',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton11(radioButtonsArray) {
        setRadioButtons11(radioButtonsArray);
        var id =10
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons11s, setRadioButtons11s] = useState([
        {
            id: '21',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'  
        },

    ])
    function onPressRadioButton11s(radioButtonsArray) {
        setRadioButtons11s(radioButtonsArray);
        var id =10
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons45, setRadioButtons45] = useState([
        {
            id: '22',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton45(radioButtonsArray) {
        setRadioButtons45(radioButtonsArray);
        
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons12, setRadioButtons12] = useState([
        {
            id: '23',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton12(radioButtonsArray) {
        setRadioButtons12(radioButtonsArray);
        var id =11
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons12s, setRadioButtons12s] = useState([
        {
            id: '23',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton12s(radioButtonsArray) {
        setRadioButtons12s(radioButtonsArray);
        var id =11
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons46, setRadioButtons46] = useState([
        {
            id: '24',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton46(radioButtonsArray) {
        setRadioButtons46(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons13, setRadioButtons13] = useState([
        {
            id: '25',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton13(radioButtonsArray) {
        setRadioButtons13(radioButtonsArray);
        var id =12

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons13s, setRadioButtons13s] = useState([
        {
            id: '25',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton13s(radioButtonsArray) {
        setRadioButtons13s(radioButtonsArray);
        var id =12

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons47, setRadioButtons47] = useState([
        {
            id: '26',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton47(radioButtonsArray) {
        setRadioButtons47(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons14, setRadioButtons14] = useState([
        {
            id: '27',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton14(radioButtonsArray) {
        setRadioButtons14(radioButtonsArray);
        var id =13

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons14s, setRadioButtons14s] = useState([
        {
            id: '27',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton14s(radioButtonsArray) {
        setRadioButtons14s(radioButtonsArray);
        var id =13

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons48, setRadioButtons48] = useState([
        {
            id: '28',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton48(radioButtonsArray) {
        setRadioButtons48(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons15, setRadioButtons15] = useState([
        {
            id: '29',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton15(radioButtonsArray) {
        setRadioButtons15(radioButtonsArray);
        var id =14

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons15s, setRadioButtons15s] = useState([
        {
            id: '29',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton15s(radioButtonsArray) {
        setRadioButtons15s(radioButtonsArray);
        var id =14

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons49, setRadioButtons49] = useState([
        {
            id: '30',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton49(radioButtonsArray) {
        setRadioButtons49(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons16, setRadioButtons16] = useState([
        {
            id: '31',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton16(radioButtonsArray) {
        setRadioButtons16(radioButtonsArray);
        var id =15
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons16s, setRadioButtons16s] = useState([
        {
            id: '31',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton16s(radioButtonsArray) {
        setRadioButtons16s(radioButtonsArray);
        var id =15
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons50, setRadioButtons50] = useState([
        {
            id: '32',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton50(radioButtonsArray) {
        setRadioButtons50(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons17, setRadioButtons17] = useState([
        {
            id: '33',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton17(radioButtonsArray) {
        setRadioButtons17(radioButtonsArray);
        var id =16
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons17s, setRadioButtons17s] = useState([
        {
            id: '33',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton17s(radioButtonsArray) {
        setRadioButtons17s(radioButtonsArray);
        var id =16
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons51, setRadioButtons51] = useState([
        {
            id: '34',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton51(radioButtonsArray) {
        setRadioButtons51(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons18, setRadioButtons18] = useState([
        {
            id: '35',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton18(radioButtonsArray) {
        setRadioButtons18(radioButtonsArray);
        var id =17
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons18s, setRadioButtons18s] = useState([
        {
            id: '35',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton18s(radioButtonsArray) {
        setRadioButtons18s(radioButtonsArray);
        var id =17
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons52, setRadioButtons52] = useState([
        {
            id: '36',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton52(radioButtonsArray) {
        setRadioButtons52(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons19, setRadioButtons19] = useState([
        {
            id: '37',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton19(radioButtonsArray) {
        setRadioButtons19(radioButtonsArray);
        var id =18

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons19s, setRadioButtons19s] = useState([
        {
            id: '37',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton19s(radioButtonsArray) {
        setRadioButtons19s(radioButtonsArray);
        var id =18

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons53, setRadioButtons53] = useState([
        {
            id: '38',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton53(radioButtonsArray) {
        setRadioButtons53(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons20, setRadioButtons20] = useState([
        {
            id: '39',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton20(radioButtonsArray) {
        setRadioButtons20(radioButtonsArray);
        var id =19

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons20s, setRadioButtons20s] = useState([
        {
            id: '39',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton20s(radioButtonsArray) {
        setRadioButtons20s(radioButtonsArray);
        var id =19

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons54, setRadioButtons54] = useState([
        {
            id: '40',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton54(radioButtonsArray) {
        setRadioButtons54(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons21, setRadioButtons21] = useState([
        {
            id: '41',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton21(radioButtonsArray) {
        setRadioButtons21(radioButtonsArray);
        var id =20
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons21s, setRadioButtons21s] = useState([
        {
            id: '41',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton21s(radioButtonsArray) {
        setRadioButtons21s(radioButtonsArray);
        var id =20
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons55, setRadioButtons55] = useState([
        {
            id: '42',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton55(radioButtonsArray) {
        setRadioButtons55(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons22, setRadioButtons22] = useState([
        {
            id: '43',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton22(radioButtonsArray) {
        setRadioButtons22(radioButtonsArray);
        var id =21

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons22s, setRadioButtons22s] = useState([
        {
            id: '43',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton22s(radioButtonsArray) {
        setRadioButtons22s(radioButtonsArray);
        var id =21

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons56, setRadioButtons56] = useState([
        {
            id: '44',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton56(radioButtonsArray) {
        setRadioButtons56(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons23, setRadioButtons23] = useState([
        {
            id: '45',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton23(radioButtonsArray) {
        setRadioButtons23(radioButtonsArray);
        var id =22

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons23s, setRadioButtons23s] = useState([
        {
            id: '45',
          
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton23s(radioButtonsArray) {
        setRadioButtons23s(radioButtonsArray);
        var id =22

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons57, setRadioButtons57] = useState([
        {
            id: '46',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton57(radioButtonsArray) {
        setRadioButtons57(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons24, setRadioButtons24] = useState([
        {
            id: '47',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton24(radioButtonsArray) {
        setRadioButtons24(radioButtonsArray);
        var id =23

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons24s, setRadioButtons24s] = useState([
        {
            id: '47',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton24s(radioButtonsArray) {
        setRadioButtons24s(radioButtonsArray);
        var id =23

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons58, setRadioButtons58] = useState([
        {
            id: '48',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton58(radioButtonsArray) {
        setRadioButtons58(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons25, setRadioButtons25] = useState([
        {
            id: '49',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton25(radioButtonsArray) {
        setRadioButtons25(radioButtonsArray);
        var id =24
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons25s, setRadioButtons25s] = useState([
        {
            id: '49',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton25s(radioButtonsArray) {
        setRadioButtons25s(radioButtonsArray);
        var id =24
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons59, setRadioButtons59] = useState([
        {
            id: '50',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton59(radioButtonsArray) {
        setRadioButtons59(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons26, setRadioButtons26] = useState([
        {
            id: '51',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton26(radioButtonsArray) {
        setRadioButtons26(radioButtonsArray);
        var id =25

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons26s, setRadioButtons26s] = useState([
        {
            id: '51',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton26s(radioButtonsArray) {
        setRadioButtons26s(radioButtonsArray);
        var id =25

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons60, setRadioButtons60] = useState([
        {
            id: '52',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton60(radioButtonsArray) {
        setRadioButtons60(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons27, setRadioButtons27] = useState([
        {
            id: '53',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton27(radioButtonsArray) {
        setRadioButtons27(radioButtonsArray);
        var id =26

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons27s, setRadioButtons27s] = useState([
        {
            id: '53',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton27s(radioButtonsArray) {
        setRadioButtons27s(radioButtonsArray);
        var id =26

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons61, setRadioButtons61] = useState([
        {
            id: '54',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton61(radioButtonsArray) {
        setRadioButtons61(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons28, setRadioButtons28] = useState([
        {
            id: '55',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton28(radioButtonsArray) {
        setRadioButtons28(radioButtonsArray);
        var id =27
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons28s, setRadioButtons28s] = useState([
        {
            id: '55',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton28s(radioButtonsArray) {
        setRadioButtons28s(radioButtonsArray);
        var id =27
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons62, setRadioButtons62] = useState([
        {
            id: '56',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton62(radioButtonsArray) {
        setRadioButtons62(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons29, setRadioButtons29] = useState([
        {
            id: '57',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton29(radioButtonsArray) {
        setRadioButtons29(radioButtonsArray);
        var id =28
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons29s, setRadioButtons29s] = useState([
        {
            id: '57',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton29s(radioButtonsArray) {
        setRadioButtons29s(radioButtonsArray);
        var id =28
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons63, setRadioButtons63] = useState([
        {
            id: '58',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton63(radioButtonsArray) {
        setRadioButtons63(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons30, setRadioButtons30] = useState([
        {
            id: '59',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton30(radioButtonsArray) {
        setRadioButtons30(radioButtonsArray);
        var id =29
        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons30s, setRadioButtons30s] = useState([
        {
            id: '59',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton30s(radioButtonsArray) {
        setRadioButtons30s(radioButtonsArray);
        var id =29
        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons64, setRadioButtons64] = useState([
        {
            id: '60',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton64(radioButtonsArray) {
        setRadioButtons64(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons31, setRadioButtons31] = useState([
        {
            id: '61',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton31(radioButtonsArray) {
        setRadioButtons31(radioButtonsArray);
        var id =30

        req.push(id)
        //console.log('selected value', req)
    }

    const [radioButtons31s, setRadioButtons31s] = useState([
        {
            id: '61',
           
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton31s(radioButtonsArray) {
        setRadioButtons31s(radioButtonsArray);
        var id =30

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons65, setRadioButtons65] = useState([
        {
            id: '62',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton65(radioButtonsArray) {
        setRadioButtons65(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons32, setRadioButtons32] = useState([
        {
            id: '63',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton32(radioButtonsArray) {
        setRadioButtons32(radioButtonsArray);
        var id =31

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons32s, setRadioButtons32s] = useState([
        {
            id: '63',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton32s(radioButtonsArray) {
        setRadioButtons32s(radioButtonsArray);
        var id =31

        req.push(id)
        //console.log('selected value', req)
    }
    const [radioButtons66, setRadioButtons66] = useState([
        {
            id: '64',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton66(radioButtonsArray) {
        setRadioButtons66(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons33, setRadioButtons33] = useState([
        {
            id: '65',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton33(radioButtonsArray) {
        setRadioButtons33(radioButtonsArray);
        var id =32

        req.push(id)
        //console.log('selected value', req)
        setClick(1)
    }

    const [radioButtons33s, setRadioButtons33s] = useState([
        {
            id: '65',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton33s(radioButtonsArray) {
        setRadioButtons33s(radioButtonsArray);
        var id =32

        req.push(id)
        //console.log('selected value', req)
        setClick(1)
    }
    const [radioButtons67, setRadioButtons67] = useState([
        {
            id: '66',
            selected: true,
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton67(radioButtonsArray) {
        setRadioButtons67(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons67s, setRadioButtons67s] = useState([
        {
            id: '66',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton67s(radioButtonsArray) {
        setRadioButtons67s(radioButtonsArray);
        done.push(selectdone)
        //console.log('selected value', done)
    }
    const [radioButtons34, setRadioButtons34] = useState([
        {
            id: '67',
            selected: true,
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton34(radioButtonsArray) {
        setRadioButtons34(radioButtonsArray);
        var id =33

        req.push(id)
        //console.log('selected value', req)

    }

    const [radioButtons34s, setRadioButtons34s] = useState([
        {
            id: '67',
            containerStyle: {
                width: '50.5%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                paddingLeft: 15,
            },
            size: '15'
        },

    ])
    function onPressRadioButton34s(radioButtonsArray) {
        setRadioButtons34s(radioButtonsArray);
        var id =33

        req.push(id)
        //console.log('selected value', req)

    }
    const [radioButtons68, setRadioButtons68] = useState([
        {
            id: '68',
            disabled: true,
            // setSelect:'1',
            containerStyle: {
                width: '43%',
                height: 46,
                marginTop: 7,
                borderRightWidth: 1,
                fontSize: 16,
                color: '#000000',
                // right:10,
                marginLeft: '-42%',
                paddingLeft: 15,

                // borderWidth:1
            },
            size: '15'
        },

    ])
    function onPressRadioButton68(radioButtonsArray) {
        setRadioButtons68(radioButtonsArray);

        done.push(selectdone)
        //console.log('selected done value', done)
    }

    const alldata = {

        des: desc,
        requirement: req,
        done: done,
        rem: Remark,
        Repair: Repairarray


    }

    const passarray = () => {

        navigation.navigate('Ins', alldata)
        //console.log('allllllllllll dataa', alldata)
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#fafafd' }}>

            <View style={styles.maincontainer}>
                <ScrollView style={{ marginBottom: 15 }}>
                    <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                    <View style={{ margin: 30 }}>
                        <View style={{ height: 10 }}></View>
                        <TouchableOpacity onPress={() => navigation.goBack()}>
                            <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.btn} onPress={passarray} >
                            <Text style={styles.btninner}>
                                Next
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.hadding}>
                        <View style={styles.h1}><Text style={{ fontSize: 16, fontWeight: 'bold' }}>Description</Text></View>
                        <View style={styles.h2}><Text style={{ fontSize: 16, fontWeight: 'bold' }}>Req Attn</Text></View>
                        <View style={styles.h3}><Text style={{ fontSize: 16, fontWeight: 'bold' }}>Done</Text></View>
                        <View style={styles.h4}><Text style={{ fontSize: 16, fontWeight: 'bold' }}>Remarks</Text></View>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>1.Inspection</Text></View>
                        {fr == 1 ?

                        <RadioGroup

                            radioButtons={radioButtons}
                            onPress={onPressRadioButton}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        :
                        <RadioGroup

                            radioButtons={radioButtonss}
                            onPress={onPressRadioButtons}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        }
                        <RadioGroup

                            radioButtons={radioButtons35}
                            onPress={onPressRadioButton35}
                            layout='row'
                            containerStyle={styles.radiostyle}
                           
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>2.Servicing</Text></View>

                         {Two == 1 ?
                            <RadioGroup
                                radioButtons={radioButtons2}
                                onPress={onPressRadioButton2}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />
                            :
                            <RadioGroup
                                radioButtons={radioButtons2s}
                                onPress={onPressRadioButton2s}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />
                        }
                        <RadioGroup

                            radioButtons={radioButtons68}
                            onPress={onPressRadioButton68}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>3.Air Filter</Text></View>
                        {Three == 1 ?

                                <RadioGroup
                                    radioButtons={radioButtons3}
                                    onPress={onPressRadioButton3}
                                    layout='row'
                                    containerStyle={styles.radiostyle}
                                />
                                :
                                <RadioGroup
                                    radioButtons={radioButtons3s}
                                    onPress={onPressRadioButton3s}
                                    layout='row'
                                    containerStyle={styles.radiostyle}
                                />
                                }
                        <RadioGroup

                            radioButtons={radioButtons36}
                            onPress={onPressRadioButton36}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>4.Fule Filter</Text></View>
                        {Four == 1 ?

                            <RadioGroup
                                radioButtons={radioButtons4}
                                onPress={onPressRadioButton4}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />
                            :
                            <RadioGroup
                                radioButtons={radioButtons4s}
                                onPress={onPressRadioButton4s}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />
                            }
                        <RadioGroup

                            radioButtons={radioButtons37}
                            onPress={onPressRadioButton37}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>5.Wiper</Text></View>
                        {five == 1 ?

                        <RadioGroup
                            radioButtons={radioButtons5}
                            onPress={onPressRadioButton5}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        :
                        <RadioGroup
                            radioButtons={radioButtons5s}
                            onPress={onPressRadioButton5s}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />}
                        <RadioGroup

                            radioButtons={radioButtons38}
                            onPress={onPressRadioButton38}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>6.AdBlue/Gear oil</Text></View>
                        {six == 1 ?

                            <RadioGroup
                                radioButtons={radioButtons6}
                                onPress={onPressRadioButton6}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />
                            :
                            <RadioGroup
                                radioButtons={radioButtons6s}
                                onPress={onPressRadioButton6s}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />}
                        <RadioGroup

                            radioButtons={radioButtons39}
                            onPress={onPressRadioButton39}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>7.Bulb</Text></View>
                        {Seven == 1 ?

                            <RadioGroup
                                radioButtons={radioButtons7}
                                onPress={onPressRadioButton7}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />
                            :
                            <RadioGroup
                                radioButtons={radioButtons7s}
                                onPress={onPressRadioButton7s}
                                layout='row'
                                containerStyle={styles.radiostyle}
                            />}
                        <RadioGroup

                            radioButtons={radioButtons40}
                            onPress={onPressRadioButton40}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>8.Aircon Filter</Text></View>
                        {Eight == 1 ?

<RadioGroup
    radioButtons={radioButtons8}
    onPress={onPressRadioButton8}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons8s}
    onPress={onPressRadioButton8s}
    layout='row'
    containerStyle={styles.radiostyle}
/>
}
                        <RadioGroup

                            radioButtons={radioButtons41}
                            onPress={onPressRadioButton41}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>9.AC Compressorr</Text></View>
                        {Nine == 1 ?

<RadioGroup
    radioButtons={radioButtons9}
    onPress={onPressRadioButton9}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons9s}
    onPress={onPressRadioButton9s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons42}
                            onPress={onPressRadioButton42}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>10.AC Condensorr</Text></View>
                        {Ten == 1 ?

<RadioGroup
    radioButtons={radioButtons10}
    onPress={onPressRadioButton10}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons10s}
    onPress={onPressRadioButton10s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons43}
                            onPress={onPressRadioButton43}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>11.AC Gas/Comp Oil</Text></View>
                        {Eleven == 1 ?

<RadioGroup
    radioButtons={radioButtons11}
    onPress={onPressRadioButton11}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons11s}
    onPress={onPressRadioButton11s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons44}
                            onPress={onPressRadioButton44}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>12.Battery</Text></View>
                        {Twelve == 1 ?

<RadioGroup
    radioButtons={radioButtons12}
    onPress={onPressRadioButton12}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons12s}
    onPress={onPressRadioButton12s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons45}
                            onPress={onPressRadioButton45}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>13.Tyre/Patch Tyre</Text></View>
                        {Thirteen == 1 ?

<RadioGroup
    radioButtons={radioButtons13}
    onPress={onPressRadioButton13}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons13s}
    onPress={onPressRadioButton13s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons46}
                            onPress={onPressRadioButton46}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>

                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>14.Tyre Alignment</Text></View>
                        {Fourteen == 1 ?

<RadioGroup
    radioButtons={radioButtons14}
    onPress={onPressRadioButton14}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:

<RadioGroup
    radioButtons={radioButtons14s}
    onPress={onPressRadioButton14s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons47}
                            onPress={onPressRadioButton47}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>15.Brake Pad/Disc/Oil</Text></View>
                        {Fifteen == 1 ?

<RadioGroup
    radioButtons={radioButtons15}
    onPress={onPressRadioButton15}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons15s}
    onPress={onPressRadioButton15s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons48}
                            onPress={onPressRadioButton48}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>16.Started/Altetnator</Text></View>
                        {Sixteen == 1 ?

<RadioGroup
    radioButtons={radioButtons16}
    onPress={onPressRadioButton16}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons16s}
    onPress={onPressRadioButton16s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons49}
                            onPress={onPressRadioButton49}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>17.Clutch</Text></View>
                        {Seventeen == 1 ?

<RadioGroup
    radioButtons={radioButtons17}
    onPress={onPressRadioButton17}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons17s}
    onPress={onPressRadioButton17s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons50}
                            onPress={onPressRadioButton50}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text} >18.Radiator</Text></View>
                        {Eighteen == 1 ?

<RadioGroup
    radioButtons={radioButtons18}
    onPress={onPressRadioButton18}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons18s}
    onPress={onPressRadioButton18s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons51}
                            onPress={onPressRadioButton51}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text} >19.Belting</Text></View>
                        {Nineteen == 1 ?

<RadioGroup
    radioButtons={radioButtons19}
    onPress={onPressRadioButton19}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons19s}
    onPress={onPressRadioButton19s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons52}
                            onPress={onPressRadioButton52}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>20.Power Steering/Oil</Text></View>
                        {Twenty == 1 ?

<RadioGroup
    radioButtons={radioButtons20}
    onPress={onPressRadioButton20}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons20s}
    onPress={onPressRadioButton20s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons53}
                            onPress={onPressRadioButton53}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text} >21.Computer Reset</Text></View>
                        {Twentyone == 1 ?

<RadioGroup
    radioButtons={radioButtons21}
    onPress={onPressRadioButton21}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:

<RadioGroup
    radioButtons={radioButtons21s}
    onPress={onPressRadioButton21s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons54}
                            onPress={onPressRadioButton54}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>22.Horn</Text></View>
                        {Twentytwo == 1 ?

<RadioGroup
    radioButtons={radioButtons22}
    onPress={onPressRadioButton22}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons22s}
    onPress={onPressRadioButton22s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons55}
                            onPress={onPressRadioButton55}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>23.Centeral Oil/Door Lock</Text></View>
                        {Twentythree == 1 ?

<RadioGroup
    radioButtons={radioButtons23}
    onPress={onPressRadioButton23}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons23s}
    onPress={onPressRadioButton23s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons56}
                            onPress={onPressRadioButton56}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text} >24.Power Window/Mirror</Text></View>
                        {Twentyfour == 1 ?

<RadioGroup
    radioButtons={radioButtons24}
    onPress={onPressRadioButton24}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons24s}
    onPress={onPressRadioButton24s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons57}
                            onPress={onPressRadioButton57}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>25.Windscreen</Text></View>
                        {Twentyfive == 1 ?

<RadioGroup
    radioButtons={radioButtons25}
    onPress={onPressRadioButton25}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons25s}
    onPress={onPressRadioButton25s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons58}
                            onPress={onPressRadioButton58}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>26.panel Beating</Text></View>
                        {Twentysix == 1 ?

<RadioGroup
    radioButtons={radioButtons26}
    onPress={onPressRadioButton26}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons26s}
    onPress={onPressRadioButton26s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons59}
                            onPress={onPressRadioButton59}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>27.Wiring/Accessories</Text></View>
                        {Twentyseven == 1 ?

<RadioGroup
    radioButtons={radioButtons27}
    onPress={onPressRadioButton27}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons27s}
    onPress={onPressRadioButton27s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons60}
                            onPress={onPressRadioButton60}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text} >28.Partition/Box</Text></View>
                        {Twentyeight == 1 ?

<RadioGroup
    radioButtons={radioButtons28}
    onPress={onPressRadioButton28}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons28s}
    onPress={onPressRadioButton28s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons61}
                            onPress={onPressRadioButton61}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>29.Camera/SD Card</Text></View>
                        {Twentynine == 1 ?

<RadioGroup
    radioButtons={radioButtons29}
    onPress={onPressRadioButton29}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons29s}
    onPress={onPressRadioButton29s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons62}
                            onPress={onPressRadioButton62}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>30.Ventilator</Text></View>
                        {Thirty == 1 ?

<RadioGroup
    radioButtons={radioButtons30}
    onPress={onPressRadioButton30}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons30s}
    onPress={onPressRadioButton30s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons63}
                            onPress={onPressRadioButton63}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>31.Police/Spray Paint</Text></View>
                        {Thirtyone == 1 ?

<RadioGroup
    radioButtons={radioButtons31}
    onPress={onPressRadioButton31}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup
    radioButtons={radioButtons31s}
    onPress={onPressRadioButton31s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
                        <RadioGroup

                            radioButtons={radioButtons64}
                            onPress={onPressRadioButton64}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.f1}><Text style={styles.text}>32.Logo</Text></View>
                        {Thirtytwo == 1 ?

<RadioGroup

    radioButtons={radioButtons32}
    onPress={onPressRadioButton32}
    layout='row'
    containerStyle={styles.radiostyle}
/>
:
<RadioGroup

    radioButtons={radioButtons32s}
    onPress={onPressRadioButton32s}
    layout='row'
    containerStyle={styles.radiostyle}
/>
}
                        <RadioGroup

                            radioButtons={radioButtons65}
                            onPress={onPressRadioButton65}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                    </View>
                    <View style={styles.frow}>
                        <View style={styles.last}><Text style={styles.text}>33.Others</Text></View>
                        {Thirtythree == 1 ?

<RadioGroup
    radioButtons={radioButtons33}
    onPress={onPressRadioButton33}
    layout='row'
    containerStyle={styles.radiostyle}

/>
:
<RadioGroup
    radioButtons={radioButtons33s}
    onPress={onPressRadioButton33s}
    layout='row'
    containerStyle={styles.radiostyle}

/>}
                        <RadioGroup

                            radioButtons={radioButtons66}
                            onPress={onPressRadioButton66}
                            layout='row'
                            containerStyle={styles.radiostyle}
                        />
                        <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>

                    </View>
                    {click == '1' ?
                        <View style={styles.frow}>
                            <TextInput style={styles.f5}></TextInput>
                            {Thirtyfour == 1 ?

<RadioGroup
    radioButtons={radioButtons34}
    onPress={onPressRadioButton34}
    layout='row'
    containerStyle={styles.radiostyle}
/> :
<RadioGroup
    radioButtons={radioButtons34s}
    onPress={onPressRadioButton34s}
    layout='row'
    containerStyle={styles.radiostyle}
/>}
<RadioGroup

radioButtons={radioButtons67}
onPress={onPressRadioButton67}
layout='row'
containerStyle={styles.radiostyle}
/>
:
<RadioGroup

radioButtons={radioButtons67s}
onPress={onPressRadioButton67s}
layout='row'
containerStyle={styles.radiostyle}
/>
                            <TextInput onEndEditing={(event) => setremarkvalue(event.nativeEvent.text)} style={styles.f4}></TextInput>
                        </View>
                        :
                        null
                    }

                    <View style={{ borderWidth: 0, width: '100%', justifyContent: 'flex-end', flexDirection: 'row', marginTop: 10 }}>
                        <TouchableOpacity style={styles.btn1} onPress={passarray} >
                            <Text style={styles.btninner1}>
                                Next
                            </Text>
                        </TouchableOpacity>
                    </View>
                </ScrollView>
            </View>
        </SafeAreaView>
    )

}
export default Des1;