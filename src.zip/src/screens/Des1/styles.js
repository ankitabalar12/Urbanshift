import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    btn:{
        height:30,borderRadius:3,backgroundColor:'#346696',
        position:'absolute',
        width:'23%',
        right:'1%',
        top:'33%',
       
    },
    btninner:{
       color:'white',
       fontSize:18,
       fontWeight:'bold',
       alignSelf:'center',
       marginTop:3,

       position:'absolute',
    //    marginTop:1
    },
    hadding:{
                // borderWidth:1,
                marginLeft:'5%',
                marginRight:'5%',
                // flex:1,
                flexDirection:'row',
                paddingTop:'1%',
                borderBottomWidth:1
},
    h1:{
                // borderWidth:1,
                // margin:'2%',
                width:'38%',
                height:30,
                marginTop:10,
               borderRightWidth:1,
            //    borderBottomWidth:1,
            //    borderColor:'red',
                // fontSize:20,
                

                
    },
    h2:{
        width:'21%',
        height:30,
        marginTop:10,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:3,
        // marginRight:5
        // left:20
    },
    h3:{
        width:'15%',
        height:30,
        marginTop:10,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:6,
       
    },
    h4:{
        width:'22%',
        height:30,
        marginTop:10,
        // borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:5
    },
    frow:{
        flexDirection:'row',
        // paddingTop:'1%',
        borderBottomWidth:1,
        marginLeft:'5%',
        marginRight:'5%',
        // borderWidth:1,
        height:46


    },
    f1:{
        width:'38%',
        height:57,
        // marginTop:5,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        // borderWidth:1,
    //    paddingTop:'2%',
    //    paddingBottom:'2%'
    //    margin:'1%'
    },
    last:{
        width:'38%',
        height:47,
        // marginTop:5,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        // borderWidth:1,
       paddingTop:'2%'
    },
    text:{
        fontSize:16,  
        color:'#9e9ea7',   
       paddingTop:'2%'

    },
   
    
    f4:{
        width:'27%',
        height:46,
        // marginTop:10,
        // borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:5,
        // borderWidth:1,
        marginLeft:'-34%'
    },
    f5:{
        width:'38%',
        height:46,
        // marginTop:10,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:5,
        // borderWidth:1,
    },
    radiostyle:{
        // borderWidth:1,
        borderRightWidth:1,
        width:'36.6%',
        color:'#9e9ea7',   
        bordercolor:'#9e9ea7',

    },
    btn1:{
        height:30,
        borderRadius:3,
        backgroundColor:'#346696',
       marginRight:20,
        width:'20%',
        // borderWidth:1
      
       
    },
    btninner1:{
       color:'white',
       fontSize:18,
       fontWeight:'bold',
       marginTop:3,
    alignSelf:'center',
   
    //    borderWidth:1
   
    },
   
    
})