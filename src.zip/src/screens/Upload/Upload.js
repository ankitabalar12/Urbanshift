import React, { useState } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';


const Upload = ({ navigation }) => {
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />

                        {/* <Image style={styles.ficon} source={require('../../../image/back.png')} /> */}
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 20 }}>Appointment Details</Text>

                </View>
                <View>

                    <View style={{ backgroundColor: '#b3c5d9', borderRadius: 20, margin: 25, marginTop: 0 }}>
                        <View style={{ height: 20 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                            </View>
                            <View style={{ width: '70%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>Nissan E25 (GZ81X(Q))</Text>
                            </View>
                            {/* <TouchableOpacity style={{ width: '10%' }} onPress={()=>navigation.navigate('Reschle',up)}  > */}
                            {/* <TouchableOpacity style={{ width: '10%' }} onPress={()=>selectpop(up)}  >
                                                <Image style={{ height: 20, width: 8 }} source={require('../../../image/dotapp.png')} />
                                            </TouchableOpacity> */}
                        </View>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                            </View>
                            <View style={{ width: '80%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>30 March 2023</Text>
                            </View>
                        </View>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clockapp.png')} />
                            </View>
                            <View style={{ width: '80%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>10:00</Text>
                            </View>
                        </View>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                            <View style={{ width: '15%' }}>
                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                            </View>
                            <View style={{ width: '80%' }}>
                                <Text style={{ fontSize: 18, marginTop: 2, color: '#395168' }}>General Servicing</Text>
                            </View>
                        </View>
                        <View style={{ height: 15 }}></View>
                    </View>
                </View>
{/* **************************************************************************************************** */}
                <Text style={{ fontSize: 25, color: '#9b9ba7', fontWeight: 'bold' ,marginLeft:25}}>Customer Details</Text>
                <View style={{  borderRadius: 20 ,margin:5,marginTop:10}}>
                                        <View style={{ height: 20 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/pr.png')} />
                                            </View>
                                            <View style={{ width: '70%' }}>
                                                <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>Nissan E25 (GZ81X(Q))</Text>
                                            </View>
                                            {/* <TouchableOpacity style={{ width: '10%' }} onPress={()=>navigation.navigate('Reschle',up)}  > */}
                                           
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/mail.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>30 March 2023</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/phone.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>10:00</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/report.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 19, marginTop: 2, color: '#000000' }}>General Servicing</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 15 }}></View>
                                    </View>
        {/* ******************************************************************************************** */}

        <Text style={{ fontSize: 25, color: '#9b9ba7', fontWeight: 'bold' ,marginLeft:25}}>Full Car Details</Text>

        <View style={{ height: 15 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>License Plate</Text>
                    </View>

                    <View style={styles.view}>
                        <Text style={styles.sw1}>GZ81X(Q)</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>IU Number</Text>
                    </View>

                    <View style={styles.view}>
                        <Text style={styles.sw1}>1043446269</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Brand</Text>
                    </View>

                    <View style={styles.view}>
                        <Text style={styles.sw1}>Nissan</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Model</Text>
                    </View>



                    <View style={styles.view}>
                        <Text style={styles.sw1}>E25</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Road Tax Expiry</Text>
                    </View>



                    <View style={styles.view}>
                        <Text style={styles.sw1}>31 Aug 2023</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>COE Expiry</Text>
                    </View>


                    <View style={styles.view}>
                        <Text style={styles.sw1}>24 Oct 2025</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Inspection Due Date</Text>
                    </View>



                    <View style={styles.view}>
                        <Text style={styles.sw1}>15 Jun 2023</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Last Service Date</Text>
                    </View>



                    <View style={styles.view}>
                        <Text style={styles.sw1}>15 Dec 20233</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Chassis Number</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>JN1HG2E25Z0</Text>
                    </View>
                </View>


                <TouchableOpacity style={styles.btn} onPress={()=>{navigation.navigate('Repair',1)}} >
                        <Text style={styles.btninner}>
                          Upload Report
                        </Text>
                    </TouchableOpacity>
            </ScrollView>
        </View>
    )

}
export default Upload;