import React, { useState } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import FastImage from 'react-native-fast-image';
const Summary = ({ navigation }) => {
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 20, color: '#0d0d26', fontWeight: 'bold', marginTop: 10 }}>Summary Report</Text>
                </View>
                <View style={{ marginTop: -10 }}>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Vehicle Number</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>GZ81X(Q)</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Brand</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>Nissan</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Model</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>E25</Text>
                        </View>

                    </View>
                </View>
                <Text style={{ fontSize: 20, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, marginLeft: 29 }}>Service/Repair</Text>
                <View style={{ height: 15 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Mileage(KM)</Text>
                    </View>

                    <View style={styles.view}>
                        <Text style={styles.sw1}>GZ81X(Q)</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Date</Text>
                    </View>

                    <View style={styles.view}>
                        <Text style={styles.sw1}>1043446269</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Time</Text>
                    </View>

                    <View style={styles.view}>
                        <Text style={styles.sw1}>Nissan</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Comapny Name</Text>
                    </View>



                    <View style={styles.view}>
                        <Text style={styles.sw1}>E25</Text>
                    </View>

                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Driver Name</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>31 Aug 2023</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Contact Number</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>24 Oct 2025</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Towing Date</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>15 Jun 2023</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Time In</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>15 Dec 20233</Text>
                    </View>
                </View>
                <View style={{ height: 10 }}></View>
                <View style={styles.frow}>
                    <View style={{ width: '50%' }}>
                        <Text style={styles.fw}>Tow Chit N.o</Text>
                    </View>
                    <View style={styles.view}>
                        <Text style={styles.sw1}>JN1HG2E25Z07012</Text>
                    </View>
                </View>
                <View style={styles.box}>
                    <View style={styles.hadding}>
                        <Text style={styles.h1}>Description</Text>
                        <Text style={styles.h2}>Req Attn</Text>
                        <Text style={styles.h3}>Done</Text>
                        <Text style={styles.h4}>Remark</Text>

                    </View>
                    <TouchableOpacity >
                        <View style={styles.sub1}>
                            <Text style={styles.t1}>1.Inspection</Text>
                            <Text style={styles.t2}>Yes</Text>
                            <Text style={styles.t3}>Yes</Text>
                            <Text style={styles.t4}>Ok Good</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity >
                        <View style={styles.sub1}>
                            <Text style={styles.t1}>1.Inspection</Text>
                            <Text style={styles.t2}>Yes</Text>
                            <Text style={styles.t3}>Yes</Text>
                            <Text style={styles.t4}></Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity >
                        <View style={styles.sub1}>
                            <Text style={styles.t1}>1.Inspection</Text>
                            <Text style={styles.t2}>Yes</Text>
                            <Text style={styles.t3}>Yes</Text>
                            <Text style={styles.t4}>No Good</Text>
                        </View>
                    </TouchableOpacity>
                </View>
                <Text style={{ fontSize: 20, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, marginLeft: 28 }}>Van Inspection Report</Text>
                <View style={{ marginTop: 10 }}>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Date Out</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>GZ81X(Q)</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Time Out</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>Nissan</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Completed By</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>E25</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Mileage In(KM)</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>E25</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Mileage Out(KM)</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>E25</Text>
                        </View>

                    </View>
                    <View style={styles.main}>
                        <View style={styles.sub}>
                            <Text style={styles.frist}>Inspected By</Text>
                        </View>
                        <View style={styles.view}>
                            <Text style={styles.fline}>E25</Text>
                        </View>

                    </View>
                </View>

                <View style={{ borderWidth: 0, width: '100%', height: 250, flex: 0, flexDirection: 'row', marginTop: 10, margin: 12 }}>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 140 }}>
                        <TouchableOpacity>
                            <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} />
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 140 }}>
                        <TouchableOpacity>
                            <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} />
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>

                    </View>
                    <View style={{ borderWidth: 0, width: '30%', margin: '1%', backgroundColor: '#d9d9d9', borderRadius: 6, height: 140 }}>
                        <TouchableOpacity>
                            <FastImage style={{ borderWidth: 0, width: '100%', borderRadius: 10, height: 120 }} />
                        </TouchableOpacity>
                        <TextInput placeholder="Remarks" style={styles.textinput}></TextInput>
                    </View>
                </View>
                <TouchableOpacity style={styles.btn} onPress={() => { navigation.navigate('Summary') }} >
                    <Text style={styles.btninner}>
                        Save
                    </Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    )

}
export default Summary;