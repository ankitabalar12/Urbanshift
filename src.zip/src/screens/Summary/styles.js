import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    main:{
        width: '100%', flexDirection: 'row' ,marginLeft:30,marginBottom:10,marginTop:-5,borderWidth:0
    },
    sub:{
        width: '35%' 
    },
    frist:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18
    },
    fline:{
        textAlign: 'left', color: '#526578', fontSize: 18
    },
    view:{
        width: '35%',marginLeft:10
    },
    frow:{
        width: '100%', flexDirection: 'row'
    },
    fw:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18,marginLeft:29,borderWidth:0
    },
    sw:{
        textAlign: 'right', color: '#526578', fontSize: 18
    },
    sw1:{
        textAlign: 'left', color: '#526578', fontSize: 18,borderWidth:0
    },
    view:{
        width: '45%',marginLeft:10
    },
    box:{
        borderWidth:2,
        margin:10,
        borderColor:'#e5e5e5',
        borderRadius:10,
        // width:'100%'
    },
    hadding:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        backgroundColor:'#346696',
        height:40,
        // borderWidth:1
      
       
        // margin:5
    },
    h1:{
        color:'#ffffff',
       width:'35%',
        fontSize:18,
       textAlignVertical:'center',
        // marginTop:5,
        paddingLeft:'3%'
        // borderWidth:1,
        // textAlign:'center'
    },
    h2:{
        color:'#ffffff',
       
        fontSize:18,
        // marginRight:'11%',
        // marginTop:5,
        // borderWidth:1,
        width:'25%',
        textAlign:'center',
        textAlignVertical:'center'

    },
    h3:{
        color:'#ffffff',
      
        fontSize:18,
        // marginTop:5,
        // borderWidth:1,
        width:'20%',
        textAlign:'center',
        textAlignVertical:'center'

    },
    h4:{
        color:'#ffffff',
       
        fontSize:18,
        // marginTop:5,
        // borderWidth:1,
        width:'20%',
        textAlign:'center',
        textAlignVertical:'center'

    },
    sub1:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        borderBottomColor:'#e5e5e5',
        borderBottomWidth:2,
        margin:'2%',
        padding:'1%'
       
    },
    t1:{
     
        // marginLeft:'2%',
         fontSize:18,
         color:'#000000',
        //  borderWidth:1,
         width:'37%',
        //  textAlign:'center'
        
     },
     t2:{
        
        //  marginLeft:'15%',
         fontSize:18,
         color:'#000000',
        //  borderWidth:1,
         width:'23%',
         textAlign:'center'
 
     },
     t3:{
        
        //  marginLeft:'13%',
         fontSize:18,
         color:'#000000',
        //  borderWidth:1,
         width:'20%',
         textAlign:'center'
 
     },
     t4:{
        // marginLeft:'9%',
        fontSize:18,
        color:'#000000',
        // borderWidth:1,
        width:'26%',
        textAlign:'center'
     },
     textinput:{
        borderWidth:2,
        marginTop:30,
        fontSize:16,
        borderColor:'#a3a3a3',
        borderRadius:10
        // paddingTop:-5
        
      },
      btn:{
        height:45,borderRadius:3,backgroundColor:'#346696',width:'37%',marginLeft:'33%',marginTop:-15
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    
})
