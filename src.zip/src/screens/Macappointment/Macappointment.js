import React, { useState,useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    ActivityIndicator,
    Alert
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import { SearchBar } from "react-native-elements";
import AsyncStorage from '@react-native-community/async-storage';
import Modal from "react-native-modal";
import '../../../i18n';
import { useTranslation } from 'react-i18next';


const Macappointment = ({ navigation }) => {

    const [loading, setLoading] = useState(false);
    const [upcomming,setUpcomming]=useState('');
    const [history,setHistory]=useState('');
    const [search, setSearch] = useState('');
    const [masterDataSource, setMasterDataSource] = useState([]);
    const [isModalVisible, setModalVisible] = useState(false);
    const [pass,setPass]=useState('');
    const [isdelete, setIsdelete] = useState('1')
    const [del, setdel] = useState('');
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');

    
useEffect(() => {
    async function fetchData() {
    const typee = await AsyncStorage.getItem('type');
    //console.log('type== => ', typee);
    selectlan(typee)
                up();
            }
            fetchData();
            }, [])

            const selectlan = async (value) => {
                //console.log('selectedd',value)
                setValue(value)
                if (value == '1') {
                    changeLanguage('en')
                }
                if (value == '2') {
                    changeLanguage('hi')
                }
              
        
            }
            
             const changeLanguage = value => {
                i18n
                    .changeLanguage(value)
                    .then(() => setLanguage(value))
                    .catch(err => console.log(err));
            };

const selectpop = (up) => {
        setModalVisible(true)
        setPass(up)
        setdel(up.id)
 }
    const rest = () => {
        setModalVisible(false)
        navigation.navigate('Reschle',pass)
    }
    const deletes = () => {
        Alert.alert(
            "Are your sure?",
            "Are you sure you want to Delete ?",
            [
              // The "Yes" button
              {
                text: "Yes",
                onPress: () => {
                    // const del = async(id,index)=>{
                        setLoading(true);
                        fetch(global.url + 'deleteappointment.php', {
                            method: 'POST',
                            headers: {
                                Accept: 'application/json',
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                id:del
            
                            }),
                        })
                            .then((res) => res.json())
                            .then(async (json) => {
                                //console.log(json)
                                setLoading(false);
                                if (json.ResponseCode == '1') {
                                   
                                    setModalVisible(false)
                                    up();
                                    
                                } else {
                                    alert(json.ResponseMsg)
                                    setLoading(false);
                                }
                            })
                            .catch((err) => {
                               
                            });
                    // }
                },
                
              },
              // The "No" button
              // Does nothing but dismiss the dialog when tapped
              {
                text: "No",
                onPress: () => {
                    setModalVisible(false)
                    up();
                }
              
              },
            ]
          );
   }
    const up =async()=>{
        setLoading(true);
       const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)
        //console.log('donee')
        fetch(global.url+'getappointment.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
                
            }),
        })
        .then((res) => res.json())
            .then(async(json) => {
                console.log('Response =>', json)
                if (json.ResponseCode == '1') {
                   
                    await AsyncStorage.setItem('startScreen', "loginsucess");
                    await AsyncStorage.setItem('QasUpdate', JSON.stringify(json.upcomming));
                    setUpcomming(json.upcomming)
                    setHistory(json.history)
                    setMasterDataSource(json.upcomming);
                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)

                    setLoading(false);
                }
               
            })
            .catch((err) => {
                //console.log(err)
            });
    }

const searchFunction = (text) => {

    //console.log(text)
    if (text) {
       const newData = masterDataSource.filter(function (item) {


          return item.message.toUpperCase().startsWith(text.toUpperCase()) 
        });
    //   setHistory(newData)
      setUpcomming(newData)
      setHistory('')
      setSearch(text);
      } 
        else {
            setSearch(text);
            up();
}
};
 return (

    <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 20 }}>{t('All Appointment')}</Text>
                </View>
                    <View style={{borderWidth:0,flexDirection:'row',flex:0}}>
                <View style={{ marginLeft: 15 ,width:'75%',bottom:10}}>
                        <SearchBar
                        searchIcon={{ size: 25, color: '#9696a1', marginLeft: 10 }}
                        onChangeText={(text) => searchFunction(text)}
                        value={search}
                        underlineColorAndroid="transparent"
                        placeholder={t("Search Appointment")}
                        placeholderTextColor="#9696a1"
                        fontSize={20}
                        inputContainerStyle={{ backgroundColor: '#f2f2f3', borderBottomColor: 'gray', borderRadius: 8, height: 60 }}
                        containerStyle={{ backgroundColor: 'transparent', borderBottomColor: 'transparent', borderTopColor: 'transparent', height: 60 }}
                        returnKeyType='search'

                    />
                </View>
                <TouchableOpacity style={{borderWidth:0, backgroundColor: '#f2f2f3' ,width:'15%',borderRadius:10}} onPress={()=>navigation.navigate('Customer') }>

                    <View style={{ borderWidth: 0 }}>
                        <Image style={{ height: 30, width: 30,alignSelf:'center',marginTop:12 }} source={require('../../../image/add1.png')} />
                    </View>

                </TouchableOpacity>
                </View>
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        
                    </View>
                    : null}
             

                <View style={{ marginRight:20,marginLeft:20,marginTop:-15 ,marginTop:20}}>

                {/* <View style={{ margin: 5 }}> */}
                {upcomming?
            <View>
                 {upcomming.map((up, index) => (
                    <View key={index}>
                           <TouchableOpacity  onPress={() => navigation.navigate('Appodetail',up)}>
                                    <View style={{ borderWidth:2,borderColor:'#969698', borderRadius: 20 ,margin:5}}>
                                        <View style={{ height: 20 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                                            </View>
                                            <View style={{ width: '70%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.message}</Text>
                                            </View>
                                            {/* <TouchableOpacity style={{ width: '10%' }} onPress={()=>navigation.navigate('Reschle',up)}  > */}
                                            <TouchableOpacity style={{ width: '10%' }} onPress={()=>selectpop(up)}>
                                                <Image style={{ height: 20, width: 8 }} source={require('../../../image/dots.png')} />
                                            </TouchableOpacity>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.date}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clockapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.time}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 10 }}></View>
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{up.service_type}</Text>
                                            </View>
                                        </View>
                                        <View style={{ height: 15 }}></View>
                                    </View>
                                    </TouchableOpacity>
                            </View>
                  ))}
                  </View>
                  :<Text style={{fontSize:16,alignSelf:'center'}}> No any appointment found</Text>}
                 
                {/* </View> */}
                {history?
                    <View>
                         {history.map((his, index) => (
                             <View key={index}>
                                <TouchableOpacity onPress={() => navigation.navigate('Appodetail',his)}>
                                        <View style={{ borderWidth:2,borderColor:'#969698', borderRadius: 20 ,margin:5}}>
                                        <View style={{ height: 20 }}></View>
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10,margin:3 }} source={require('../../../image/carap.png')} />
                                        </View>
                                        <View style={{ width: '70%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.message}</Text>
                                        </View>
                                        <TouchableOpacity onPress={()=>selectpop(his)}>
                                        <View style={{ width: '10%' }}>
                                            <Image style={{ height: 20, width: 8 ,marginTop:10}} source={require('../../../image/dots.png')} />
                                        </View>
                                        </TouchableOpacity>
                                    </View>
                                 
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10,margin:3 }} source={require('../../../image/calapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.date}</Text>
                                        </View>
                                    </View>
                                   
                                        <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                            <View style={{ width: '15%' }}>
                                                <Image style={{ height: 30, width: 35, borderRadius: 10,margin:3 }} source={require('../../../image/clockapp.png')} />
                                            </View>
                                            <View style={{ width: '80%' }}>
                                                <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.time}</Text>
                                            </View>
                                        </View>
                                        
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 15 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10 ,margin:3}} source={require('../../../image/toolapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{his.service_type}</Text>
                                        </View>
                                    </View>
                                    <View style={{ height: 10 }}></View>
                               </View> 
                               </TouchableOpacity>   
                                    </View>
                         ))}
                         </View>
                 
                    :null}
                    </View>
                    <View>
                    <Modal isVisible={isModalVisible}>
                        <View style={{ flex: 0, alignItems: 'center', backgroundColor: 'white', padding: 6,height:'20%',width:200,marginLeft:100}}>
                            
                            <View style={{ borderBottomWidth: 2, width: 170 ,marginTop:10,height:30,borderColor:'#cccccc'}}>
                                <TouchableOpacity onPress={rest}>
                                    <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{'Reschedule'}</Text>
                                </TouchableOpacity>
                                
                            </View>
                            <View style={{ height: 10}}></View>
                            <Text style={{ textAlign: 'center',fontSize:18,color:'#1d334c' }} onPress={deletes}>{'Delete'}</Text>
                            <View style={{ borderTopWidth: 2, width: 170 ,marginTop:10,height:30,borderColor:'#cccccc',paddingTop:5}}>
                        <Text style={{ textAlign: 'center',fontSize:18,color:'#1d334c' }} onPress={deletes}>{'Cancel'}</Text>
</View>
                        </View>
                        
                    </Modal>
                </View>
            </ScrollView>
        </View>
    )

}
export default Macappointment;