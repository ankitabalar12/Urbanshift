import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    SafeAreaView,
    ActivityIndicator

} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import FastImage from 'react-native-fast-image';
import { TextInput } from "react-native-gesture-handler";
import DateTimePicker from '@react-native-community/datetimepicker';
import { use } from "i18next";
import AsyncStorage from '@react-native-community/async-storage';
import { Dropdown } from "react-native-element-dropdown";
import { flingGestureHandlerProps } from "react-native-gesture-handler/lib/typescript/handlers/FlingGestureHandler";
import '../../../i18n';
import { useTranslation } from 'react-i18next';

const Repair = ({ navigation, route }) => {
    const [date, setDate] = useState(new Date());
    const [m, setM] = useState(0);
    const [m1, setM1] = useState(0);
    const [m2, setM2] = useState(0);
    const [m3, setM3] = useState(0);
    const [datePicker, setDatePicker] = useState(false);
    const [tdate, setTdate] = useState(new Date());
    const [tdatePicker, setTdatePicker] = useState(false);
    const [From, setFrom] = useState(new Date());
    const [To, setTo] = useState(new Date());
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const [currentSetting, setcurrentSetting] = useState('from');
    const [currentSetting1, setcurrentSetting1] = useState('from');
    const [From1, setFrom1] = useState(new Date());
    const [To1, setTo1] = useState(new Date());
    const [mode1, setMode1] = useState('date');
    const [show1, setShow1] = useState(false);
    const [vnum, setVnum] = useState('');
    const [vbrand, setVbrand] = useState('');
    const [vmodel, setVmodel] = useState('');
    const [vmil, setvmil] = useState('');
    const [apidate, setapidate] = useState('');
    const [apitime, setapitime] = useState('');
    const [comname, setcomname] = useState('');
    const [drivername, setdrivername] = useState('');
    const [contact, setContact] = useState('');
    const [towing, settowign] = useState('');
    const [time, settime] = useState('');
    const [tow, settow] = useState('');
    const [His, setHis] = useState('');
    const [tconformdate, setconformdate] = useState('');
    const [loading, setLoading] = useState(false);
    const [Number, setNumber] = useState('');
    const [dropDownData2, setdropDownData2] = useState([]);
    const [model1, setmodel1] = useState([]);
    const [brand1, setbrand1] = useState([]);
    const [brand, setbrand] = useState('');
    const [model, setmodel] = useState('');
    const [selecteddrop2Values, setselecteddrop2Values] = useState('');
    const [submitted, setsubmitted] = useState(false);
    const [isFocus3, setIsFocus3] = useState(false);
    const [vehicle_number, setvehicle_number] = useState('');
    const [time1, settime1] = useState('');
    const [time2, settime2] = useState('');
    const [remark, setremark] = useState('');
    const [dateout, setdateout] = useState('');
    const [timeout, settimeout] = useState('');
    const [milin, setmilin] = useState('');
    const [milout, setmilout] = useState('');
    const [img, setimg] = useState('');
    const [imgremark, setimgremark] = useState('');
    const [complate, setcomplate] = useState('');
    const [id, setid] = useState('');
    const [timeoutpass, settimeoutpass] = useState('');
    const [tout, settout] = useState('');
    const [dearftdec, setdearftdec] = useState('');
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [showplacetext, setshowplacetext] = useState(0);
    const [datesame, setdatesame] = useState(0);
    const [datesame2, setdatesame2] = useState(0);
    // const [dateout, setdateout] = useState('');
    useEffect(() => {
        navigation.addListener('focus', async () => {
            setLoading(true)
            const typee = await AsyncStorage.getItem('type');
            console.log('date>>>', date)
            console.log('date>>>',date)
            const str =date.toString()
            console.log('str>>',str)
           const cut = str.substring(3,15)
           console.log('getsetdate>>>',cut)
           var month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
                "Aug", "Sep", "Oct", "Nov", "Dec"];
           global.currentdatee =new Date().getDate()
           global.currentmonth =new Date().getMonth()+1
           global.currentyear =new Date().getFullYear()
           var mm = month[new Date().getMonth()];
           const mydate =mm+''+'0'+global.currentdatee+''+global.currentyear
           console.log('mydate>>>',mydate)
           const spe =cut.replace(/\s/g, '')
          console.log('spe>>>',spe)
           if(spe == mydate){
               setdatesame(1)
               setdatesame2(1)
           }
            //console.log('type== => ', typee);
            selectlan(typee)
            const pass = route.params
            console.log('pass data>>>', pass)
            if (pass) {
                setLoading(true)
                //console.log('passifcondition', pass)
                if (pass.pass) {
                    //console.log('****iftrue')
                    setHis(pass.pass)
                    setvehicle_number(pass.pass.cardetail.vehicle_number)
                    ///setvehicle_number(2)
                    setVbrand(pass.pass.cardetail.car_brand)
                    setVmodel(pass.pass.cardetail.car_model)
                    setLoading(false)
                }
                else {
                    setLoading(true)

                    //console.log('***elsetrue')

                    setvehicle_number(pass.vehicle_number)
                    //    setvehicle_number(2)
                    setVbrand(pass.vehicle_brand)
                    setVmodel(pass.vehicle_model)
                    setvmil(pass.mileage)
                    setcomname(pass.company_name)
                    setdrivername(pass.driver_name)
                    setContact(pass.contact_number)
                    settow(pass.tow_chit_no)
                    if(pass.sdate){
                        setdatesame(0)
                        setDate(new Date(pass.sdate))
                    }
                   if(pass.towing_date){
                    setdatesame2(0)
                    setTdate(new Date(pass.towing_date))
                   }
                    // setDate(new Date(pass.sdate))
                    settime1(pass.stime)
                    // setTdate(new Date(pass.towing_date))
                    settime2(pass.time_in)
                    setremark(pass.req_attn)
                    // console.log('pass.req_attn>>>>',pass.req_attn)
                    setmilin(pass.mileage_in)
                    setmilout(pass.mileage_out)
                    setimg(pass.images)
                    setimgremark(pass.image_remark)
                    setcomplate(pass.completed_by)
                    setid(pass.id)
                    global.dec = pass.description;
                    // console.log(' global.dec>>>>', global.dec)
                    // console.log(' pass.description>>>>', pass.description)
                    setdearftdec(global.dec)

                    global.out = pass.time_out

                    setdateout(pass.date_out)

                    getcar();
                    setLoading(false)
                }
            }
            else {
                getcar();
            }
            setLoading(false)


        })
    }, [])

    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };

    const getcar = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setLoading(true);


        fetch(global.url + 'getcars.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
            }),
        })

            .then((res) => res.json())
            .then((json) => {
                if (json.ResponseCode == '1') {

                    setbrand(json.car_brand)
                    setmodel(json.car_model)
                    var count = Object.keys(json.data).length;


                    for (var i = 0; i < count; i++) {
                        dropDownData2.push({ value: json.data[i].vehicle_number, label: json.data[i].vehicle_number, model: json.data[i].car_model, brand: json.data[i].car_brand }); // Create your array of data
                    }
                    dropDownData2.push({ value: 20, label: 'Other' })
                    setNumber(dropDownData2);


                    setLoading(false);

                }
                else {
                    alert(json.ResponseMsg)
                }

            })
            .catch((err) => {
                //console.log(err);
                //console.log(err)
            });
    }
    const setvehiclenumber = (val) => {
        setLoading(true)
        //console.log('vehiclenumber-----', val.value)

        setselecteddrop2Values(val.value)

        for (var i = 0; i < dropDownData2.length; i++) {

            if (dropDownData2[i].value == val.value) {

                const selectval = dropDownData2[i]


                setVbrand(selectval.brand)

                setVmodel(selectval.model)

            }
        }
        setLoading(false)
    }
    const onChange = (event, selectedDate) => {

        setShow(false);
        const currentDate = selectedDate;

        //console.log('currentDate>>>', currentDate.toLocaleTimeString())

        const str = currentDate.toLocaleTimeString();
        //console.log('str>>', str)
        const str2 = str.substring(0, str.length - 3);
        settime1(str2)
        //console.log('time1>>>', time1)

    };

    const showTimepicker = (current) => {
        setShow(true);

    };
    const onChange1 = (event, selectedDate) => {
        const currentDate = selectedDate;

        setShow1(false)
        let str = currentDate.toLocaleTimeString();
        str = str.substring(0, str.length - 3);
        settime2(str)



    };
    const showTimepicker1 = (current) => {
        setShow1(true);

    };
    const ontDateSelected = (event, value) => {
        //console.log(value)
        setdatesame2(0)
        setTdate(value);
        setTdatePicker(false);
    };
    const tvalueformatedate = (value) => {
        //console.log(value)
        var month = ["January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"];
        var strSplitDate = String(value).split(' ');
        var dates = new Date(strSplitDate[0]);
        var dd = tdate.getDate();
        var mm = month[tdate.getMonth()];
        var yyyy = tdate.getFullYear();
        var conformdate = dd + ' ' + mm + ' ' + yyyy
        global.date2 = conformdate

        //console.log(conformdate)
        return conformdate
    }

    const tshowDatePicker = () => {
        setM2(1)
        setTdatePicker(true);

    };


    const onDateSelected = (event, value) => {
        setdatesame(0)
        setshowplacetext(1)
        setDate(value);
        setDatePicker(false);
    };
    const valueformatedate = (value) => {
        //console.log(value)
        var month = ["January", "February", "March", "April", "May", "June", "July",
            "August", "September", "October", "November", "December"];
        var strSplitDate = String(value).split(' ');
        var dates = new Date(strSplitDate[0]);
        var dd = date.getDate();
        var mm = month[date.getMonth()];
        var yyyy = date.getFullYear();
        var conformdate1 = dd + ' ' + mm + ' ' + yyyy
        global.sdate = conformdate1
        //console.log(conformdate1)
        return conformdate1
    }
    const showDatePicker = () => {
        setDatePicker(true);

        //console.log('*********************', date)
    };

    const passarray = () => {
        setsubmitted(true)
        let Repairarray = [
            { "id": 0, 'name': vehicle_number },
            { "id": 1, 'name': vbrand },
            { "id": 2, 'name': vmodel },
            { "id": 3, 'name': vmil },
            { "id": 4, 'name': global.sdate },

            { "id": 5, 'name': time1 },
            { "id": 6, 'name': comname },
            { "id": 7, 'name': drivername },
            { "id": 8, 'name': contact },
            { "id": 9, 'name': drivername },
            { "id": 10, 'name': global.date2 },
            // { "id": 11, 'name': To1},
            { "id": 11, 'name': time2 },
            { "id": 12, 'name': tow },
            { "id": 13, 'name': remark },
            { "id": 14, 'name': dateout },
            { "id": 15, 'name': timeout },
            { "id": 16, 'name': milin },
            { "id": 17, 'name': milout },
            { "id": 18, 'name': img },
            { "id": 19, 'name': imgremark },
            { "id": 20, 'name': complate },
            { "id": 21, 'name': id },
            // { "id": 22, 'name': timeoutpass },
            { "id": 22, 'name': global.out },
            { "id": 23, 'name': dearftdec },
        ];
        if (vehicle_number !== '' && vbrand !== '' && vmodel !== '' && vmil !== '' && date !== '' && From !== '' && contact !== '' && drivername !== '') {
            console.log('remark>>>', remark)
            //console.log('img>>>', img)
            navigation.navigate('Description', JSON.stringify(Repairarray))
        }

        // //console.log('Repairarray------------', Repairarray)
    }
    const placeholder = "Select date"

    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 20 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />

                        {/* <Image style={styles.ficon} source={require('../../../image/back.png')} /> */}
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, marginLeft: -5 }}>{t('Service / Repair Form')}</Text>


                </View>

                {!His ?
                    <View>
                        <View style={styles.fristdrop}>
                            <Image style={{ height: 30, width: 35, alignSelf: 'center', marginTop: 6, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                            <View style={{ width: '80%', marginHorizontal: 13, letterSpacing: 1.5, fontSize: 18, alignSelf: 'center', margin: 5 }}>

                                {Number ?
                                    <Dropdown

                                        placeholderStyle={styles.placeholderStyle}
                                        selectedTextStyle={styles.selectedTextStyle}
                                        itemTextStyle={{ color: "#afb0b6" }}
                                        data={Number}
                                        iconStyle={{ right: 10 }}
                                        maxHeight={300}
                                        labelField="label"
                                        valueField="value"
                                        placeholder={!isFocus3 ? "Vehicle Number" : vehicle_number}
                                        // placeholder={t('Vehicle Number')}
                                        value={vehicle_number}
                                        onFocus={() => setIsFocus3(true)}
                                        onBlur={() => setIsFocus3(false)}
                                        onChange={(item) => {
                                            // setSelect(0)
                                            setvehicle_number(item.label)
                                            setvehiclenumber(item)
                                            setIsFocus3(false);
                                        }}

                                    /> : null}
                            </View>
                        </View>
                        {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>{t('Please Select Vehicle Number')}</Text> : null}

                        <View style={{ height: 15 }}></View>

                        {selecteddrop2Values == '20' ?
                            <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -5 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                    <TextInput onChangeText={(value) => setvehicle_number(value)} value={vehicle_number} placeholder={t("Vehicle Number")} fontSize={19} marginTop={5} color={'#000000'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>

                                </View>
                                {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>Please Enter Vehicle Number</Text> : null}
                            </View>


                            : null}


                        <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                <TextInput onChangeText={(value) => setVbrand(value)} value={vbrand} placeholder={t("Vehicle Brand")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>

                            </View>
                        </View>
                        {vbrand === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Brand</Text> : null}


                        <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />

                                <TextInput onChangeText={(value) => setVmodel(value)} value={vmodel} placeholder={t("Vehicle Model")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}></TextInput>
                            </View>
                        </View>
                        {vmodel === '' && submitted ? <Text style={styles.chooseUserName2}>Please Input model</Text> : null}

                    </View>

                    :
                    <View style={{ marginTop: -5 }}>
                        <View style={styles.main}>
                            <View style={styles.sub}>
                                <Text style={styles.frist}>{t('Vehicle Number')}</Text>
                            </View>
                            <View style={styles.view}>
                                <Text style={styles.fline}>{vehicle_number}</Text>
                            </View>

                        </View>
                        <View style={styles.main}>
                            <View style={styles.sub}>
                                <Text style={styles.frist}>{t('Brand')}</Text>
                            </View>
                            <View style={styles.view}>
                                <Text style={styles.fline}>{vbrand}</Text>
                            </View>

                        </View>
                        <View style={styles.main}>
                            <View style={styles.sub}>
                                <Text style={styles.frist}>{t('Model')}</Text>
                            </View>
                            <View style={styles.view}>
                                <Text style={styles.fline}>{vmodel}</Text>
                            </View>

                        </View>
                    </View>

                }
                <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -2 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                        <TextInput placeholder={t("Mileage")} onChangeText={(value) => setvmil(value)} value={vmil} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000", paddingTop: 10 }}>
                        </TextInput>
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end', marginRight: 10 }}><Text style={{ fontSize: 17, color: "gray", marginTop: 10 }}>{t('KM')}</Text></View>
                    </View>

                </View>

                {vmil === '' && submitted ? <Text style={styles.chooseUserName2}>{t('Please Input mileage')}</Text> : null}

                <View style={{ flexDirection: 'row' }}>
                    <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -2, width: '45%' }}>
                        <TouchableOpacity onPress={showDatePicker}>
                            <View style={{ flexDirection: 'row' }}>

                                <View style={{ width: '10%', marginRight: 10 }}>

                                    <TouchableOpacity >
                                        <Image style={styles.ficon} source={require('../../../image/datenew1.png')} />
                                    </TouchableOpacity>

                                </View>

                                <View style={{ width: '100%' }}>

                                    {datePicker ?
                                        <DateTimePicker
                                            value={date}
                                            mode={'date'}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={true}
                                            onChange={onDateSelected}
                                        />

                                        : null
                                    }
                                    {/* <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{m == 1 ? valueformatedate(date.toDateString()) : placeholderText}</Text> */}

                                    {datesame==1?
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>Select date</Text>

                                    :
                                   
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{valueformatedate(date.toDateString())}</Text>
                                    
                                    }


                                </View>

                            </View>
                        </TouchableOpacity>

                    </View>
                    {date === '' && submitted ? <Text style={styles.chooseUserName}>Please Select Time</Text> : null}


                    <View style={{ width: '43%', borderWidth: 2, borderColor: '#AFB0B6', height: 45, marginLeft: -10, borderRadius: 10 }} >
                        <TouchableOpacity onPress={showTimepicker}>
                            <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity onPress={showTimepicker}>
                        <View>
                            {show ?
                                <DateTimePicker
                                    testID="dateTimePicker"
                                    value={To}
                                    mode={'time'}
                                    is24Hour={true}
                                    display="default"
                                    onChange={onChange}
                                /> :
                                // <Text style={{ color: 'black', fontSize: 15, margin: 10 ,borderWidth:0,width:'20%',position:'absolute',bottom:"34%",borderWidth:0,right:53}}>{To.toLocaleTimeString()}</Text>
                                null
                            }
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={{ borderWidth: 0, marginTop: 11, position: 'absolute', right: '17%' }} onPress={showTimepicker}>
                        {time1 ?
                            <Text style={{ color: 'black', fontSize: 15, borderWidth: 0 }}>{time1}</Text>

                            :
                            <TouchableOpacity onPress={showTimepicker}>
                                <Text style={{ color: 'black', fontSize: 15, borderWidth: 0 }}>{t('Select time')}</Text>
                            </TouchableOpacity>
                        }
                    </TouchableOpacity>
                </View>
                {From === '' && submitted ? <Text style={styles.chooseUserName}>Please Select Time</Text> : null}

                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/com.png')} />
                        <TextInput placeholder={t("Company Name")} onChangeText={(value) => setcomname(value)} value={comname} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {/* {comname === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Input Company Name')}</Text> : null} */}
                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/per.png')} />
                        <TextInput placeholder={t("Driver's Name")} onChangeText={(value) => setdrivername(value)} value={drivername} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {drivername === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Input Driver Name')}</Text> : null}


                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/call.png')} />
                        <TextInput placeholder={t("Contact Number")} onChangeText={(value) => setContact(value)} value={contact} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {contact === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Input Contact Number')}</Text> : null}
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                <View style={{ flexDirection: 'row' }}>
                    <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20, width: '45%' }}>
                        <TouchableOpacity onPress={tshowDatePicker}>
                            <View style={{ flexDirection: 'row' }}>

                                <View style={{ width: '10%', marginRight: 10 }}>

                                    <TouchableOpacity>
                                        <Image style={styles.ficon} source={require('../../../image/datenew.png')} />
                                    </TouchableOpacity>

                                </View>
                                <View style={{ width: '90%' }}>
                                    {tdatePicker
                                        ?
                                        <DateTimePicker
                                            value={tdate}
                                            mode={'date'}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={true}
                                            onChange={ontDateSelected}
                                        />
                                        :
                                        // <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{tvalueformatedate(tdate.toDateString())}</Text>
                                        null
                                    }
                                    {datesame2==1?
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>Select date</Text>

                                    :
                                   
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{tvalueformatedate(tdate.toDateString())}</Text>
                                    
                                    }
                                    

                                </View>

                            </View>
                        </TouchableOpacity>
                    </View>
                    {/* {tdate === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Towing date</Text> : null} */}

                    <View style={{ width: '43%', borderWidth: 2, borderColor: '#AFB0B6', height: 45, marginLeft: -10, borderRadius: 10, marginTop: 20 }} >
                        <TouchableOpacity onPress={showTimepicker1}>
                            <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity onPress={showTimepicker1}>
                        <View>
                            {show1 ?
                                <DateTimePicker
                                    testID="dateTimePicker"
                                    value={To1}
                                    mode={'time'}
                                    is24Hour={true}
                                    display="default"
                                    onChange={onChange1}
                                /> :
                                // <Text style={{ color: 'black', fontSize: 15, margin: 10 ,borderWidth:0,width:'20%',position:'absolute',bottom:"29%",borderWidth:0,right:53}}>{To1.toLocaleTimeString()}</Text>
                                null
                            }


                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={{ borderWidth: 0, right: '17%', position: 'absolute', marginTop: 30 }} onPress={showTimepicker1}>
                        {time2 ?
                            <Text style={{ color: 'black', fontSize: 15, borderWidth: 0 }}>{time2}</Text>
                            :
                            <TouchableOpacity onPress={showTimepicker1}>
                                <Text style={{ color: 'black', fontSize: 15, borderWidth: 0 }}>{t('Select time')}</Text>
                            </TouchableOpacity>
                        }
                    </TouchableOpacity>

                </View>
                {/* {From1 === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Time In</Text> : null} */}

                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 0 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/tow.png')} />
                        <TextInput placeholder={t("Tow Chit N.o")} onChangeText={(value) => settow(value)} value={tow} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {/* {tow === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Tow Chit N.o</Text> : null} */}


                <TouchableOpacity style={styles.btn} onPress={passarray} >
                    <Text style={styles.btninner}>
                        {t('Next')}
                    </Text>
                </TouchableOpacity>
            </ScrollView>

        </View>
    )

}
export default Repair;