import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
        // borderWidth:1
    },
    ficon:{
        width:25,
        height:25,
        margin:9,
    },
    btn:{
        height:50,borderRadius:3,backgroundColor:'#346696',
       marginLeft:'6%',
       marginTop:'10%',
       marginRight:'5%'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:20,fontWeight:'bold',marginTop:7
    },
    ficon1:{
        width:20,
        height:20,
        margin:9,
    },
    main:{
        width: '100%', flexDirection: 'row' ,marginLeft:20,marginBottom:10,marginTop:-5,borderWidth:0,
    },
    sub:{
        width: '45%' ,margin:'1%'
    },
    frist:{
        textAlign: 'left', color: '#9b9ba7', fontSize: 19,borderWidth:0
    },
    fline:{
        textAlign: 'right', color: '#526578', fontSize: 19,borderWidth:0
    },
    view:{
        width: '40%',marginLeft:0,margin:'1%'
    },
    frow:{
        width: '100%', flexDirection: 'row'
    },
    fw:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18,marginLeft:20
    },
    dropdown2:{

        borderWidth: 2,
         margin: '5%',
          padding: '0%', 
          borderColor: '#afb0b6',
           borderRadius: 10,
           height:50

      },
      placeholderStyle: {
        fontSize: 18,
        color: '#AFB0B6',
        fontFamily:'Poppins-bold',
        // marginLeft:'19%'

        // borderWidth:1
      },
      selectedTextStyle: {
        fontSize: 17,
        color:'#000000',
        fontFamily:'Poppins-bold',
        // marginLeft:'21%'


        // borderWidth:1
      },
      chooseUserName:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start',
        fontFamily:'Poppins-Regular',
        marginLeft:25,
       
        // borderWidth:1,
        
    },
      chooseUserName2:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start',
        fontFamily:'Poppins-Regular',
        marginLeft:25,
        // borderWidth:1,
        marginTop:-12,
        marginBottom:0
    },
    datetimevali:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start',
        fontFamily:'Poppins-Regular',
        marginLeft:25,
       
        // borderWidth:1,
        
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%'
      },
      fristdrop:{
        flexDirection: 'row',
        borderColor:'gray',
        marginBottom: 10,
       
        borderWidth: 1,
        width: '90%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
})