import React, { useState } from "react";
import { StatusBar, StyleSheet, View, Platform, Text } from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import LinearGradient from 'react-native-linear-gradient';
import { resetNavigateTo } from "../../../NavigationHelper";
import AsyncStorage from '@react-native-community/async-storage';
import { styles } from './styles';
export default function Splash({ navigation }) {
    React.useEffect(() => {
        setTimeout(async () => {
            SplashScreen.hide();
            const result = await AsyncStorage.getItem('QasLogin')
            const screenData = JSON.parse(result)
            if (screenData) {
                resetNavigateTo(navigation, 'Home');
            } else {
                resetNavigateTo(navigation, 'Firstp');
            }
        }, 500);
    }, []);

    return (
        <LinearGradient colors={['#346696', '#274c70', '#1c3852']} style={styles.container}>
            <StatusBar backgroundColor='#346696' barStyle="dark-content" />
            <View style={{ justifyContent: 'center' }}>
                <Text style={styles.txt}>QAS</Text>
                <Text style={styles.txt}> AUTO</Text>
            </View>
        </LinearGradient>
    );
}

