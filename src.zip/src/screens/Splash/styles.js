import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    container: {
        height: '100%',
        backgroundColor: '#346696',
        alignItems: 'center',
        justifyContent: 'center',
    },
    txt: {
        color: '#ffffff', fontSize: 30, fontWeight: 'bold', textAlign: 'center', fontWeight: 'bold',
    }
})