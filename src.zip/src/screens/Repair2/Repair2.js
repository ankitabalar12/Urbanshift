import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    SafeAreaView,
    ActivityIndicator

} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import FastImage from 'react-native-fast-image';
import { TextInput } from "react-native-gesture-handler";
import DateTimePicker from '@react-native-community/datetimepicker';
import { use } from "i18next";
import AsyncStorage from '@react-native-community/async-storage';
import { Dropdown } from "react-native-element-dropdown";


const Repair2 = ({ navigation, route }) => {
    const [date, setDate] = useState(new Date());
    const [m1, setM1] = useState(0);
    const [m2, setM2] = useState(0);
    const [m3, setM3] = useState(0);
    const [datePicker, setDatePicker] = useState(false);
    const [tdate, setTdate] = useState(new Date());
    const [tdatePicker, setTdatePicker] = useState(false);
    const [From, setFrom] = useState(new Date());
    const [To, setTo] = useState(new Date());
    const [show, setShow] = useState(false);
    const [currentSetting, setcurrentSetting] = useState('from');
    const [currentSetting1, setcurrentSetting1] = useState('from');
    const [From1, setFrom1] = useState(new Date());
    const [To1, setTo1] = useState(new Date());
    const [show1, setShow1] = useState(false);
    const [vbrand, setVbrand] = useState('');
    const [vmodel, setVmodel] = useState('');
    const [vmil, setvmil] = useState('');
    const [comname, setcomname] = useState('');
    const [drivername, setdrivername] = useState('');
    const [contact, setContact] = useState('');
    const [tow, settow] = useState('');
    const [loading, setLoading] = useState(false);
    const [submitted, setsubmitted] = useState(false);
    const [vehicle_number, setvehicle_number] = useState('');
    const [time1, settime1] = useState('');
    const [time2, settime2] = useState('');
    const [id, setid] = useState('');
    const [req, setreq] = useState('');
    useEffect(() => {
        navigation.addListener('focus', () => {
            setLoading(true)
            const number = route.params
            //console.log('app===>>>>>', number)
            setvehicle_number(number.vehicle_number)
            setVbrand(number.vehicle_brand)
            // setVmodel(number.)
            setvmil(number.mileage)
            setcomname(number.company_name)
            setdrivername(number.driver_name)
            setContact(number.contact_number)
            settow(number.tow_chit_no)
            // settime1(number.time_in)
            setTo(number.time_in)
            const str = To.toLocaleTimeString();
            var strr = str.substring(0, str.length - 3);
            settime1(strr)
            setTo1(number.time_out);
            let str2 = To1.toLocaleTimeString();
            str2 = str2.substring(0, str2.length - 3);
            settime2(str2)
            setTdate(number.towing_date)
            setDate(number.date_out)
            setVmodel(number.vehicle_model)
            setreq(number.req_attn)
            setid(number.id)
            setLoading(false)
        })
    }, [])


    const onChange = (event, selectedDate) => {
        // //console.log('selectedDate>>>',selectedDate)
        if (currentSetting === 'from') {
            const currentDate = selectedDate || From;
            setShow(Platform.OS === 'ios');
            setFrom(currentDate);
            // //console.log('currentDate',currentDate)
            // //console.log('From',From)
            alert(currentDate)
            alert(From)
        }
        else {
            const currentDate = selectedDate || To;
            setShow(Platform.OS === 'ios');
            setTo(currentDate);
            var st = To.toLocaleTimeString()
            let str = To.toLocaleTimeString();
            str = str.substring(0, str.length - 3);
            settime1(str)
        }
    };

    const showTimepicker = (current) => {
        setShow(true);
        setM1(1)
        setcurrentSetting(current);
    };
    const onChange1 = (event, selectedDate) => {
        if (currentSetting1 === 'from') {
            const currentDate = selectedDate || From;
            setShow1(Platform.OS === 'ios');
            setFrom1(currentDate);
        } else {
            const currentDate = selectedDate || To;
            setShow1(Platform.OS === 'ios');
            setTo1(currentDate);
            var st = To1.toLocaleTimeString()
            let str = To1.toLocaleTimeString();
            str = str.substring(0, str.length - 3);
            settime2(str)
        }
    };
    const showTimepicker1 = (current) => {
        setShow1(true);
        setM3(1)
        setcurrentSetting1(current);
    };
    const ontDateSelected = (event, value) => {
        //console.log(value)
        setTdate(value);
        setTdatePicker(false);
    };


    const tshowDatePicker = () => {
        setM2(1)
        setTdatePicker(true);

    };


    const onDateSelected = (event, value) => {
        //console.log(value)
        setDate(value);
        setDatePicker(false);
    };

    const showDatePicker = () => {
        setDatePicker(true);
        // setM(1)
        //console.log('*********************', date)
    };

    const passarray = () => {
        setsubmitted(true)
        let Repairarray = [
            { "id": 0, 'name': vehicle_number },
            { "id": 1, 'name': vbrand },
            { "id": 2, 'name': vmodel },
            { "id": 3, 'name': vmil },
            { "id": 4, 'name': date },
            { "id": 5, 'name': time1 },
            { "id": 6, 'name': comname },
            { "id": 7, 'name': drivername },
            { "id": 8, 'name': contact },
            { "id": 9, 'name': drivername },
            { "id": 10, 'name': tdate },
            { "id": 11, 'name': time2 },
            { "id": 12, 'name': tow },
            { "id": 13, 'name': req },


        ];
        if (vehicle_number !== '' && vbrand !== '' && vmodel !== '' && vmil !== '' && date !== '' && From !== '' && comname !== '' && contact !== '' && drivername !== '') {
            navigation.navigate('Des1', JSON.stringify(Repairarray))
        }
        //console.log('Repairarray------------', Repairarray)
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 20 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, marginLeft: -5 }}>Service / Repair Form</Text>

                    {loading ?
                        <View style={styles.spinner}>
                            <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        </View>
                        : null}
                </View>
                <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -5 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                        <TextInput editable={false} onChangeText={(value) => setvehicle_number(value)} value={vehicle_number} placeholder="Vehicle Number" fontSize={19} marginTop={5} color={'#000000'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                    {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>Please Enter Vehicle Number</Text> : null}
                </View>
                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                        <TextInput onChangeText={(value) => setVbrand(value)} value={vbrand} placeholder="Vehicle Brand" fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {vbrand === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Brand</Text> : null}


                <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />

                        <TextInput onChangeText={(value) => setVmodel(value)} value={vmodel} placeholder="Vehicle Model" fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}></TextInput>
                    </View>
                </View>
                {vmodel === '' && submitted ? <Text style={styles.chooseUserName2}>Please Input model</Text> : null}
                <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -2 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                        <TextInput placeholder="Mileage" onChangeText={(value) => setvmil(value)} value={vmil} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000", paddingTop: 10 }}>
                        </TextInput>
                        <Text style={{ fontSize: 17, color: "gray", marginTop: 10, left: 70 }}>KM</Text>
                    </View>
                </View>

                {vmil === '' && submitted ? <Text style={styles.chooseUserName2}>Please Input mileage</Text> : null}

                <View style={{ flexDirection: 'row' }}>
                    <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -2, width: '45%' }}>
                        <TouchableOpacity onPress={showDatePicker}>
                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ width: '10%', marginRight: 10 }}>
                                    <TouchableOpacity >
                                        <Image style={styles.ficon} source={require('../../../image/datenew1.png')} />
                                    </TouchableOpacity>
                                </View>
                                <View style={{ width: '90%' }}>
                                    {datePicker ?
                                        <DateTimePicker
                                            // placeholder='abcds'
                                            value={date}
                                            mode={'date'}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={true}
                                            onChange={onDateSelected}
                                        />
                                        : null
                                    }
                                    <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{date.toString()}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>

                    </View>
                    {date === '' && submitted ? <Text style={styles.chooseUserName}>Please Select Time</Text> : null}
                    <View style={{ width: '43%', borderWidth: 2, borderColor: '#AFB0B6', height: 45, marginLeft: -10, borderRadius: 10 }} >
                        <TouchableOpacity onPress={showTimepicker}>
                            <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity onPress={showTimepicker}>
                        <View>
                            {show ?
                                <DateTimePicker
                                    testID="dateTimePicker"
                                    value={To}
                                    mode={'time'}
                                    is24Hour={true}
                                    display="default"
                                    onChange={onChange}
                                /> :
                                null
                            }
                            {From &&
                                <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '100%', bottom: "1%", right: 110, top: 12 }}>{time1}</Text>
                            }
                        </View>
                    </TouchableOpacity>
                </View>
                {From === '' && submitted ? <Text style={styles.chooseUserName}>Please Select Time</Text> : null}

                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/com.png')} />
                        <TextInput placeholder="Company Name" onChangeText={(value) => setcomname(value)} value={comname} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {comname === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Company Name</Text> : null}
                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/per.png')} />
                        <TextInput placeholder="Driver's Name" onChangeText={(value) => setdrivername(value)} value={drivername} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {drivername === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Driver's Name</Text> : null}


                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/call.png')} />
                        <TextInput placeholder="Contact Number" onChangeText={(value) => setContact(value)} value={contact} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {contact === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Contact Number</Text> : null}

                <View style={{ flexDirection: 'row' }}>
                    <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20, width: '45%' }}>
                        <TouchableOpacity onPress={tshowDatePicker}>
                            <View style={{ flexDirection: 'row' }}>

                                <View style={{ width: '10%', marginRight: 10 }}>

                                    <TouchableOpacity>
                                        <Image style={styles.ficon} source={require('../../../image/datenew.png')} />
                                    </TouchableOpacity>

                                </View>
                                <View style={{ width: '90%' }}>
                                    {tdatePicker
                                        ?
                                        <DateTimePicker
                                            value={tdate}
                                            mode={'date'}
                                            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                            is24Hour={true}
                                            onChange={ontDateSelected}
                                        />
                                        :
                                        // <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{tvalueformatedate(tdate.toDateString())}</Text>
                                        null
                                    }
                                    {tdate &&
                                        <Text style={{ color: 'black', fontSize: 15, margin: 10 }}>{tdate.toString()}</Text>
                                    }

                                </View>

                            </View>
                        </TouchableOpacity>
                    </View>
                    {/* {tdate === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Towing date</Text> : null} */}

                    <View style={{ width: '43%', borderWidth: 2, borderColor: '#AFB0B6', height: 45, marginLeft: -10, borderRadius: 10, marginTop: 20 }} >
                        <TouchableOpacity onPress={showTimepicker1}>
                            <Image style={styles.ficon1} source={require('../../../image/clock1.png')} />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity onPress={showTimepicker1}>
                        <View>
                            {show1 ?
                                <DateTimePicker
                                    testID="dateTimePicker"
                                    value={To1}
                                    mode={'time'}
                                    is24Hour={true}
                                    display="default"
                                    onChange={onChange1}
                                /> :
                                // <Text style={{ color: 'black', fontSize: 15, margin: 10 ,borderWidth:0,width:'20%',position:'absolute',bottom:"29%",borderWidth:0,right:53}}>{To1.toLocaleTimeString()}</Text>
                                null
                            }
                            {From1 &&
                                <Text style={{ color: 'black', fontSize: 15, borderWidth: 0, width: '100%', bottom: "1%", right: 110, top: 30 }}>{time2}</Text>
                            }
                        </View>
                    </TouchableOpacity>

                </View>
                {/* {From1 === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Time In</Text> : null} */}

                <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 0 }}>
                    <View style={{ flexDirection: 'row' }}>
                        <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/tow.png')} />
                        <TextInput placeholder="Tow Chit N.o" onChangeText={(value) => settow(value)} value={tow} fontSize={19} marginTop={5} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                        </TextInput>

                    </View>
                </View>
                {/* {tow === '' && submitted ? <Text style={styles.chooseUserName}>Please Input Tow Chit N.o</Text> : null} */}


                <TouchableOpacity style={styles.btn} onPress={passarray} >
                    <Text style={styles.btninner}>
                        Next
                    </Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    )

}
export default Repair2;