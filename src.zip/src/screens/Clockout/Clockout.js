import React, { useState,useEffect } from "react";
import {
  Image,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  StatusBar
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Dropdown } from "react-native-element-dropdown";
import AsyncStorage from '@react-native-community/async-storage';
import moment from 'moment';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
const Clockout = ({ navigation }) => {
    const [value, setValue] = useState(null);
    const [isFocus, setIsFocus] = useState(false);
    const [category,setCategory]=useState('');
    const [loading, setLoading] = useState(false);
    const [submitted,setsubmitted]=useState('');
    const [currentTime, setCurrentTime] = useState('');
    const [currentDate, setCurrentDate] = useState('');
    const [apitime, setapitime] = useState('');
    const { t, i18n } = useTranslation();
    const [Value2, setValue2] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    useEffect(() => {
     navigation.addListener('focus', async() => {
        const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
        var date= moment().format("DD-MM-YYYY")
        setCurrentDate(date)
        var date = moment().utcOffset('+05:30').format(' hh:mm A');
        setCurrentTime(date);
       getmac();
       time2();
    })
    }, []);
    const selectlan = async (value) => {
        setValue2(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
	
	 const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };

    const getmac =async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setLoading(true);
        fetch(global.url+'getmechanics.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id:screenData.id
            }),
        })
            .then((res) => res.json())
            .then(async(json) => {
                if (json.ResponseCode == '1') {
                    var count = Object.keys(json.upcomming).length;
                    let dropDownData = [];
                    for (var i = 0; i < count; i++) {
                        dropDownData.push({ value: json.upcomming[i].id, label: json.upcomming[i].full_name }); // Create your array of data
                    }
                    setCategory(dropDownData);
                   setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }
 const time2 =() =>{
        fetch(global.url+'gettime.php', {
                        method: 'POST',
                        headers: {
                            Accept: 'application/json',
                            'Content-Type': 'application/json',
                        },
                        body:JSON.stringify({
                          
                           }),
                    })
                    .then((res) => res.json())
                    .then(async(json) => {  
                        if (json.ResponseCode == '1') {
                            setapitime(json.data)
                               }
                             else {
                                alert(json.ResponseMsg)
                            }
                        
                        })
                            .catch((err) => {
                            console.log(err);
                            console.log(err)
                        });
                    }
 
    const Clockout =async()=>{
        setsubmitted(true)
        if(value!==null){
        fetch(global.url+'addattendance.php', {
                 method: 'POST',
                 headers: {
                     Accept: 'application/json',
                     'Content-Type': 'application/json',
                 },
                 body:JSON.stringify({
                    user_id:value,
                    adate:currentDate,
                    atime:apitime,
                    type:2
                    }),
             })
             .then((res) => res.json())
             .then(async(json) => {  
                 if (json.ResponseCode == '1') {
                 navigation.navigate('Success')
                    }
                      else {
                         alert(json.ResponseMsg)
                     }
                 
                 })
                     .catch((err) => {
                     console.log(err);
                     console.log(err)
                 });
                }
    
     }
    
return(
	<View style={styles.maincontainer}>
    <ScrollView style={{bottom:10}}>
    <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
        <View style={{ margin: 30 }}>
            <View style={{ height: 10 }}></View>
            <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={35}  style={{color:'#0d0d26',marginLeft:-10}}/>
            </TouchableOpacity>
            <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold' ,marginTop:20}}>{t('Clock Out')}</Text>
            </View>
            <Text style={{marginLeft:20,fontSize:18,color:'#95969d'}}>{t('Please Select Your Name')}</Text>
            <View style={{ borderWidth: 0, width: '97%', marginTop: 0, marginLeft: 6 }}>

<TouchableOpacity>
    <Image style={styles.ficon3} source={require('../../../image/per.png')} />
</TouchableOpacity>
{category?
<Dropdown
    style={[styles.dropdown]}
    placeholderStyle={styles.placeholderStyle}
    selectedTextStyle={styles.selectedTextStyle}
    itemTextStyle={{textColor:"#afb0b6"}}
    data={category}
    // value={value}
    maxHeight={300}
    labelField="label"
    valueField="value"
    placeholder={!isFocus ? (t("Mechanic Name")) : "..."}
    // value={value}
    onFocus={() => setIsFocus(true)}
    onBlur={() => setIsFocus(false)}
    onChange={(item) => {
        setValue(item.value);
        setIsFocus(false);
    }}
/>:null}
</View>
{value === null && submitted ? <Text style={styles.validate}>Please enter password </Text> : null}

<View style={{borderWidth:0,marginTop:'70%'}}>
<Text style={{ fontSize: 45, color: '#0d0d26', fontWeight: 'bold',alignSelf:'center'}}>{apitime}</Text>

                <TouchableOpacity style={styles.btn} onPress={Clockout}>
                        <Text style={styles.btninner}>
                           {t('Clock Out')}
                        </Text>
                        
                    </TouchableOpacity>
    </View>
            </ScrollView>
    </View>
)

}
export default Clockout;