import React, { useState, useEffect } from "react";
import {
        Image,
        ScrollView,
        Text,
        TouchableOpacity,
        View,
        StatusBar,
        ActivityIndicator,
        RefreshControl,

} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import { SearchBar } from "react-native-elements";
import AsyncStorage from '@react-native-community/async-storage';
import moment from 'moment';
import '../../../i18n';
import { useTranslation } from 'react-i18next';

const Atten = ({ navigation }) => {
       const [loading, setLoading] = useState(false);
        const [currentDate, setCurrentDate] = useState('');
        const [predate, setpredate] = useState('');
        const [new2,setnew2]=useState('');
        const [masterDataSource, setMasterDataSource] = useState([]);
        const [search, setSearch] = useState('');
        const [itemdate, setitemdate] = useState('');
        const [all, setall] = useState('');
        const { t, i18n } = useTranslation();
        const [Value, setValue] = useState('');
        const [currentLanguage, setLanguage] = useState('');
        const [inorout, setinorout] = useState('');

useEffect(() => {
        navigation.addListener('focus', async() => {
              const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
                        const date = moment().format("DD-MM-YYYY")
                        setCurrentDate(date)
                        const date2 = new Date();
                        date2.setDate(date2.getDate() - 1);
                        const dayYesterday = date2.getDate();
                        const month =date2.getMonth();
                        const yearyesterday=date2.getFullYear();
                        const all =  dayYesterday+'-'+'0'+month+'-'+yearyesterday
                        setpredate(all)
                       atten();
                })
         }, []);
const selectlan = async (value) => {
                setValue(value)
                if (value == '1') {
                    changeLanguage('en')
                }
                if (value == '2') {
                    changeLanguage('hi')
                }
             }
            const changeLanguage = value => {
                i18n
                    .changeLanguage(value)
                    .then(() => setLanguage(value))
                    .catch(err => console.log(err));
            };
      const atten = async () => {
                const result1 = await AsyncStorage.getItem('QasLogin')
                const screenData = JSON.parse(result1)
                const arraydate =[];
                setLoading(true);
                fetch(global.url + 'getattendance.php', {
                        method: 'POST',
                        headers: {
                                Accept: 'application/json',
                                'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                                user_id: screenData.id,
                               
                        }),
                })
                        .then((res) => res.json())
                        .then(async (json) => {
                                if (json.ResponseCode == '1') {
                                        if(json.upcomming!==null){
                                     var previousdate = '';
                                        for (let i = 0; i < json.upcomming.length; i++) {
                                                 var dates = json.upcomming[i].date
                                                 const curdate = dates.slice(-2);
                                                if(curdate == previousdate){
                                                        json.upcomming[i]['types'] = 1;
                                                        arraydate.push(json.upcomming[i])
                                                 }else{
                                                        previousdate= curdate;
                                                        json.upcomming[i]['types'] = 2;
                                                        arraydate.push(json.upcomming[i])
                                                 }
                                           }
                                        setall(arraydate)
                                       setinorout(arraydate[0].types)
                                         setMasterDataSource(arraydate)
                                } 
                                         else{
                                                setLoading(false)
                                        }
                                          setLoading(false)
                                }
                                else {
                                        alert(json.ResponseMsg)
                                }

                        })
                        .catch((err) => {
                              
                        });
        }
const searchFunction = (text) => {
               if(text){
                      if(isNaN(text)){
                              const name = masterDataSource.filter(function (item)
                                         {
                                      const itemData = item.mechanic_name
                                             ? item.mechanic_name.toUpperCase()
                                                  : "".toUpperCase();
                                                const textData = text.toUpperCase();
                                                return itemData.indexOf(textData) >-1;
                                              });
                                              setall(name)
                                                setSearch(text);
                        }
                        else{
                                const date= masterDataSource.filter(function (item) {
                                        const itemData = item.date
                                       ? item.date.toUpperCase()
                                          : "".toUpperCase();
                                        const textData = text.toUpperCase();
                                        return itemData.indexOf(textData) > -1;
                                      });
                                      setall(date)
                                        setSearch(text);
                               }
                 }
                 else{
                        setSearch(text);
                        atten();
                 }
             };
        return (
                <View style={styles.maincontainer}>
                        <ScrollView>
                                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                                <View style={{ margin: 30 }}>
                                        <View style={{ height: 10 }}></View>
                                        <TouchableOpacity onPress={() => navigation.goBack()}>
                                                <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                                        </TouchableOpacity>
                                        <TouchableOpacity >
                                                <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 10 }}>{t('Attendance')}</Text>
                                        </TouchableOpacity>
                                </View>
                                <View style={{ flexDirection: 'row',borderWidth:0 }}>
                                        <SearchBar
                                                searchIcon={{ size: 25, color: '#9696a1', marginLeft: 10 }}
                                                onChangeText={(text) => searchFunction(text)}
                                                value={search}
                                                underlineColorAndroid="transparent"
                                                placeholder={t("Search Attendance")}
                                                placeholderTextColor="#9696a1"
                                                fontSize={17}
                                                inputContainerStyle={{ backgroundColor: '#f2f2f3', borderBottomColor: 'gray', borderRadius: 8, height: 48, marginTop: -10, borderWidth: 0 }}
                                                containerStyle={{ backgroundColor: 'transparent', borderBottomColor: 'transparent', borderTopColor: 'transparent', height: 60, width: '73%',marginLeft:6 }}
                                                returnKeyType='search'

                                        />
                                        <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Clock')}>
                                               <Text style={styles.btntext}>Clock In/Out</Text>
                                        </TouchableOpacity>
                                </View>
                                <View>
                                   {all!=''?
                                                        <View style={{borderWidth:0,marginTop:20,marginLeft:10}}>
                                                        {all.map((ar,index)=>(
                                                         <View key={index}>       
                                                         <View>       
                                                         {ar.types == 2?
                                                                
                                                                <View style={{ borderWidth: 0 }}>
                                                                
                                                                        <Text style={{ fontSize: 17, color: '#0d0d26', fontWeight: 'bold', marginTop: 0, marginLeft: 15 }}>{ar.date}</Text>
                                                                
                                                                </View>  
                                                                
                                                                :null}       
                                                        </View>

                                                        
                                                              <View  style={{ borderWidth: 0 ,marginBottom:13 ,marginLeft:25}}>
                                                                 {ar.type==2?
                                                                        <Image style={{ height: 36, width: 36, borderWidth: 0, borderRadius: 10, marginTop: 7 }} source={require('../../../image/cross.png')} />
                                                                                :
                                                                        <Image style={{ height: 36, width: 36, borderWidth: 0, borderRadius: 10, marginTop: 7 }} source={require('../../../image/right.png')} />

                                                                        }      

                                                              <View style={{ position: 'absolute', left: 50, marginTop: 5, marginLeft: 10, borderWidth: 0,}}>
                                                                      <Text style={{ color: 'black', fontSize: 17, fontWeight: 'bold', borderWidth: 0,marginLeft:5 }} >{ar.mechanic_name}</Text>
                                                                      <Text style={{ fontSize: 15 }}>{ar.time}</Text>
                                                              </View>
                                                      </View>       
                                                      </View>
                                                        ))}
                                                        </View>
                                                        :
                                                        <Text style={styles.erromes}>Attendance data not found</Text>
                                                        }
                                                        <View style={{ borderWidth: 0 }}>
                                                                <Text style={{ fontSize: 15, color: '#0d0d26', fontWeight: 'bold', marginTop: 10, marginLeft: 30 }}>{new2}</Text>
                                                        </View>
                                      </View>
                        </ScrollView>
                        {loading ?
                                        <View style={styles.spinner}>
                                                <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                                        </View>
                                        : null}
                </View>
        )

}
export default Atten;