import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
        
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%'
      },
      btn:{
        // borderWidth: 1,
        marginRight:5 ,
        height:35,
        alignSelf:"center",
        marginTop:-10,
        backgroundColor:'#346696',
        justifyContent:'center',
        borderRadius:7,
        padding:4

      },
      btntext:{
      
        color:'#ffffff',
        fontWeight:'bold'
      },
      erromes:{
        fontSize:20,
        alignSelf:'center',
        marginTop:'30%'
      }
})