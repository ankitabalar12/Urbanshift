import React, { useState, useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image, StatusBar, ActivityIndicator } from 'react-native';
import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import FastImage from 'react-native-fast-image';
export default function Detail({ route, navigation }) {
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [utype, setUsertype] = useState('');
    const [carname, setCarname] = useState("");
    const [iu, setIu] = useState("");
    const [mod, setMod] = useState("");
    const [rtex, setRtex] = useState("");
    const [cexpiry, setCexpiry] = useState("");
    const [due, setDue] = useState("");
    const [ldate, setlDate] = useState("");
    const [cnum, setCnum] = useState("");
    const [last, setLast] = useState("");
    const [regi, setRegi] = useState("");
    const [carp, setCarp] = useState("");
    const [loading, setLoading] = useState(false);
    const [carname2, setCarname2] = useState("");
    const [iu2, setIu2] = useState("");
    const [mod2, setMod2] = useState("");
    const [rtex2, setRtex2] = useState("");
    const [cexpiry2, setCexpiry2] = useState("");
    const [due2, setDue2] = useState("");
    const [ldate2, setlDate2] = useState("");
    const [cnum2, setCnum2] = useState("");
    const [last2, setLast2] = useState("");
    const [carp2, setCarp2] = useState("");
    const [img, setImg] = useState("");
    const [intimg, setIntimg] = useState("");
    const [iimg, setiimg] = useState("");
    const [alldata, setAlldata] = useState("");
    const [ragistration, setragistration] = useState("");
    const [passuser, setpassuser] = useState("");
    const [Value, setValue] = useState("");
    useEffect(() => {
 async function fetchData() {
            setLoading(true)
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
            const passuser1 =route.params
            setpassuser(passuser1)
            if (passuser1 == 1) {
                setLoading(true)
                const result1 = await AsyncStorage.getItem('QasLogin')
                const screenData = JSON.parse(result1)
                const ciu = screenData.car_iu_number
                const cname = screenData.car_brand;
                const cmodel = screenData.car_model;
                const crode = screenData.road_tax_expiry_date;
                const ccoe = screenData.coe_expiry_date;
                const cin = screenData.inspection_due_date;
                const cser = screenData.last_service_date;
                const cnum = screenData.chassis_number;
                const clast = screenData.last_inspection_date
                const regdate = screenData.registration_date
                const Plate = screenData.vehicle_number
                setIu(ciu);
                setCarname(cname);
                setMod(cmodel);
                setRtex(crode);
                setCexpiry(ccoe);
                setDue(cin);
                setlDate(cser);
                setCnum(cnum);
                setLast(clast);
                setRegi(regdate);
                setCarp(Plate);
                setLoading(false)
            } else if(passuser1 != 1){
                setLoading(true)
                const information = route.params
                const ciu2 = information.car_iu_number
                const cname2 = information.car_brand;
                const cmodel2 = information.car_model;
                const crode2 = information.road_tax_expiry_date;
                const ccoe2 = information.coe_expiry_date;
                const cin2 = information.inspection_due_date;
                const cser2 = information.last_service_date;
                const cnum2 = information.chassis_number;
                const clast2 = information.last_inspection_date
                const Plate2 = information.vehicle_number
                const Eimage = information.exterior
                const reg2 = information.registration_date
                const Iimage = information.interior;
                setIu2(ciu2);
                setCarname2(cname2);
                setMod2(cmodel2);
                setRtex2(crode2);
                setCexpiry2(ccoe2);
                setDue2(cin2);
                setlDate2(cser2);
                setCnum2(cnum2);
                setLast2(clast2);
                setCarp2(Plate2)
                setImg(Eimage)
                setIntimg(Iimage)
                setAlldata(information)
                setragistration(reg2)
                setLoading(false)
            }
        }
        fetchData();
    }, [])
    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <View style={{ height: 15 }}></View>
                    {utype != '2' ?
                        <Text style={{ fontSize: 25, color: 'black', fontWeight: 'bold' }}>{t('Your Car Details')}</Text>

                        :
                        <Text style={{ fontSize: 25, color: 'black', fontWeight: 'bold' }}>{t('Car Details')}</Text>
                    }
                    {loading ?
                        <View style={styles.spinner}>
                            <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        </View>
                        : null}
                    <View style={{ height: 15 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('License Plate')}</Text>
                        </View>
                        {passuser == '1' ?
                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{carp}</Text>
                              
                            </View>
                            : <View style={styles.view}>
                                <Text style={styles.sw1}>{carp2}</Text>
                            </View>}

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('IU Number')}</Text>
                        </View>
                        {passuser == '1' ?
                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{iu}</Text>
                            </View>
                            : <View style={styles.view}>
                                <Text style={styles.sw1}>{iu2}</Text>
                            </View>}

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Brand')}</Text>
                        </View>
                        {passuser == '1' ?
                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{carname}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{carname2}</Text>
                            </View>}

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Model')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{mod}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{mod2}</Text>
                            </View>
                        }
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Road Tax Expiry')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{rtex}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{rtex2}</Text>
                            </View>}
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('COE Expiry')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{cexpiry}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{cexpiry2}</Text>
                            </View>}
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Inspection Due Date')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{due}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{due2}</Text>
                            </View>}
                    </View>
                    <View style={{ height: 10 }}></View>

                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Last Inspection Date')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{last}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{last2}</Text>
                            </View>}
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Last Service Date')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{ldate}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{ldate2}</Text>
                            </View>}
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Chassis Number')}</Text>
                        </View>
                        {passuser == '1' ?

                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{cnum}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                                <Text style={styles.sw1}>{cnum2}</Text>
                            </View>}
                    </View>
                    <View style={{ height: 10 }}></View>


                    <View style={styles.frow}>
                     
                            <View style={{ width: '50%' }}>
                                <Text style={styles.fw}>{t('Registration date')}</Text>
                    </View>
                        {passuser == '1' ?
                            <View style={{ width: '50%' }}>
                                <Text style={styles.sw}>{regi}</Text>
                            </View>
                            :
                            <View style={styles.view}>
                            <Text style={styles.sw1}>{ragistration}</Text>
                        </View>}
                    </View>
                </View>
                {passuser == 1 ?
                    null
                    :
                    <View>
                        {img ?
                            <View>
                                        <Text style={{ fontSize: 23, color: 'black', fontWeight: 'bold', paddingLeft: 30, marginTop: -13, marginBottom: 6 }}>{t('Exterior Image')}</Text>
                                        <ScrollView horizontal={true} style={{ borderWidth: 0, height: 160 }}>
                                        {img.split(',').map((img, index) => (
                                            <View style={{borderWidth: 0, width: 160, marginLeft: 10 }}>
                                                <TouchableOpacity onPress={()=>navigation.navigate('Bigimg',img)}>
                                                <FastImage resizeMode="contain" style={{ borderWidth: 0, marginRight: 10, marginLeft: 10, borderRadius: 7, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/admin/${img}` }} />
                                                </TouchableOpacity>
                                            </View>
                                            ))}
                                        </ScrollView>
                            </View>
                            : null}
                        <View>
                        {intimg ?
                        <View>
                            <Text style={{ fontSize: 23, color: 'black', fontWeight: 'bold', paddingLeft: 30, marginBottom: 6 }}>{t('Interior Image')}</Text>
                            <ScrollView horizontal={true} style={{ borderWidth: 0, height: 160 }}>
                            {intimg.split(',').map((img2, index) => (
                                <View style={{ borderWidth: 0, width: 160, marginLeft: 10 }}>
                                      <TouchableOpacity onPress={()=>navigation.navigate('Bigimg',img2)}>
                                    <FastImage resizeMode="contain" style={{ borderWidth: 0, marginRight: 10, marginLeft: 10, borderRadius: 7, height: 130 }} source={{ uri: `https://appdevelopmentsingapore.com/qas/admin/${img2}` }} />
                                    </TouchableOpacity>
                                </View>
                            ))}
                            </ScrollView>
                            </View>
                            :null}
                        </View>
                    </View>
                }
            </ScrollView>
        </View>
    );
};