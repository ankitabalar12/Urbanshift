import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    frow:{
        width: '100%', flexDirection: 'row'
    },
    fw:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18
    },
    sw:{
        textAlign: 'right', color: '#526578', fontSize: 18
    },
    sw1:{
        textAlign: 'left', color: '#526578', fontSize: 18
    },
    view:{
        width: '45%',marginLeft:10
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
    
})