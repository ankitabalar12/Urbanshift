import { StyleSheet, Platform } from "react-native";


export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    showinput: {
        flexDirection: 'row',
        borderColor:'gray',
        marginBottom: 10,
        borderColor: 'gray',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    fristdrop:{
        flexDirection: 'row',
        borderColor:'black',
        marginBottom: 10,
       
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    showinput1: {
        flexDirection: 'row',
        borderColor:'black',
        marginBottom: 10,
        borderColor: 'black',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    textInput: {
        color: 'gray',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    textInput1: {
        color: 'black',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    ficon:{
        width:25,
        height:25,
        margin:9,
    },
    email:{
        borderWidth: 1, height: 150, borderColor: 'gray', borderRadius: 10, width: '100%', flexDirection: 'row'
       
    },
    email1:{
        borderWidth: 1, height: 150, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row'
    },
    date:{
        borderWidth: 1, borderColor: 'gray', borderRadius: 10, width: '100%', flexDirection: 'row' 
    },
    date1:{
        borderWidth: 1, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row' 
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696',
      marginTop:100
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    yes: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill: {
        borderWidth: 1,
        width: '41%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'2%'
    },
    no: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout: {
        borderWidth: 1,
        width: '41%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'2%'
    },
    iconStyle:{
        color:'black'
    },
    validate:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start'
    },
    dropdown2:{

        borderWidth: 1,
        borderColor: '#000000',
        borderRadius: 10,
        height:50,
        paddingRight:10

      },
      placeholderStyle: {
        fontSize: 18,
        color: '#AFB0B6',
        fontFamily:'Poppins-bold',
        // marginLeft:'19%'

        // borderWidth:1
      },
      selectedTextStyle: {
        fontSize: 17,
        color:'#000000',
        fontFamily:'Poppins-bold',
        // marginLeft:'21%'


        // borderWidth:1
      },
      placeholderStyle2: {
        fontSize: 19,
        color: '#AFB0B6',
        fontFamily:'Poppins-bold',
       marginLeft:'8%',
        borderWidth:1
      },
      selectedTextStyle2: {
        fontSize: 18,
        color:'#000000',
        fontFamily:'Poppins-bold',
        marginLeft:'18%'


        // borderWidth:1
      },
      spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
      date1:{
        borderWidth: 1, borderColor: 'black', borderRadius: 10, width: '100%', flexDirection: 'row' 
    },
    container: {
        flex: 1,
        paddingTop: 30,
        // backgroundColor: '#ffffff',
        
        // padding: 16,
        // borderWidth:1
      },
      yes2: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill2: {
        borderWidth: 1,
        width: '35%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'1%'
    },
    no2: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout2: {
        borderWidth: 1,
        width: '35%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'1%'
    },
    yes3: {
        color: 'white',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    yesfill3: {
        borderWidth: 1,
        width: '27%',
        alignItems: 'center',
        borderRadius: 20,
        backgroundColor: '#346696',
        borderColor: '#346696',
        marginRight:'1%'
    },
    no3: {
        color: 'gray',
        textAlign: 'center',
        margin: 5,
        fontSize: 16,
    },
    noout3: {
        borderWidth: 1,
        width: '27%',
        alignItems: 'center',
        borderRadius: 20,
        borderColor: 'gray',
        marginRight:'1%'
    },
})