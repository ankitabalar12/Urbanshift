import React, { useState,useEffect } from "react";
import {
    ScrollView, Text, TextInput, TouchableOpacity, View, Image, StatusBar, Alert,Button,SafeAreaView, ActivityIndicator
} from "react-native";

import { styles } from "./styles";
import { Dropdown } from "react-native-element-dropdown";
import Ionicons from 'react-native-vector-icons/Ionicons';
import DateTimePicker from '@react-native-community/datetimepicker';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import CalendarPicker from 'react-native-calendar-picker';
import moment from 'moment';
const Customer = ({ navigation }) => {
const [value, setValue] = useState(null);
const [value1, setValue1] = useState(null);
    const [timer, settimer] = useState('')
    const [time1, setTime1] = useState(false);
    const [time2, setTime2] = useState(false);
    const [time3, setTime3] = useState(false);
    const [time4, setTime4] = useState(false);
    const [time5, setTime5] = useState(false);
    const [time6, setTime6] = useState(false);
    const [select, setSelect] = useState('');
    const [di, setdi] = useState('');
    const [dis,setdis]=useState([]);
    const [holi,setholi]=useState('');
 const [isFocus, setIsFocus] = useState(false);
    const [isregister, setIsRegister] = useState('1')
const [datePicker, setDatePicker] = useState(false);
    const [date, setDate] = useState(new Date());
    const [mess, setMess] = useState()
    const [submitted, setsubmitted] = useState(false)
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [name,setname]=useState('');
    const [Contact,setContact]=useState('');
    const [isFocus3, setIsFocus3] = useState(false);
    const [vnum,setvnum]=useState('');
    const [vbrand,setVbrand]=useState('');
    const [vmodel,setVmodel]=useState('');
    const [idd,setidd]=useState('');
    const [dropDownData2, setdropDownData2] = useState([]);
    const [loading,setLoading]=useState(false);
    const [vehicle_number, setvehicle_number] = useState('');
    const [selecteddrop2Values, setselecteddrop2Values] = useState('');
    const [selectedStartDate, setSelectedStartDate] = useState('');
    const [mac, setmac] = useState('');
    const [weekdays, setWeekdays] = useState([ 'Mon', 
    'Tue', 
    'Wed', 
    'Thur', 
    'Fri', 
    'Sat', 
    'Sun']);
    const [selectsat,setSelectsat]=useState('');
    const [apidate, setapidate] = useState('');
    const [Category, setCategory] = useState('');
    const [selmacid, setselmacid] = useState('');
 const onDateSelected = (date) => {
        setholi(0)
        const res = date.replace(/-/g,'')
        const res2 =res.replace(/ /g,'')
      for (var i=0;i<dis.length;i++){
            if(res2==dis[i]){
                Alert.alert('','Sorry, we are not opne on Sundays and Public Holidays')
                setDatePicker(true)
                setholi(1)
            }else{
                setDatePicker(false);
                setapidate(apidate)
            }
         
        }
      
        const string =date
        let firstChar = string.charAt(1); 
       if(firstChar=='7'){
           Alert.alert('','Sorry, we are not open on Sundays and Public Holidays')
            setDatePicker(true);
        }else{
            setDatePicker(false);
        }
        setSelectsat(firstChar)
        if(firstChar=='7' || holi==1){
            setapidate('')
        }else{
            let newStr = string.substr(2, string.length - 1); 
            const apidate =newStr.replace(/ /g,'')
        setSelectedStartDate(apidate);
            setapidate(apidate)
        }
      };

const changetime1 = () => {
        setTime1(true)
        setTime2(false)
        setTime3(false)
        setTime4(false)
        setTime5(false)
        const time = '9am-10:30am'
        setSelect(time);
    }
    const changetime2 = () => {
        setTime1(false)
        setTime2(true)
        setTime3(false)
        setTime4(false)
        setTime5(false)
        const time1 = '10:30am-12pm'
        setSelect(time1);
    }
    const changetime3 = () => {
        setTime1(false)
        setTime2(false)
        setTime3(true)
        setTime4(false)
        setTime5(false)
        const time2 = '1pm-2:30pm'
        setSelect(time2)
    }
    const changetime4 = () => {
        setTime1(false)
        setTime2(false)
        setTime3(false)
        setTime4(true)
        setTime5(false)
        const time3 = '2:30pm-4pm'
        setSelect(time3);
    }
    const changetime5 = () => {
        setTime1(false)
        setTime2(false)
        setTime3(false)
        setTime4(false)
        setTime5(true)
        const time4 = '4pm-6pm'
        setSelect(time4);
    }
    useEffect(() => {
        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
            getcar();
            getmac();
            dis.push('10212023','20312023','12312023','22412023','50742023','62242023','10152023','50262023','42962023','30982023','113112023','125122023')
        }
        fetchData();
       
    }, [])

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
 
    const showDatePicker = () => {
        setDatePicker(true);
    };
    const register = () => {
        setIsRegister('1')
    }

    const data = [
        { label: 'General Servicing', value: 'General Servicing' },
        { label: 'Inspection', value: 'Inspection' },
        { label: 'Others', value: 'Others' },
    ]
    const conform = async () => {
 
        console.log('selmacid>>>',selmacid)
        setsubmitted(true)
        if (value !== '' && mess !== '' && apidate !== '' && select !== '') {
            setLoading(true)
            fetch(global.url + 'addappointmentmechanic.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    mechanic_id: selmacid,
                    service_type: value,
                    adate: apidate,
                    atime: select,
                    message: mess,
                    customer_name:name,
                    customer_mobile:Contact,
                    vehicle_number:vehicle_number,
                    car_brand:vbrand,
                    car_model:vmodel,
                    car_id:idd
                }),
            })
                .then((res) => res.json())
                .then(async (json) => {
                   if (json.ResponseCode == '1') {
                       Alert.alert('',json.ResponseMsg)
                        setLoading(false)
                        navigation.navigate('Conformation')
                    }
                    else {
                        alert(json.ResponseMsg)
                        setLoading(false)
                    }
                })
                .catch((err) => {
                    console.log(err);
                    console.log(err)
                });
            }
    }


    const getcar = async () => {
        setLoading(true);
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        fetch(global.url + 'getcars.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
            }),
        })

            .then((res) => res.json())
            .then((json) => {
                if (json.ResponseCode == '1') {
                    setVbrand(json.car_brand)
                    setVmodel(json.car_model)
                    setidd(json.id)
                    var count = Object.keys(json.data).length;
                   for (var i = 0; i < count; i++) {
                        dropDownData2.push({ value: json.data[i].id, label: json.data[i].vehicle_number, model: json.data[i].car_model, brand: json.data[i].car_brand }); // Create your array of data
                    }
                    dropDownData2.push({ value: 0, label: 'Other' })
                    setvnum(dropDownData2);
                    setLoading(false);

                }
                else {
                    alert(json.ResponseMsg)
                    setLoading(false)
                }

            })
            .catch((err) => {
                console.log(err);
                console.log(err)
            });
    }
    const setvehiclenumber = (val) => {
        setselecteddrop2Values(val.value)
        for (var i = 0; i < dropDownData2.length; i++) {
            if (dropDownData2[i].value == val.value) {
                const selectval = dropDownData2[i]
                setVbrand(selectval.brand)
                setidd(selectval.value)
                setVmodel(selectval.model)
            }
        }

    }


    const getmac = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setLoading(true);
        fetch(global.url + 'getmechanics.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {

                if (json.ResponseCode == '1') {
                    var count = Object.keys(json.upcomming).length;
                    let dropDownData = [];
                    for (var i = 0; i < count; i++) {
                        dropDownData.push({ value: json.upcomming[i].id, label: json.upcomming[i].full_name, type: json.upcomming[i].type }); // Create your array of data
                    }
                    setCategory(dropDownData);
                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }
 return(
    <View style={styles.maincontainer}>
        <ScrollView>
            <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
            <View style={{ margin: 20 }}>
                <View style={{ height: 10 }}></View>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                </TouchableOpacity>
                <View style={{ height: 10 }}></View>
                <Text style={{ marginTop: 10, fontSize: 25, color: 'black' }}>
                    {t('Appointment for customers')}
                </Text>
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        
                    </View>
                    : null}
                <View style={{ height: 10 }}></View>
                <View style={styles.fristdrop}>
                            <Image style={{  height: 30, width: 35,alignSelf:'center',marginTop:6,marginLeft:10}} source={require('../../../image/carlogo.png')} />
                    <View style={{ width: '80%', marginHorizontal: 13, letterSpacing: 1.5, fontSize: 18  ,alignSelf:'center',margin:5}}>
                            {vnum?
                            <Dropdown
                            style={[styles.dropdown]}
                            placeholderStyle={styles.placeholderStyle}
                            selectedTextStyle={styles.selectedTextStyle}
                            iconStyle={styles.iconStyle}
                            data={vnum}
                            maxHeight={300}
                            labelField="label"
                            valueField="value"
                            placeholder={!isFocus ? t('Vehicle Number') : '...'}
                            // value={vnum}
                            onFocus={() => setIsFocus(true)}
                            onBlur={() => setIsFocus(false)}
                            onChange={(item) => {
                                setvehicle_number(item.label)
                                setvehiclenumber(item)
                            }}
                        />:null}
                        </View>
                        </View>
                        {selecteddrop2Values == '0' ?
                            <View style={{ borderWidth: 1, padding: '0%', borderColor: '#000000', borderRadius: 10 ,marginTop:15 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                    <TextInput onChangeText={(value) => setvehicle_number(value)}  placeholder={t("Vehicle Number")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>

                                </View>
                               

                            </View>

                            : null}
                        <View style={{ height: 10 }}></View>

                        <View style={{ borderWidth: 1, padding: '0%', borderColor: '#000000', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                <TextInput onChangeText={(value) => setVbrand(value)} value={vbrand} placeholder={t("Vehicle Brand")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>

                            </View>
                        </View>
                        <View style={{ height: 15}}></View>
                    

                        <View style={{ borderWidth: 1, borderColor: '#000000', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />

                                <TextInput onChangeText={(value) => setVmodel(value)} value={vmodel} placeholder={t("Vehicle Model")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}></TextInput>
                            </View>
                        </View>

                        <View style={{ height: 15}}></View>
                        {Category?
                              <View style={styles.fristdrop}>
                              <Image style={{  height: 30, width: 35,alignSelf:'center',marginTop:6,marginLeft:10}} source={require('../../../image/carlogo.png')} />
                      <View style={{ width: '80%', marginHorizontal: 13, letterSpacing: 1.5, fontSize: 18  ,alignSelf:'center',margin:5}}>
                              {vnum?
                              <Dropdown
                              style={[styles.dropdown]}
                              placeholderStyle={styles.placeholderStyle}
                              selectedTextStyle={styles.selectedTextStyle}
                              iconStyle={styles.iconStyle}
                              data={Category}
                              maxHeight={300}
                              labelField="label"
                              valueField="value"
                              placeholder={!isFocus ? t('Booked By') : '...'}
                              // value={vnum}
                              onFocus={() => setIsFocus(true)}
                              onBlur={() => setIsFocus(false)}
                              onChange={(item) => {
                                  setmac(item.label)
                                  setselmacid(item.value)
                                
                              }}
                          />:null}
                          </View>
                          </View>
                        :null
                        }
              
                        <View style={{ borderWidth: 1, marginLeft: '0%', marginRight: '0%', padding: '0%', borderColor: '#000000', borderRadius: 10, marginTop: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/per.png')} />
                                <TextInput onChangeText={(value) => setname(value)} value={name} placeholder={t("Customer Name")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>

                            </View>
                        </View>
                        <View style={{ borderWidth: 1, marginLeft: '0%', marginRight: '0%', padding: '0%', borderColor: '#000000', borderRadius: 10, marginTop: 20 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/call.png')} />
                                <TextInput onChangeText={(value) => setContact(value)} value={Contact} placeholder={t("Customer Mobile")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>

                            </View>
                        </View>
                <View style={{ height: 10 }}></View>

                <Text style={{ fontSize: 17 }}>{t('Create new servicing appointment.')}</Text>
                <View style={{ height: 10 }}></View>
                <View style={isregister == '0' ? styles.showinput : styles.showinput1}>
                    {isregister == '0' ?
                        <Image style={styles.ficon} source={require('../../../image/type.png')} />
                        :
                        <Image style={styles.ficon} source={require('../../../image/type1.png')} />
                    }
                    <View style={{ width: '80%', marginHorizontal: 15, letterSpacing: 1.5, fontSize: 18 }}>
                        
                        <Dropdown
                            style={[styles.dropdown]}
                            placeholderStyle={styles.placeholderStyle}
                            selectedTextStyle={styles.selectedTextStyle}
                            iconStyle={styles.iconStyle}
                            data={data}
                            maxHeight={300}
                            labelField="label"
                            valueField="value"
                            placeholder={!isFocus ? t('Type of Servicing') : '...'}
                            value={value}
                            onFocus={() => setIsFocus(true)}
                            onBlur={() => setIsFocus(false)}
                            onChange={(item) => {
                                setValue(item.value);
                                setIsFocus(false);
                            }}
                        />
                    </View>
                </View>
                {value === null && submitted ? <Text style={styles.validate}>{t('Please Select Servicing')}</Text> : null}
                <View style={{ height: 10 }}></View>
                <View style={isregister == '0' ? styles.email : styles.email1}>
                    <View style={{ width: '20%' }}>

                        {isregister == '0' ?
                            <Image style={styles.ficon} source={require('../../../image/emailnew.png')} />
                            :
                            <Ionicons name="mail-outline" size={25} style={{ margin: 10 }} />
                        }
                    </View>
                    <View style={{ width: '80%' }}>
                        <TextInput
                            multiline={true}
                            numberOfLines={5}
                            keyboardType='default'
                            placeholder={t("Enter here")}
                            onChangeText={(value) => setMess(value)} value={mess}
                            style={{ height: 120, textAlignVertical: 'top', borderRadius: 10 ,color:'#000000',fontSize:20}} />
                    </View>
                </View>
                {mess === undefined && submitted ? <Text style={styles.validate}>{t('Please Enter Message')}</Text> : null}
                <View style={{ height: 10 }}></View>
                <Text style={{ fontSize: 20, color: 'gray' }}>{t('Select your date & time(DD-M-YYYY)')}</Text>
                <View style={{ height: 10 }}></View>
              
                <TouchableOpacity onPress={showDatePicker}>
                    <View style={styles.date1}>
                       
                                <Image style={styles.ficon} source={require('../../../image/datenew1.png')} />
                                {selectsat=='7' || holi=='1'?
                                // <Text style={{alignSelf:'center',fontSize:16}}>null</Text>
                               null

                                :
                                <Text style={{alignSelf:'center',fontSize:16}}>{selectedStartDate.toString()}</Text>
                                }
                       </View>
                    </TouchableOpacity>


                        <SafeAreaView>       
      <View style={styles.container}>
       
        {datePicker?
        <CalendarPicker
          startFromMonday={true}
        //   allowRangeSelection={true}
          minDate={new Date(2018, 1, 1)}
          maxDate={new Date(2050, 6, 3)}
          weekdays={weekdays}
       
          months={[
            'January',
            'Febraury',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December',
          ]}
          previousTitle="Previous"
          nextTitle="Next"
          todayBackgroundColor="#e6ffe6"
          selectedDayColor="#66ff33"
          selectedDayTextColor="#000000"
          scaleFactor={375}
          textStyle={{
            fontFamily: 'Cochin',
            color: '#000000',
          }}
        onDateChange={(res) => onDateSelected(moment(res).format(" E DD - M - YYYY"))}
       
        />:null}
    
      </View>
      </SafeAreaView>  
              <View style={{ height: 20 }}></View>
                {
                    isregister == '1' ?
                        <View>
                            <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                            <TouchableOpacity onPress={changetime1} style={time1 ? styles.yesfill : styles.noout}>
                                        <Text style={time1 ? styles.yes : styles.no}>
                                        9am - 10:30am
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime2} style={time2 ? styles.yesfill : styles.noout}>
                                        <Text style={time2 ? styles.yes : styles.no}>
                                           10:30am - 12pm
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            <View style={{ height: 10 }}></View>
                            {selectsat != 6?
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                <TouchableOpacity onPress={changetime3} style={time3 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time3 ? styles.yes2 : styles.no2}>

                                            1pm - 2:30pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime4} style={time4 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time4 ? styles.yes2 : styles.no2}>
                                           2:30pm - 4pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime5} style={time5 ? styles.yesfill3 : styles.noout3}>
                                        <Text style={time5 ? styles.yes3 : styles.no3}>
                                           4pm -6pm
                                        </Text>
                                    </TouchableOpacity>
                                    
                                </View>
                                :
                                <View style={{ flexDirection: 'row', height: 40, width: '100%' }}>
                                <TouchableOpacity onPress={changetime3} style={time3 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time3 ? styles.yes2 : styles.no2}>

                                            1pm - 3pm
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={changetime4} style={time4 ? styles.yesfill2 : styles.noout2}>
                                        <Text style={time4 ? styles.yes2 : styles.no2}>
                                           3pm - 5pm
                                        </Text>
                                    </TouchableOpacity>
                                  </View>
                                
                                }
                        </View>

                        : null
                }
                {select === '' && submitted ? <Text style={styles.validate}>{t('Please Enter time')}</Text> : null}

                <View style={{ height: 50 }}></View>
                {
                    isregister == '0' ?
                        <TouchableOpacity style={styles.btn} onPress={register}>
                            <Text style={styles.btninner}>
                                Register
                            </Text>
                        </TouchableOpacity>
                        :
                        <TouchableOpacity style={styles.btn} onPress={conform}>
                            <Text style={styles.btninner}>
                                {t('Confirm')}
                            </Text>
                        </TouchableOpacity>
                }
            </View>
        </ScrollView>
    </View>
    )

}

export default Customer;