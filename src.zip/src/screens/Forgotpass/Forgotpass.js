import React, { useState } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, Image } from 'react-native';
import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';


export default function Forgotpass({ navigation }) {
    const [email, setEmail] = useState("");
    const [submitted, setsubmitted] = useState(false)
    const login = () => {
        setsubmitted(true)
        //console.log(email)
        if (email !== '') {
            fetch(global.url+'forgotpassword.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email
                }),
            })
                .then((res) => res.json())
                .then(async (json) => {
                    //console.log(json)
                    if (json.ResponseCode == '1') {
                        alert(json.ResponseMsg)
                        navigation.navigate('Login')
                        setEmail('');
                    } else {
                        alert(json.ResponseMsg)
                    }
                })
                .catch((err) => {
                    //console.log(err);
                    //console.log(err)
                });
        }
    }

    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <View style={{ margin: 20 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <View style={{ height: 20 }}></View>
                    <Text style={{ marginTop: 10, fontSize: 35, color: 'black', fontWeight: 'bold' }}>
                        Forgot Password
                    </Text>
                    <Text style={{ marginTop: 10, fontSize: 17 }}>
                        Enter your email below and we will send you a reset password link to your email.
                    </Text>
                    <View style={{ height: 20 }}></View>
                    <View style={styles.showinput}>
                        {/* <Image style={styles.ficon1} source={require('../../../image/email.png')} /> */}
                        <Ionicons name="mail-outline" size={25} style={{ margin: 6 }} />
                        <TextInput style={styles.textInput}  onChangeText={(value) => setEmail(value)} value={email}  placeholder="E-mail" />
                    </View>
                    {email === '' && submitted ? <Text style={styles.validate}>Please enter Email </Text> : null}
                    <View style={{ height: 20 }}></View>
                    <TouchableOpacity style={styles.btn} onPress={login}>
                        <Text style={styles.btninner}>
                            Send code
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};