import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    ficon:{
        height:30,
        width:30,
        color:'black'
    },
    showinput: {
        flexDirection: 'row',
        marginBottom: 10,
        borderColor: '#aaaaaa',
        borderWidth: 1,
        width: '100%',
        borderStyle: 'solid',
        borderRadius:10,
        alignSelf: 'center',fontFamily:'Poppins-Regular'
    },
    textInput: {
        color: '#000000',
        paddingBottom: 3,
        marginLeft: 10,
        padding:5,fontFamily:'Poppins-Regular',
        width:'70%'
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    ficon1:{
        width:22,
        height:20,
        margin:10
    },
    validate:{
        color:'#cc1a1a',
        textAlign:'left',
        alignContent:'flex-start'
    }
    
})