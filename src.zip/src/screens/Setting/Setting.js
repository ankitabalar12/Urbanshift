import React, { useState, useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, View, StatusBar, Image,Alert } from 'react-native';
import { styles } from './styles';
import { Dropdown } from "react-native-element-dropdown";
import Ionicons from 'react-native-vector-icons/Ionicons';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import { resetNavigateTo } from '../../../NavigationHelper';

export default function Setting({ navigation }) {
    const [value, setValue] = useState('1');
    const [isFocus, setIsFocus] = useState(false);
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('en');

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };

    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
        await AsyncStorage.setItem('lunguage',currentLanguage)
        await AsyncStorage.setItem('type', value)

    }
const data = [
        { label: 'English', value: '1' },
        { label: 'Chinese', value: '2' },
    ]
useEffect(() => {
        async function fetchData() {
            const result = await AsyncStorage.getItem('lunguage');
            //console.log('launuage => ', result);
            const type = await AsyncStorage.getItem('type');
            //console.log('type== => ', type);
            setValue(type)
        }
        fetchData();
    }, [])
    const logout=()=>{
        Alert.alert(  
            '',  
            (t('Are you sure you want to logout?')),  
            [  
                {  
                    text: (t('Yes')),  
                    onPress: () =>{
                        AsyncStorage.removeItem('QasLogin')
                        resetNavigateTo(navigation, 'Loginoption');
                    } 
                  ,  
                   
                },  
                {text: (t('No')), onPress: () => console.log('OK Pressed')},  
            ]  
        );
    }

    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 20 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <View style={{ height: 30 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row' }}>
                        <View style={{ width: '70%' }}>
                            <Text style={{ fontSize: 25, color: 'black' }}>{t('Setting')}</Text>
                        </View>
                        <View style={{ width: '30%' }}>
                            <Dropdown
                                style={[styles.dropdown]}
                                placeholderStyle={styles.placeholderStyle}
                                selectedTextStyle={styles.selectedTextStyle}
                                iconStyle={styles.iconStyle}
                                data={data}
                                maxHeight={300}
                                labelField="label"
                                valueField="value"
                                placeholder={!isFocus ? 'Language' : '...'}
                                value={value}
                                onFocus={() => setIsFocus(true)}
                                onBlur={() => setIsFocus(false)}
                                onChange={(item) => {
                                    selectlan(item.value);
                                    setIsFocus(false);
                                }}
                            />
                        </View>
                    </View>
                    <View style={{ height: 30 }}></View>
                    <View style={{ width: '100%', flexDirection: 'row' ,marginBottom:20}}>
                        <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Editprofile')}>
                            <View style={{ width: '96%', height: 170, backgroundColor: 'white', borderRadius: 10 }}>
                                <Image style={{ height: 50, width: 50, marginTop: 40, alignSelf:'center' }} source={require('../../../image/setingp.png')} />
                                <Text style={{ fontSize: 18, textAlign: 'center' }}>{t('Edit Profile')}</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Support')}>
                            <View style={{ width: '96%', height: 170, backgroundColor: 'white', borderRadius: 10 }}>
                                <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center'  }} source={require('../../../image/mess.png')} />
                                <Text style={{ fontSize: 18, textAlign: 'center' ,marginLeft:13}}>{t('Support')}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={{ width: '100%', flexDirection: 'row' }}>
                        <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Terms')}>
                            <View style={{ width: '96%', height: 170, backgroundColor: 'white', borderRadius: 10 }}>
                                <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center'  }} source={require('../../../image/doc.png')} />
                                <Text style={{ fontSize: 18, textAlign: 'center' }}>{t('Terms & Conditions')}</Text>
                            </View>
                        </TouchableOpacity>
                  
                        <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={logout}>
                            <View style={{ width: '96%', height: 170, backgroundColor: 'white', borderRadius: 10 }}>
                                <Image style={{ height: 50, width: 50, marginTop: 36, alignSelf:'center'  }} source={require('../../../image/logout.png')} />
                                <Text style={{ fontSize: 18, textAlign: 'center' }}>{t('Logout')}</Text>
                            </View>
                        </TouchableOpacity>
                       </View>
                </View>
            </ScrollView>
        </View>
    );
};