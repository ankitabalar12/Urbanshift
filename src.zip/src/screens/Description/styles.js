import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    btn:{
        height:30,borderRadius:3,backgroundColor:'#346696',
        position:'absolute',
        width:'23%',
        right:'1%',
        top:'33%',
       
    },
    btninner:{
       color:'white',
       fontSize:18,
       fontWeight:'bold',
       alignSelf:'center',
       marginTop:3,

       position:'absolute',
    //    marginTop:1
    },
    hadding:{
                // borderWidth:1,
                marginLeft:'5%',
                marginRight:'5%',
                // flex:1,
                flexDirection:'row',
                paddingTop:'1%',
                borderBottomWidth:1
},
    h1:{
                // borderWidth:1,
                // margin:'2%',
                width:'38%',
                height:30,
                marginTop:10,
               borderRightWidth:1,
           
    },
    h2:{
        width:'21%',
        height:30,
        marginTop:10,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
      
        // paddingLeft:3,
        // marginRight:5
        // left:20
    },
    h3:{
        width:'16%',
        height:30,
        marginTop:10,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        // paddingLeft:6,
       
    },
    h4:{
        width:'25%',
        height:30,
        marginTop:10,
        // borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        // paddingLeft:5
    },
    frow:{
        flexDirection:'row',
        // paddingTop:'1%',
        borderBottomWidth:1,
        marginLeft:'5%',
        marginRight:'5%',
        // borderWidth:1,
        height:70,
    
       


    },
    f1:{
        width:'38%',
        height:70,
        // marginTop:5,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        alignSelf:'center'
        // borderWidth:1,
    //    paddingTop:'2%',
    //    paddingBottom:'2%'
    //    margin:'1%'
    },
    last:{
        width:'38%',
        height:70,
        // marginTop:5,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        // borderWidth:1,
       paddingTop:'2%'
    },
    text:{
        fontSize:16,  
        color:'#9e9ea7',   
      width:'38%',
      borderRightWidth:2,
      borderColor:'#83838a',
    height:51,
    textAlignVertical:'center'
   

    },
    text2:{
        fontSize:16,  
        color:'#9e9ea7',   
      width:'38%',
      borderRightWidth:2,
      borderColor:'#83838a',
    height:51,
    textAlignVertical:'center',
    // backgroundColor:'red',
    // borderWidth:1
   

    },
   
    
    f4:{
        width:'27%',
        height:46,
        // marginTop:10,
        // borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:5,
        borderWidth:1,
        marginLeft:'-34%'
    },
    f5:{
        width:'38%',
        height:70,

        // marginTop:10,
        borderRightWidth:1,
        fontSize:16,
        color:'#000000',
        paddingLeft:5,
        
        // borderWidth:1,
    },
    radiostyle:{
        // borderWidth:1,
        borderRightWidth:1,
        width:'37%',
      
        // color:'#9e9ea7',   
        // bordercolor:'#9e9ea7',
     

    },
    btn1:{
        height:30,
        borderRadius:3,
        backgroundColor:'#346696',
       marginRight:20,
        width:'20%',
        // borderWidth:1
      
       
    },
    btninner1:{
       color:'white',
       fontSize:18,
       fontWeight:'bold',
       marginTop:3,
    alignSelf:'center',
   
    //    borderWidth:1
   
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
      addicon:{
        flex: 0,width:23,height:23,borderWidth:0,marginLeft:'8%',marginTop:7
      },
      othertextt:{
        borderWidth:1

      },
      checkbox:{
        borderWidth:1,
        borderColor:'red'
      },
      rows:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        width:'89%',
        alignSelf:'center',
        borderColor:'#83838a', 
        borderBottomWidth:2
      },
      redio:{
        // borderWidth:2,
        width:'21.3%',
        borderRightWidth:2,
        borderColor:'#83838a',
        justifyContent:'center',
        alignItems:'center'
      },
      disableredio:{
        // borderWidth:2,
        width:'16.2%',
        borderRightWidth:2,
        borderColor:'#83838a',
        justifyContent:'center',
        alignItems:'center'
      },
      textinput:{
        // borderWidth:1,
        width:'25%'
      }
   
    
})