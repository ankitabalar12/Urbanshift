import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    SafeAreaView,
    ActivityIndicator
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import RadioGroup from "react-native-radio-buttons-group/lib/RadioGroup";
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import FastImage from 'react-native-fast-image';
import { PureRoundedCheckbox } from "react-native-rounded-checkbox";
import { nativeViewHandlerName } from "react-native-gesture-handler/lib/typescript/handlers/NativeViewGestureHandler";

const Des1 = ({ navigation, route }) => {
    const [ot, setot] = useState(0)
    const [count, setCount] = useState(1)
    const [select, setSelect] = useState(0);
    const [selectdone, setSelectdone] = useState(1);
    const [Remark, setremark] = useState([]);
    const [data, setData] = useState('');
    const [done, setdone] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [passdes, setpassdes] = useState('');
    const [req, setreq] = useState([]);
    const [desc, setdesc] = useState([]);
    const [newdesc, setnewdesc] = useState([]);
    const [other, setother] = useState([]);
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [loading, setLoading] = useState(false);
    const [finalreq, setfinalreq] = useState('');
    const [plus, setplus] = useState(33);
    const [onetimeadd, setonetimeadd] = useState(32);

    const Repairarray = route.params
    useEffect(() => {
        navigation.addListener('focus', async () => {
            setLoading(true)

            global.isFound = false;
            // desc = []
            console.log(desc.length);
            if (desc.length == 0) {
                desc.push(
                    { label: 'Inspection(检验)', value: '0', selected: global.isFound },
                    { label: 'Servicing(保养)', value: '1', selected: global.isFound },
                    { label: 'Air Filter', value: '2', selected: global.isFound },
                    { label: 'Fule Filter(柴油过滤器)', value: '3', selected: global.isFound },
                    { label: 'Wiper', value: '4', selected: global.isFound },
                    { label: 'AdBlue/Gear oil', value: '5', selected: global.isFound },
                    { label: 'Bulb(灯泡)', value: '6', selected: global.isFound },
                    { label: 'Aircon Filter', value: '7', selected: global.isFound },
                    { label: 'Ac compressorr', value: '8', selected: global.isFound },
                    { label: 'Ac Condensorr', value: '9', selected: global.isFound },
                    { label: 'Ac Gas/Comp oil', value: '10', selected: global.isFound },
                    { label: 'Battery', value: '11', selected: global.isFound },
                    { label: 'Type/Patch Type', value: '12', selected: global.isFound },
                    { label: 'Type Alignment', value: '13', selected: global.isFound },
                    { label: 'Brake Pad/Disc/oil', value: '14', selected: global.isFound },
                    { label: 'Starter/Alternator(马达发电机)', value: '15', selected: global.isFound },
                    { label: 'Clutch', value: '16', selected: global.isFound },
                    { label: 'Radiator(水柜)', value: '17', selected: global.isFound },
                    { label: 'Belting(皮带)', value: '18', selected: global.isFound },
                    { label: 'Power Steering/Oil', value: '19', selected: global.isFound },
                    { label: 'Computer reset', value: '20', selected: global.isFound },
                    { label: 'Horn', value: '21', selected: global.isFound },
                    { label: 'Centeral Oil/Door Lock', value: '22', selected: global.isFound },
                    { label: 'Power Window/Mirror', value: '23', selected: global.isFound },
                    { label: 'Windscreen', value: '24', selected: global.isFound },
                    { label: 'panel Beating(敲工)', value: '25', selected: global.isFound },
                    { label: 'Wiring/Accessories', value: '26', selected: global.isFound },
                    { label: 'Partition/Box', value: '27', selected: global.isFound },
                    { label: 'Camera/SD Card', value: '28', selected: global.isFound },
                    { label: 'Ventilator(车顶通风机)', value: '29', selected: global.isFound },
                    { label: 'Polish/Spray Paint(打磨/喷漆)', value: '30', selected: global.isFound },
                    { label: 'Logo(广告)', value: '31', selected: global.isFound },
                    { label: 'Others', value: '32', selected: global.isFound },
                )
            } else {
                setLoading(false)
                return [...desc]
            }
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)

            const Repairarray = route.params
            const screenData = JSON.parse(Repairarray);

            var data = screenData.map(function (item) {
                return {
                    key: item.id,
                    label: item.name
                };
            });
            let difference;
            if (data[23].label != '') {
                const sp = data[23].label.split(',')
                global.passarray = sp
                const value1 = sp.length;
                const value2 = desc.length;
                difference = value1 - value2;
            }

            if (data[13].label != '') {

                for (var i = 0; i < desc.length; i++) {

                    // if (data[13].label != '') {
                    setfinalreq(data[13].label.split(','))

                    data[13].label.split(',').some(element => {

                        if (desc[i].value == element) {
                            newdesc[i] = { label: desc[i].label, value: desc[i].value, selected: true };
                            return true;

                        } else {
                            newdesc[i] = { label: desc[i].label, value: desc[i].value, selected: false };
                        }

                    })
                    // }
                }
            } else {
                newdesc.push(
                    { label: 'Inspection(检验)', value: '0', selected: global.isFound },
                    { label: 'Servicing(保养)', value: '1', selected: global.isFound },
                    { label: 'Air Filter', value: '2', selected: global.isFound },
                    { label: 'Fuel Filter(柴油过滤器)', value: '3', selected: global.isFound },
                    { label: 'Wiper', value: '4', selected: global.isFound },
                    { label: 'AdBlue/Gear oil', value: '5', selected: global.isFound },
                    { label: 'Bulb(灯泡)', value: '6', selected: global.isFound },
                    { label: 'Aircon Filter', value: '7', selected: global.isFound },
                    { label: 'Ac compressorr', value: '8', selected: global.isFound },
                    { label: 'Ac Condensorr', value: '9', selected: global.isFound },
                    { label: 'Ac Gas/Comp oil', value: '10', selected: global.isFound },
                    { label: 'Battery', value: '11', selected: global.isFound },
                    { label: 'Type/Patch Type', value: '12', selected: global.isFound },
                    { label: 'Type Alignment', value: '13', selected: global.isFound },
                    { label: 'Brake Pad/Disc/oil', value: '14', selected: global.isFound },
                    { label: 'Starter/Alternator(马达发电机)', value: '15', selected: global.isFound },
                    { label: 'Clutch', value: '16', selected: global.isFound },
                    { label: 'Radiator(水柜)', value: '17', selected: global.isFound },
                    { label: 'Belting(皮带)', value: '18', selected: global.isFound },
                    { label: 'Power Steering/Oil', value: '19', selected: global.isFound },
                    { label: 'Computer reset', value: '20', selected: global.isFound },
                    { label: 'Horn', value: '21', selected: global.isFound },
                    { label: 'Centeral Oil/Door Lock', value: '22', selected: global.isFound },
                    { label: 'Power Window/Mirror', value: '23', selected: global.isFound },
                    { label: 'Windscreen', value: '24', selected: global.isFound },
                    { label: 'Panel Beating(敲工)', value: '25', selected: global.isFound },
                    { label: 'Wiring/Accessories', value: '26', selected: global.isFound },
                    { label: 'Partition/Box', value: '27', selected: global.isFound },
                    { label: 'Camera/SD Card', value: '28', selected: global.isFound },
                    { label: 'Ventilator(车顶通风机)', value: '29', selected: global.isFound },
                    { label: 'Polish/Spray Paint(打磨/喷漆)', value: '30', selected: global.isFound },
                    { label: 'Logo(广告)', value: '31', selected: global.isFound },
                    { label: 'Others', value: '32', selected: global.isFound },
                    // { label: 'Wiper', value: '33' ,selected:global.isFound},
                )
            }

            for (var m = 1; m <= difference; m++) {
                const add = 32 + m
                data[13].label.split(',').some(element => {

                    if (element == add) {
                        //console.log('add==> ', element, '==', add)
                        newdesc[add] = { label: global.passarray[add], value: add, selected: true }
                        return true;
                    } else {
                        newdesc[add] = { label: global.passarray[add], value: add, selected: false };
                    }
                    // //console.log('==== newdesc ', newdesc)
                })
            }
            console.log('==== newdesc ', newdesc)


            setLoading(false)
        });
    }, [navigation])


    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const addlabel = (label, index, othertext) => {
        newdesc[index] = { label: label, value: index, selected: '' };
        // //console.log('newdesc add label>>>',newdesc)
    }
    const addmore = (label, index, othertext) => {
        //console.log('index',index)
        index++;
        setplus(index)
        newdesc[index] = { label: '', value: index, selected: '' };
        // //console.log('index add 34 and addmore label>>',plus)
        // //console.log('newdesc add more>>', newdesc)
    }
    const handleToggleCheckboxtwo = (label, index, othertext) => {
        //console.log('index>>', index)
        // setonetimeadd(index +1)
        // setplus(index);
        if (index == '32') {
            req.push("32")
            index++;
            newdesc[index] = { label: '', value: index, selected: '' };
            req.push("33")
        }
        if (!req.includes(index)) {
            req.push(index)
            const filteredArray = req.filter((item) => item !== undefined);
            global.finalreq = filteredArray
            const final = filteredArray.toString()
            setfinalreq(final)
            //console.log('final>>>',final)
            //console.log('req.toString>>',req)
        } else {
            var indexx = req.indexOf(index)
            req.splice(indexx, 1);
            handleToggleCheckboxtwo();
        }
    }
    const alldata = {
        des: newdesc,
        requirement: finalreq,
        done: done,
        rem: Remark,
        Repair: Repairarray
    }

    const passarray = async () => {
        navigation.navigate('Inspection', alldata)
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#fafafd' }}>
            <View style={styles.maincontainer}>
                <ScrollView style={{ marginBottom: 13 }}>
                    <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                    <View style={{ margin: 30 }}>
                        <View style={{ height: 10 }}></View>
                        <TouchableOpacity style={{ width: '20%' }} onPress={() => navigation.goBack()}>
                            <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.btn} onPress={passarray} >
                            <Text style={styles.btninner}>
                                {t('Next')}
                            </Text>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.hadding}>
                        <View style={styles.h1}><Text style={{ fontSize: 16, fontWeight: 'bold', borderWidth: 0 }}>{t('Description')}</Text></View>
                        <View style={styles.h2}><Text style={{ fontSize: 16, fontWeight: 'bold', textAlign: 'center' }}>{t('Req Attn')}</Text></View>
                        <View style={styles.h3}><Text style={{ fontSize: 16, fontWeight: 'bold', textAlign: 'center' }}>{t('Done')}</Text></View>
                        <View style={styles.h4}><Text style={{ fontSize: 16, fontWeight: 'bold', textAlign: 'center' }}>{t('Remarks')}</Text></View>
                    </View>
                    {newdesc ?
                        <View>
                            {newdesc.map((o, index) => (
                                <View key={index} style={styles.rows}>
                                    {o.value > 32 ?
                                        // <TextInput onChangeText={(value) => handleToggleCheckboxtwo(value,onetimeadd)}  style={styles.text2}></TextInput>
                                        <TextInput onEndEditing={(event) => addlabel(event.nativeEvent.text, o.value)} style={styles.text2}>{o.label}</TextInput>
                                        :
                                        <Text style={styles.text}>{o.label}</Text>
                                    }
                                    <View style={styles.redio}>
                                        <PureRoundedCheckbox
                                            borderColor={'gray'}
                                            backgroundColor={"white"}
                                            iconColor={'#5c8ee0'}
                                            isChecked={o.selected}
                                            // isChecked={index}
                                            // isChecked={seloccu.includes(o.label)}
                                            text=''
                                            // textStyle={{ width: 150, fontSize: 17, height: 30, borderWidth: 0, marginLeft: 170, paddingLeft: 15 }}
                                            uncheckedTextColor='gray'
                                            checkedTextColor='gray'
                                            innerStyle={{ height: 18, borderWidth: 1, width: 18, borderColor: 'gray' }}
                                            outerStyle={{ height: 15, width: 15, borderWidth: 0, marginTop: 0 }}
                                            onPress={(checked) => handleToggleCheckboxtwo(o.label, o.value)}
                                            checkedColor={'#5c8ee0'} />
                                    </View>
                                    <View style={styles.disableredio}>
                                        <PureRoundedCheckbox
                                            borderColor={'gray'}
                                            backgroundColor={"white"}
                                            iconColor={'#5c8ee0'}
                                            text=''
                                            innerStyle={{ height: 18, borderWidth: 1, width: 18, borderColor: 'gray' }}
                                            outerStyle={{ height: 15, width: 15, borderWidth: 0, marginTop: 0 }}
                                            disabled={true}
                                        />
                                    </View>
                                    <TextInput editable={false} style={styles.textinput}></TextInput>
                                </View>
                            ))}
                        </View>
                        : null}
                    {/* <TouchableOpacity  onPress={(checked) => addmore('',plus)}><Text>add</Text></TouchableOpacity> */}
                    <TouchableOpacity style={styles.addicon} onPress={(checked) => addmore('', plus)}><FastImage resizeMode="stretch" style={{ flex: 1 }} source={require('../../../image/add.png')} /></TouchableOpacity>
                    <View style={{ borderWidth: 0, width: '100%', justifyContent: 'flex-end', flexDirection: 'row', marginTop: 10 }}>
                        <TouchableOpacity onPress={passarray} style={styles.btn1}>
                            {/* <TouchableOpacity  onPress={checkTextInput} style={styles.btn1}> */}
                            <Text style={styles.btninner1}>
                                {t('Next')}
                            </Text>
                        </TouchableOpacity>
                    </View>
                </ScrollView>

                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
            </View>
        </SafeAreaView>
    )
}
export default Des1;