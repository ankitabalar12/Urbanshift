import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    SafeAreaView,
    ActivityIndicator,
    Alert
} from "react-native";
import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-community/async-storage';
import '../../../i18n';
import { useTranslation } from 'react-i18next';

const Draff = ({ navigation, route }) => {

    const [vnumber,setvnumber]=useState('');
    const [array,setarray]=useState('');
    const [old,setold]=useState([]);
    const [full,setfull]=useState('');
    const [loading, setLoading] = useState(false);
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');

   useEffect(()=>{
        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            //console.log('type== => ', typee);
            selectlan(typee)
          const home =route.params
          //console.log('HOme>>',home)
           if(home!='1'){
            Alert.alert(  
                '',  
               (t('Successfully save in draft')),  
                [  
                    {  
                        
                    },  
                    {text: (t('OK')),
                  
                     onPress: () =>
                    navigation.navigate('Home')
                    },  
                ]  
            );
            getdraff();
           }else{
            getdraff();
           }
         
        
       
        }
            fetchData();
              
    },[])

    const selectlan = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
      

    }
	
	 const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const draffclick=async(click)=>{
      navigation.navigate('Repair',click)
      //console.log('Repairpass>>>',click)
    }


    const getdraff=async()=>{

        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData2 = JSON.parse(result1)
         setLoading(true)

        fetch(global.url + 'getreport.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData2.id,
              
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                    //console.log('json--->>>', json)
                    setarray(json.data)
                    setLoading(false)
                    }
                else {
                    alert(json.ResponseMsg)
                }

            })
            .catch((err) => {
                //console.log(err);
                //console.log(err)
            });
            }

    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 30 }}></View>
                    <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />

                        {/* <Image style={styles.ficon} source={require('../../../image/back.png')} /> */}

                    </TouchableOpacity>
                    <Text style={{ fontSize: 22, color: '#0d0d26', fontWeight: 'bold', marginTop: 20, borderWidth: 0 }}>{t('Report Draft')}</Text>
                    {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                    {array?
                    <View>
                           {array.map((click, index) => (
                                 <View key={index}>
                                    <TouchableOpacity onPress={()=>(draffclick(click))}>
                                           <View style={{borderWidth:0,height:50,marginTop:30,borderBottomWidth:1  , borderColor:'#a3a3a3',}}>
                                              <Text style={{color:'#1d334c',fontSize:18,paddingTop:10}}>{click.vehicle_number}</Text>
                                           </View>
                                    </TouchableOpacity>
                                  </View>
                            ))}

                    </View>
                    :<Text style={styles.draff}>{t('There is no reports in draft at the moment')}</Text>
                    }
                    </View>
            </ScrollView>
        </View>
    )
}
export default Draff;