import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    ActivityIndicator
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
const Car = ({ navigation }) => {
    const { t, i18n } = useTranslation();
    const [currentLanguage, setLanguage] = useState('');
    const [submitted, setsubmitted] = useState('');
    const [data, setData] = useState('');
    const [loading, setLoading] = useState(false);
    const [Value, setValue] = useState('');
    useEffect(() => {
        async function fetchData() {
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
        }
        fetchData();
        getcar();
    }, [])
    const getcar = async () => {
        setLoading(true);
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setsubmitted(true)
        fetch(global.url + 'getcars.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
            }),
        })

            .then((res) => res.json())
            .then((json) => {
                if (json.ResponseCode == '1') {
                    setData(json.data)
                    setLoading(false);
                }
                else {
                    alert(json.ResponseMsg)
                }

            })
            .catch((err) => {
            });
    }
    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlan = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: 'black', fontWeight: 'bold', marginTop: 15 }}>{t('Car Details')}</Text>
                </View>
                <View style={styles.box}>
                    <View style={styles.hadding}>
                        <Text style={styles.h1}>{t('Vehicle Number')}</Text>
                        <Text style={styles.h2}>{t('Brand')}</Text>
                        <Text style={styles.h3}>{t('Model')}</Text>
                    </View>
                    {data ?
                        <View>
                            {data.map((get, index) => (
                                <View key={index}>
                                    <TouchableOpacity onPress={() => navigation.navigate('Detail', get)}>

                                        <View style={styles.sub}>
                                            <Text style={styles.t1}>{get.vehicle_number}</Text>
                                            <Text style={styles.t2}>{get.car_brand}</Text>
                                            <Text style={styles.t3}>{get.car_model}</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            ))}
                        </View>
                        : null}
                </View>
            </ScrollView>
            {loading ?
                <View style={styles.spinner}>
                    <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                </View>
                : null}
        </View>
)

}
export default Car;