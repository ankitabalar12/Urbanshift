import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    box:{
        borderWidth:2,
        margin:10,
        borderColor:'#e5e5e5',
        borderRadius:10,
        // width:'100%'
    },
    hadding:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        backgroundColor:'#346696',
        height:40
      
       
        // margin:5
    },
    h1:{
        color:'#ffffff',
        width:'40%',
        // marginLeft:'3%',
        fontSize:18,
        // marginRight:'7%',
        marginTop:5,
        // borderWidth:1,
        textAlign:'center'
        // paddingLeft:'4%'
    },
    h2:{
        color:'#ffffff',
        width:'30%',
        // marginLeft:'8%',
        fontSize:18,
        // marginRight:'11%',
        marginTop:5,
        // borderWidth:1,
        textAlign:'center'

    },
    h3:{
        color:'#ffffff',
        width:'30%',
        // marginLeft:'6%',
        fontSize:18,
        marginTop:5,
        // borderWidth:1,
      textAlign:'center'

    },
    sub:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        borderBottomColor:'#e5e5e5',
        borderBottomWidth:2,
        margin:'2%',
        padding:'1%'
       
    },
    t1:{
        // borderWidth:1,
    //    marginLeft:'3%',
        fontSize:18,
        color:'#000000',
        width:'40%',
        textAlign:'center'
       
    },
    t2:{
        // borderWidth:1,
        // marginLeft:'25%',
        fontSize:18,
        color:'#000000',
        width:'33%',
        textAlign:'center'

    },
    t3:{
        // borderWidth:1,
        // marginLeft:'19%',
        fontSize:18,
        color:'#000000',
        width:'27%',
        textAlign:'center'
       

    },
    t4:{
     
        // marginLeft:'3%',
         fontSize:18,
         color:'#000000',
         width:'40%',
         textAlign:'center',
        //  borderWidth:1
        
     },
     t5:{
        
        //  marginLeft:'23%',
        // width:'20%',
         fontSize:18,
         color:'#000000',
        //  borderWidth:1,
         width:'33%',
         textAlign:'center'
     },
     t6:{
        
        //  marginLeft:'14%',
         fontSize:18,
         color:'#000000',
        //  width:'33%',
         width:'27%',
        textAlign:'center'
      
 
     },
     t7:{
     
        // marginLeft:'3%',
         fontSize:18,
         color:'#000000',
         width:'40%',
         textAlign:'center',
        
     },
     t8:{
        
        //  marginLeft:'25%',
         fontSize:18,
         color:'#000000',
         width:'33%',
         textAlign:'center',
 
     },
     t9:{
        
        //  marginLeft:'14%',
         fontSize:18,
         color:'#000000',
         width:'27%',
         textAlign:'center',
 
     },
     t10:{
     
        // marginLeft:'3%',
         fontSize:18,
         color:'#000000',
         width:'40%',
         textAlign:'center',
        
     },
     t11:{
        
        //  marginLeft:'18%',
         fontSize:18,
         color:'#000000',
         width:'33%',
         textAlign:'center',
 
     },
     t12:{
        
        //  marginLeft:'9%',
         fontSize:18,
         color:'#000000',
         width:'27%',
         textAlign:'center',
         paddingLeft:'3%'
 
     },
     t13:{
     
        // marginLeft:'3%',
         fontSize:18,
         color:'#000000',
         width:'40%',
         textAlign:'center',
        
     },
     t14:{
        
        //  marginLeft:'25%',
         fontSize:18,
         color:'#000000',
         width:'33%',
         textAlign:'center',
 
     },
     t15:{
        
        //  marginLeft:'16%',
         fontSize:18,
         color:'#000000',
         width:'27%',
         textAlign:'center',
 
     },
     spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
      bottom:10,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
     
})