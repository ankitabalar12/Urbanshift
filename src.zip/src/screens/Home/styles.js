import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
      profileimg:{
        width: '40%',
         margin: 20,
         flex:1,
         flexDirection:'row',
         justifyContent:'flex-end' ,
         backgroundColor:'#d4d4d4',
         borderWidth:1,
         paddingLeft:7,
         borderRadius:40,
            height:80,
       
      },
      profileimg2:{
      width:90,
        height:90,
        backgroundColor:'#d4d4d4',
        borderRadius:48,
        flex:0,
        flexDirection:'row',
        justifyContent:'flex-end',
        // borderWidth:1
           
       
      }
     
})