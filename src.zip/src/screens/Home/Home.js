import React, { useState, useEffect } from 'react';
import { ScrollView, Text, ActivityIndicator,Alert, TextInput, SafeAreaView, TouchableOpacity, View, Image, StatusBar } from 'react-native';
import { styles } from './styles';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';
import { resetNavigateTo } from '../../../NavigationHelper';
import Modal from "react-native-modal";
import Ionicons from 'react-native-vector-icons/Ionicons';
import FastImage from 'react-native-fast-image';



// import DeviceInfo from 'react-native-device-info';

export default function Home({ route, navigation }) {
    const { t, i18n } = useTranslation();
    const [fullname, setFullname] = useState("");
    const [loading, setLoading] = useState(false);
    const [utype, setUsertype] = useState('');
    const [vnum, setVnum] = useState('');
    const [full, setFull] = useState('');
    const [count, setcount] = useState('');
    const [Upcomming, setUpcomming] = useState('');
    const [click, setclick] = useState(0);
    const [new1, setnew1] = useState([]);
    const [userlogin, setuserlogin] = useState('');
    const [not, setnot] = useState('');
    const [isModalVisible, setModalVisible] = useState(false);
    const [isModalVisible1, setModalVisible1] = useState(false);
    const [pass,setPass]=useState('');
    const [del, setdel] = useState('')
    const [value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [profilepic, setprofilepic] = useState('');
    const [whologin, setwhologin] = useState('');
    useEffect(() => {
     
        navigation.addListener('focus',async () => {
      
       
            const typelang = await AsyncStorage.getItem('type');
            //console.log('typelang== => ', typelang);
            selectlang(typelang)
            const result1 = await AsyncStorage.getItem('QasLogin')
            const screenData = JSON.parse(result1)
            //console.log('screenData>>',screenData)
            //console.log('screenData.profile_pic',screenData.profile_pic)
            setprofilepic(screenData.profile_pic)
            const witchuser = await AsyncStorage.getItem('usertype');
            //console.log('typelang== => ', witchuser);
            setwhologin(witchuser)
         

            const user =route.params
            global.user= user
          //console.log('global.user',global.user)
           //console.log('user>>',user)
                if(user){
                 setFullname(user);
                setuserlogin(user)
              
                Notification();
              
                }else{
                 hadding();
               
           }
           Upcommingappo();
           getcategory();
        
           })
    
    }, [])
 const hadding = async () => {
        setLoading(true)
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        const int2 = screenData.full_name;
        setFull(int2)
        setVnum(screenData.vehicle_number)

       // //console.log('Userloginname:-', int2)
        setLoading(false)
    }
    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlang = async (value) => {
        //console.log('selectedd',value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
       

    }
    const logout = () => {

        Alert.alert(  
            '',  
            (t('Are you sure you want to logout?')),  
            [  
                {  
                    text: (t('Yes')),  
                    onPress: () =>{
                        AsyncStorage.removeItem('QasLogin')
                        resetNavigateTo(navigation, 'Loginoption');
                    } 
                  ,  
                   
                },  
                {text: (t('No')), onPress: () => console.log('OK Pressed')},  
            ]  
        );
     
    }

    const getcategory = () => {
        setLoading(true);
        fetch(global.url + 'getmechanics.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: 10
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {

               // //console.log('Response =>', json)
                if (json.ResponseCode == '1') {
                    await AsyncStorage.setItem('Qasmac', JSON.stringify(json.upcomming));

                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }
    const notapi = () => {
        setclick(1)
        navigation.navigate('Inbox')
    }

    const Notification = async () => {
        setLoading(true);

        const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)
       // //console.log(screenData.id)
        // alert('call noti')
        if (screenData.id !== '') {

            fetch(global.url+'getnotification.php', {

                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },

                body: JSON.stringify({
                    user_id: screenData.id,

                }),
            })

                .then((res) => res.json())
                .then(async (json) => {

                   // //console.log('Response =>', json)
                    if (json.ResponseCode == '1') {
                  
                        for (var i = 0; i < json.data.length; i++) {

                           // //console.log('***********', i)
                            new1.push(i)

                        }

                        const words = json.data;

                        const wordCount = words.length;//3 

                        const result = await AsyncStorage.getItem('Notification')
                        const screenData = JSON.parse(result)
                    
                        if (screenData < wordCount) {
                        
                            setcount(1)
                         
                        } else {
                         
                            setcount(0)
                        }
                         setLoading(false);
                    } else {
                        alert(json.ResponseMsg)
                        setLoading(false);
                    }

                })
                .catch((err) => {
                
                });
        }

    }

    const Upcommingappo =async()=>{
       
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
            setLoading(true)
         fetch(global.url+'getappointment.php', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id:screenData.id,
                }),
            })
            .then((res) => res.json())
                .then(async(json) => {
                //    //console.log('Response =>', json)
                    if (json.ResponseCode == '1') {
                    // //console.log('respose data json.upcomming>>>>',json.upcomming)
                      for (var i =0;i<json.upcomming.length;i++){
                               // //console.log('frist upcommimg data>>>>',json.upcomming[0])
                                setUpcomming(json.upcomming[0])
                                // //console.log('json.upcomming[0]',json.upcomming[0])
                      }
                        // setUpcomming(data)
                           
                        //// //console.log('upcoomg==>>',Upcomming)
                        setLoading(false);
                              }
                          })
                .catch((err) => {
                   // //console.log(err)
                });
     }
     const selectpop = (up) => {
        setModalVisible(true)
        setPass(up)
        setdel(up.id)
 }
 const rest = () => {
    setModalVisible(false)
    navigation.navigate('Reschle',pass)
}
const can =()=>{
    setModalVisible(false)
}


const deletes = () => {
    Alert.alert(
        "Are your sure?",
        "Are you sure you want to Delete ?",
        [
          // The "Yes" button
          {
            text: (t("Yes")),
            onPress: () => {
                // const del = async(id,index)=>{
                    setLoading(true);
                    fetch(global.url + 'deleteappointment.php', {
                        method: 'POST',
                        headers: {
                            Accept: 'application/json',
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            id:del
        
                        }),
                    })
                        .then((res) => res.json())
                        .then(async (json) => {
                           // //console.log(json)
                            setLoading(false);
                            if (json.ResponseCode == '1') {
                               
                                setModalVisible(false)
                                Upcommingappo();
                                
                            } else {
                                alert(json.ResponseMsg)
                                setLoading(false);
                            }
                        })
                        .catch((err) => {
                           
                        });
                // }
            },
            
          },
          // The "No" button
          // Does nothing but dismiss the dialog when tapped
          {
            text: (t("No")),
            onPress: () => {
                setModalVisible(false)
                Upcommingappo();
            }
          
          },
        ]
      );
}

const modelopne=()=>{
    setModalVisible1(true)
}

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: '#346696' }}>
            <View style={styles.maincontainer}>
                <ScrollView>
                    <StatusBar backgroundColor='#346696' barStyle="dark-content" />
                    <View style={{ backgroundColor: '#346696' }}>
                        <View style={{ height: 10 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row',flex:1}}>
                                <View style={{ width: '66%', margin: 20 }}>
                                    <Text style={{ fontSize: 20, color: 'white' }}>{t('Welcom Back!')}</Text>
                                    <View style={{ height: 10 }}></View>
                                    {userlogin!='' ||  whologin=='1' ?
                                        <Text style={{ fontSize: 22, color: 'white', fontWeight: 'bold' }}>{fullname}👋</Text>
                                            :
                                        <Text style={{ fontSize: 22, color: 'white', fontWeight: 'bold' }}>{full}👋</Text>
                                    }
                                </View>
                                {userlogin!='' || whologin=='1'?
                                <View>
                                            {profilepic==''  ?
                                        
                                            
                                                <TouchableOpacity style={styles.profileimg2} onPress={()=>navigation.navigate('Editprofile')}>
                                                
                                                    <FastImage resizeMode='contain' style={{flex:1,}}source={require('../../../image/user.png')} />
                                                </TouchableOpacity>
                                                : 
                                                <TouchableOpacity style={styles.profileimg2} onPress={()=>navigation.navigate('Editprofile')}>
                                                    <FastImage resizeMode='contain' style={{flex:1}} source={{ uri: `https://appdevelopmentsingapore.com/qas/api/${profilepic}` }} />
                                                </TouchableOpacity>


                                                }
                                                </View>
                                 :null}
                        </View>
                        <View style={{ height: 20 }}></View>
                    </View>
                    <View style={{ margin: 20 }}>
                        <View style={{ height: 10 }}></View>
                        {userlogin!='' || whologin=='1' ?
                            <View>
                                <View style={{ width: '100%', flexDirection: 'row', borderWidth: 0 }}>
                                    <View style={{ width: '90%' }}>
                                        <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'black' }}>{t('Next servicing Appointments')}</Text>
                                    </View>
                                  
                                </View>
                                {Upcomming?
                                <View>
                                <View style={{ height: 7 }}></View>
                               
                                <View style={{ width: '100%', flexDirection: 'row', borderWidth: 0 }}>
                                
                                    <View style={{ width: '15%' }}>
                                        <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/car.png')} />
                                    </View>
                                    <View style={{ width: '80%' }}>
                                        <Text style={{ fontSize: 15, marginTop: 4 }}>{t(Upcomming.cardetail.vehicle_number)}</Text>
                                    </View>
                                    <TouchableOpacity style={{ width: '10%',borderWidth:0,marginLeft:-20,alignItems:'center',marginTop:5}} onPress={()=>selectpop(Upcomming)}>
                                        <Image style={{ height: 20, width: 8 }} source={require('../../../image/dots.png')} />
                                    </TouchableOpacity>
                                </View>
                                <View style={{ height: 7 }}></View>
                               
                                <View style={{ width: '100%', flexDirection: 'row' }}>
                                    <View style={{ width: '15%' }}>
                                        <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/cal.png')} />
                                    </View>
                                    <View style={{ width: '80%' }}>
                                        <Text style={{ fontSize: 15, marginTop: 4 }}>{t(Upcomming.date)}</Text>
                                    </View>
                                </View>
                                <View style={{ height: 7 }}></View>
                                <View style={{ width: '100%', flexDirection: 'row' }}>
                                    <View style={{ width: '15%' }}>
                                        <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clock.png')} />
                                    </View>
                                    <View style={{ width: '80%' }}>
                                        <Text style={{ fontSize: 15, marginTop: 4 }}>{Upcomming.time}</Text>
                                    </View>
                                </View>
                                </View>
                                :<Text style={{fontSize:17,alignSelf:'center',marginTop:8}}>Not found any next servicing Appointments</Text>}
                            </View>
                            :
                            <View>
                                <View style={{ width: '90%' }}>
                                    <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'black' }}>{t('Next servicing Appointments')}</Text>
                                </View>
                                {Upcomming?
                                <View style={{ backgroundColor: '#b3c5d9', borderRadius: 20, margin: 5, marginTop: 10 }}>
                                    <View style={{ height: 20 }}></View>
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/carap.png')} />
                                        </View>
                                        <View style={{ width: '70%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{Upcomming.vehicle_number}</Text>
                                        </View>
                                        {/* {/ <TouchableOpacity style={{ width: '10%' }} onPress={()=>navigation.navigate('Reschle',up)}  > /} */}
                                        <TouchableOpacity style={{ width: '10%' }}  onPress={()=>selectpop(Upcomming)}>
                                            <Image style={{ height: 20, width: 8 }} source={require('../../../image/dotapp.png')} />
                                        </TouchableOpacity>
                                    </View>
                                    <View style={{ height: 10 }}></View>
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/calapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{Upcomming.date}</Text>
                                        </View>
                                    </View>
                                    <View style={{ height: 10 }}></View>
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/clockapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{Upcomming.time}</Text>
                                        </View>
                                    </View>
                                    <View style={{ height: 10 }}></View>
                                    <View style={{ width: '100%', flexDirection: 'row', marginHorizontal: 20 }}>
                                        <View style={{ width: '15%' }}>
                                            <Image style={{ height: 30, width: 35, borderRadius: 10 }} source={require('../../../image/toolapp.png')} />
                                        </View>
                                        <View style={{ width: '80%' }}>
                                            <Text style={{ fontSize: 15, marginTop: 4, color: '#395168' }}>{Upcomming.service_type}</Text>
                                        </View>
                                    </View>
                                    <View style={{ height: 15 }}></View>
                                </View>
                                :<Text style={{fontSize:17,alignSelf:'center',marginTop:8}}>Not found any next servicing Appointments</Text>}
                            </View>
                        }
                        <View style={{ height: 20 }}></View>
                        <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'black' }}>{t('Other services')}</Text>
                        {loading ?
                            <View style={styles.spinner}>
                                <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                            </View>
                            : null}
                        <View style={{ height: 20 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row' }}>
                            {userlogin!='' ||  whologin=='1'?
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Upcomingapp')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40, alignSelf:'center' }} source={require('../../../image/calc.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center' ,color:'#61656b'}}>{t('Appointments')}</Text>
                                    </View>
                                </TouchableOpacity>
                                : <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Schedule')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/calc.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Appointments')}</Text>
                                    </View>
                                </TouchableOpacity>}

                            {userlogin!='' ||  whologin=='1' ?
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Detail',1)}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40, alignSelf:'center' }} source={require('../../../image/carc.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center' ,color:'#61656b'}}>{t('Car Details')}</Text>
                                    </View>
                                </TouchableOpacity>

                                :
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Car')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/carc.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Car Details')}</Text>
                                    </View>
                                </TouchableOpacity>}

                        </View>
                        <View style={{ height: 20 }}></View>
                        <View style={{ width: '100%', flexDirection: 'row' }}>
                            {userlogin!='' ||  whologin=='1'?
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Setting')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/setting.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Setting')}</Text>
                                    </View>
                                </TouchableOpacity>

                                :
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Repair')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/setting.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Report Upload')}</Text>
                                    </View>
                                </TouchableOpacity>}
                            {userlogin!='' ||  whologin=='1' ?
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }}  onPress={() => (notapi(1))}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40, alignSelf:'center' }} source={require('../../../image/emailc.png')} />
                                        {count == '1' ?
                                         <View>
                                        {click == '0' || count == '1'?
                                            <Text style={{ position: 'absolute', borderWidth: 0, width: 16, height: 18, bottom: 30, borderRadius: 10, backgroundColor: 'red', color: '#ffffff', marginLeft:0, paddingLeft: 4,right:66 }}>{count}</Text>
                                            : null}
                                    </View>
                                    : null}
                                        <Text style={{ fontSize: 18, textAlign: 'center' }}>{t('Inbox')}</Text>
                                    </View>
                                </TouchableOpacity>
                                : <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Atten')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/location.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Attendance')}</Text>
                                    </View>
                                </TouchableOpacity>}

                        </View>
                        <View style={{ height: 20 }}></View>
                        {userlogin!='' || whologin=='1'?
                            null
                            :
                            <View style={{ width: '100%', flexDirection: 'row' }}>
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Nquo')}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 52, marginTop: 40, alignSelf:'center' }} source={require('../../../image/quo.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Quotation')}</Text>
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} 
                                onPress={() => navigation.navigate('Selectlanguage')}
                                    // onPress={modelopne}
                                >
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/world.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Language')}</Text>
                                    </View>
                                </TouchableOpacity>
                            </View>
                        }
                         <View style={{ height: 20 }}></View>
                           {userlogin!='' ||  whologin=='1'?
                               null
                               
                                : 
                                <View style={{ width: '100%', flexDirection: 'row' }}>
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={() => navigation.navigate('Draff',1)}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 10 }}>
                                        <Image style={{ height: 50, width: 50, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/draft.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Reports Draft')}</Text>
                                    </View>
                                </TouchableOpacity>
                              
                                <TouchableOpacity style={{ width: '50%', borderRadius: 10 }} onPress={logout}>
                                    <View style={{ width: '96%', height: 170, backgroundColor: '#d3dde9', borderRadius: 0 }}>
                                        <Image style={{ height: 50, width: 52, marginTop: 40,  alignSelf:'center' }} source={require('../../../image/turn-off.png')} />
                                        <Text style={{ fontSize: 18, textAlign: 'center',color:'#61656b' }}>{t('Logout')}</Text>
                                    </View>
                                </TouchableOpacity>
                                </View>
                                }

                                <View style={{ height: 20 }}></View>
                         

                    </View>
                   

                <View>
                    <Modal isVisible={isModalVisible}>
                        <View style={{ flex: 0, alignItems: 'center', backgroundColor: 'white', padding: 6,height:'20%',width:200,alignSelf:'center'}}>
                            
                            <View style={{ borderBottomWidth: 2, width: 170 ,marginTop:10,height:30,borderColor:'#cccccc'}}>
                                <TouchableOpacity onPress={rest}>
                                    <Text style={{ textAlign: 'center',fontSize:18 ,color:'#1d334c'}}>{t('Reschedule')}</Text>
                                </TouchableOpacity>
                                
                            </View>
                            <View style={{ height: 10}}></View>
                            <Text style={{ textAlign: 'center',fontSize:18,color:'#1d334c' }} onPress={deletes}>{t('Delete')}</Text>
                            <View style={{ borderTopWidth: 2, width: 170 ,marginTop:10,height:30,borderColor:'#cccccc',paddingTop:5}}>
                        <Text style={{ textAlign: 'center',fontSize:18,color:'#1d334c' }} onPress={can}>{t('Cancel')}</Text>
                            </View>
                        </View>
                        
                    </Modal>
                </View>
                </ScrollView>
            </View>
        </SafeAreaView>
    );
};