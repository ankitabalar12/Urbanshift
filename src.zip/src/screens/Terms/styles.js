import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%',
        // borderWidth:1
       
      },
   
})