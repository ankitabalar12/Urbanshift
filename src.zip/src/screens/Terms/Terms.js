import React, { useState,useEffect } from 'react';
import { ScrollView, Text, TextInput,ActivityIndicator, TouchableOpacity, View, Image, StatusBar } from 'react-native';
import { styles } from './styles';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-community/async-storage';

export default function Terms({ navigation }) {
    const { t, i18n } = useTranslation();
    const [terms, setTerms] = useState('');
    const [loading, setLoading] = useState(false);
    const [currentLanguage, setLanguage] = useState('');
    const [value, setValue] = useState('');
    useEffect(() => {
        async function fetchData() {
            const typelang = await AsyncStorage.getItem('type');
            selectlang(typelang)
            getconfig();
        }
        fetchData();
    }, [])
    const getconfig = () => {
        setLoading(true)
        fetch(global.url+'getcanfig.php', {
            method: 'GET',
            headers: {
                Accept: 'application/json',
                'Content-type': 'application/json',
            }
        }).then((res) => res.json())
            .then((json) => {
                if (json.ResponseCode == '1')
               
                 {
                    if (json.data)
                     {
                        for (var i = 0; i < json.data.length; i++) {
                            if (json.data[i].id == '1') {
                                setTerms(json.data[i].value)
                            }
                        }
                    }
                }
                setLoading(false)
            })
            .catch((err) => {
                console.log(err)
            })
    }
const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const selectlang = async (value) => {
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
       

    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30,fontSize:25,color:'black'}}>
                    <View style={{ height:20 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Image source={require('../../../image/back.png')} />
                    </TouchableOpacity>
                    <View style={{ height: 30 }}></View>
                    {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        <Text style={{fontSize:20,color:'gray',alignSelf:'center',marginTop:'25%'}}>Not Found Data</Text>

                    </View>
                    : null}
                    <Text style={{ fontSize: 25, color: 'black' }}>{t('Terms & Conditions')}</Text>
                    <View style={{ height: 30 }}></View>
                    {/* <Text style={{letterSpacing:0.15,color:'#2c2c2c',fontSize:15, fontFamily:'Poppins-Regular'}}>Lorem ipsum dolor sit  adipisicing elit. Facilis sint at saepe sed est! Sequi ad, nesciunttemporibus deserunm earum is pernem quidem excepturi aut. Doloribus facere dignissimos, placeat dicta odit aut error reprehenderit neque fugit quidem magni vitae dolore aspernatur impedit nemo adipisci repellat perferendis eos sit sunt vel nobis voluptatum dolores esse. Odio sunt esse laudantium iure, veritatis incidunt ex non inventore minima hic dolore sint molestias temporibus eaque reiciendis commodi porro.</Text> */}

                    <Text style={{letterSpacing:0.15,color:'#2c2c2c',fontSize:15, fontFamily:'Poppins-Regular'}}>{t(terms)}</Text>
                  </View>
            </ScrollView>
        </View>
    );
};