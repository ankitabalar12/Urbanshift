import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    TextInput,
    Dimensions,
    Button,
    ActivityIndicator,
    Alert
} from "react-native";

import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Dropdown } from "react-native-element-dropdown";
import { Icon } from "react-native-elements";
import AsyncStorage from '@react-native-community/async-storage';
import '../../../i18n';
import { useTranslation } from 'react-i18next';
const Nquo = ({ navigation, route }) => {
    const [width, setWidth] = useState('');
    const [value, setValue] = useState([]);
    const [isFocus, setIsFocus] = useState(false);
    const [value1, setValue1] = useState('');
    const [isFocus1, setIsFocus1] = useState(false);
    const [textInputs, setTextInputs] = useState([]);
    const [cunstomtextInputs, setcunstomextInputs] = useState([]);
    const [submitted, setsubmitted] = useState(false);
    const [comname, setComame] = useState('');
    const [vnum, setVnum] = useState('');
    const [vmodel, setVmodel] = useState('');
    const [dname, setDname] = useState('');
    const [contact, setContact] = useState('');
    const [vbrand, setVbrand] = useState('');
    const [item, setItem] = useState('');
    const [qty, setQty] = useState([]);
    const [qty2, setQty2] = useState('');
    const [category, setCategory] = useState('');
    const [category1, setCategory1] = useState('');
    const [loading, setLoading] = useState(false);
    const [select, setSelect] = useState('');
    const [counter, setcounter] = useState(0);
    const [pricecounter, setpricecounter] = useState(0);
    // const [itemArray, setitemArray] = useState([]);
    const [qtyArray, setqtyArray] = useState([]);
    const [selectedValues, setSelectedValues] = useState([]);
    const [itemname, setitemname] = useState([]);
    const [selling_price, setselling_price] = useState([]);
    const [allqtyarray, setallqtyarray] = useState([]);
    const [Number, setNumber] = useState('');
    const [Number1, setNumber2] = useState('');
    const [isFocus3, setIsFocus3] = useState(false);
    const [selecteddrop2Values, setselecteddrop2Values] = useState('');
    const [vehicle_number, setvehicle_number] = useState('');
    const [brand, setbrand] = useState('');
    const [model, setmodel] = useState('');
    const [selected, setselected] = useState([]);
    const [dropDownData, setdropDownData] = useState([]);
    const [dropDownData2, setdropDownData2] = useState([]);
    const [passprice, setpassprice] = useState('');
    const [doubleselect, setdoubleselect] = useState(0);
    const [Enter, setenter] = useState('');
    const { t, i18n } = useTranslation();
    const [Value2, setValue2] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [padddate, setpadddate] = useState('');
    const [finalqty, setfinalqty] = useState('');
    const [stock, setstock] = useState([]);
    const [finalprice, setfinalprice] = useState('');
    const [stockindexforqty, setstockindexforqty] = useState(0);
    const [selectedValuesPerDropdown, setSelectedValuesPerDropdown] = useState([]);
    const [selectedValuesArr, setSelectedValuesArr] = useState([]);
    const [ind, setind] = useState('');

    useEffect(() => {
        navigation.addListener('focus', async () => {
            setLoading(true);
            var date = new Date().getDate();
            var month = new Date().getMonth() + 1;
            var year = new Date().getFullYear();
            global.currentDate = year + '/0' + month + '/' + date
            setpadddate(global.currentDate)
            const typee = await AsyncStorage.getItem('type');
            selectlan(typee)
            setWidth(Dimensions.get('screen').width);
            if(dropDownData.length == 0){
                getmac();
            }
            
            getcar();
        })
        setLoading(false);
    }, []);

    useEffect(() => {
        console.log('selectedValuesArr----->', selectedValuesArr)
        if(selectedValuesArr){
            setSelectedValuesPerDropdown(selectedValuesArr)
            global.itemArr = selectedValuesArr
        }
        
    }, [selectedValuesArr])


    const selectlan = async (value) => {
        setValue2(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }
    }
    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const getcar = async () => {
        setLoading(true);
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        fetch(global.url + 'getcars.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,
            }),
        })
            .then((res) => res.json())
            .then((json) => {
                if (json.ResponseCode == '1') {
                    setbrand(json.car_brand)
                    setmodel(json.car_model)
                    var count = Object.keys(json.data).length;
                    for (var i = 0; i < count; i++) {
                        dropDownData2.push({ value: json.data[i].id, label: json.data[i].vehicle_number, model: json.data[i].car_model, brand: json.data[i].car_brand }); // Create your array of data
                    }
                    dropDownData2.push({ value: 0, label: 'Other' })
                    setNumber(dropDownData2);
                    //console.log('dropDownData2',dropDownData2)
                    setLoading(false);
                }
                else {
                    alert(json.ResponseMsg)
                }
            })
            .catch((err) => {

            });
    }

    const getmac = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result1)
        setLoading(true);
        fetch(global.url + 'getitem.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {
                    await AsyncStorage.setItem('Qasmac', JSON.stringify(json.data));
                   
                    console.log('json', json)
                    console.log('json.data', json.data)
                    var count = Object.keys(json.data).length;
                    for (var i = 0; i < count; i++) {
                        dropDownData.push({ value: json.data[i].id, label: json.data[i].product_name, selling_price: json.data[i].selling_price, stock_count: json.data[i].stock_count }); // Create your array of data

                    }
                    setCategory(dropDownData);
                    setCategory1(dropDownData);

                    setLoading(false);
                } else {
                    alert(json.ResponseMsg)
                    setLoading(false);
                }
            })
            .catch((err) => {
            });
    }

    const setvehiclenumber = (val) => {
        setselecteddrop2Values(val.value)
        for (var i = 0; i < dropDownData2.length; i++) {
            if (dropDownData2[i].value == val.value) {
                const selectval = dropDownData2[i]
                setVbrand(selectval.brand)
                setVmodel(selectval.model)
            }
        }
    }
    const setcustomdropdownvalue = (value) => {
        itemname.push(value)
    }
    const setcustomprice = (value, index) => {
        setselling_price((prevValues) => {
            const updatedInputValues = [...prevValues];
            updatedInputValues[index] = value;
            setfinalprice(updatedInputValues.toString())
            return updatedInputValues;
        });
    }

    const setdropdownvalue = (val, ind) => {
        
        global.Index = ind
        setind(ind)
        
        

        if (allqtyarray[ind]) {
            stock[ind] = ({ 'index': ind, 'stock': val.stock_count });
            
            const valindexnew = val._index;
            
            setqtyvalue(allqtyarray[ind], ind, 2,valindexnew);
        }

        setdoubleselect(0);
       

        const count = stockindexforqty + 1;
        setstockindexforqty(count);

        setSelectedValuesArr((prevSelectedValues) => {
            const updatedValues = [...prevSelectedValues];

            updatedValues[ind] = updatedValues[ind]?.index === ind
                ? { 'index': ind, 'stock': val.stock_count }
                : undefined;

            return updatedValues.filter((item) => item !== undefined);
        });

        const existingIndex = selectedValuesArr.findIndex((item) => item.index === ind && item.stock === val.stock_count);
        console.log('Filterd', existingIndex);

        if (existingIndex !== -1) {
            const selectedValuesCopy = [...selectedValuesArr];
            selectedValuesCopy[existingIndex] = { 'index': ind, 'stock': val.stock_count };
            setSelectedValuesArr(selectedValuesCopy);
        } else if (selectedValuesArr.some((item) => item.stock === val.stock_count)) {
            alert(t('you have already selected this item'));
            setdoubleselect(1);
        } else {
            setSelectedValuesArr((prevSelectedValues) => {
                const updatedValues = [...prevSelectedValues];
                updatedValues[ind] = { 'index': ind, 'stock': val.stock_count };

                return updatedValues.filter((item) => item !== undefined);
            });

            const sprice = val.selling_price;
            const passprice = sprice.replace('$', '');
            setpassprice(passprice);
            
            const priincrement = pricecounter + 1;
            setpricecounter(priincrement);
            setcustomprice(val.selling_price, pricecounter);

            if(passprice){
                selling_price[ind] = passprice;
            }
            if(val.label){
                itemname[ind] = val.label;
            }    
            

            //selling_price.push(passprice);
            //itemname.push(val.label);
        }
    };

    const setqtyvalue = (val, index, one,valindex) => {

        allqtyarray[index] = val;
       
        
        global.one = one
        global.val = val
        // console.log('stock array>>', stock)
       
        if (global.one == '2') {
            
            if (global.itemArr[global.Index].stock < parseInt(val)) { //storage < enter qty 
                //global.st = global.itemArr[global.Index].stock
                if(valindex != ''){
                    global.st = dropDownData[valindex].stock_count
                }else{
                    global.st = global.itemArr[index].stock
                }
                    
               

                Alert.alert('Error!', 'Stocks are insufficient. There is only ' + global.st + ' stock left.');
            } else {
                /*
                setqtyArray((prevValues) => {
                    console.log('prevalue>>>', prevValues)
                    const updatedInputValues = [...prevValues];
                    console.log('updatedInputValues>>>', updatedInputValues)
                    updatedInputValues[index] = val;
                    console.log('updatedInputValues api**********>>', updatedInputValues)
                    setfinalqty(updatedInputValues)
                    return updatedInputValues;
                });
                */
               if(val){
                qtyArray[index] = val;
               }
                
                
                

                //updatedInputValues[index] = val;
                const newValue = val.replace(/[^0-9]/g, '');
                setenter(newValue)
            }
        }
        else if (global.one == '1') {
            /*
            setqtyArray((prevValues) => {
                const updatedInputValues = [...prevValues];
                updatedInputValues[index] = val;
                console.log('updatedInputValues user**********>>', updatedInputValues)
                setfinalqty(updatedInputValues)
                return updatedInputValues;
            });
            */
            if(val){
                qtyArray[index] = val;
            }

            const newValue = val.replace(/[^0-9]/g, '');
            setenter(newValue)
        }
    }

    const handleAddInput = () => {
        const incrementedCount = counter + 1;
        setcounter(incrementedCount)
        
        const newInput = <View key={textInputs.length} style={{ flexDirection: 'row', marginTop: -10 }}>
            <TouchableOpacity>
                <Image style={styles.ficon3} source={require('../../../image/item.png')} />
            </TouchableOpacity>
            {category1 ?
                <Dropdown
                    style={[styles.dropdown]}
                    placeholderStyle={styles.placeholderStyle}
                    selectedTextStyle={styles.selectedTextStyle}
                    itemTextStyle={{ color: "#afb0b6" }}
                    data={category1}
                    maxHeight={300}
                    labelField="label"
                    valueField="value"
                    placeholder={!isFocus1 ? (t("Product name")) : "..."}
                    onFocus={() => setIsFocus1(true)}
                    onBlur={() => setIsFocus1(false)}
                    onChange={(item) => {
                        setdropdownvalue(item, incrementedCount);
                        setIsFocus1(false);
                    }}
                /> : null}
            {/* </View> */}
            <TextInput keyboardType="numeric" onEndEditing={(event) => setqtyvalue(event.nativeEvent.text, incrementedCount, 2,'')} style={{ borderWidth: 2, width: '20%', marginLeft: 10, height: 60, marginTop: 20, borderRadius: 10, borderColor: '#AFB0B6', fontSize: 20 }}></TextInput>
        </View>
            ;
        setTextInputs([...textInputs, newInput]);
    };
    const handleAddInput2 = () => {
        const incrementedCount = counter + 1;
        setcounter(incrementedCount)
        const priincrement = pricecounter + 1;
        setpricecounter(priincrement)
       
        const newInput = <View key={cunstomtextInputs.length} style={{ flexDirection: 'row', marginTop: -10 }}>
            <TouchableOpacity>
                <Image style={styles.ficon3} source={require('../../../image/item.png')} />
            </TouchableOpacity>
            <TextInput placeholder={t("Product Name")} fontSize={18} onEndEditing={(event) => setcustomdropdownvalue(event.nativeEvent.text)} style={{ borderWidth: 2, width: '50%', marginLeft: 15, height: 60, marginTop: 20, borderRadius: 10, borderColor: '#AFB0B6', paddingLeft: 50 }}></TextInput>
            <TextInput keyboardType="numeric" placeholder={t("Price")} onEndEditing={(event) => setcustomprice(event.nativeEvent.text, pricecounter)} style={{ borderWidth: 2, width: '20%', marginLeft: 10, height: 60, marginTop: 20, borderRadius: 10, borderColor: '#AFB0B6', fontSize: 20, paddingLeft: 20 }}>$</TextInput>
            <TextInput keyboardType="numeric" placeholder={t("Qty")} onEndEditing={(event) => setqtyvalue(event.nativeEvent.text, incrementedCount, 1,'')} style={{ borderWidth: 2, width: '20%', marginLeft: 10, height: 60, marginTop: 20, borderRadius: 10, borderColor: '#AFB0B6', fontSize: 20, paddingLeft: 20 }}></TextInput>
        </View>
            ;
        setcunstomextInputs([...cunstomtextInputs, newInput]);
    };
    const passarray2 = () => {
        setsubmitted(true)
        if (Enter != '') {
            if (doubleselect == '0') {
                let myArr = [
                    { "id": 0, 'name': comname },
                    { "id": 1, 'name': vehicle_number },
                    { "id": 2, 'name': dname },
                    { "id": 3, 'name': vbrand },
                    { "id": 4, 'name': vmodel },
                    { "id": 5, 'name': contact },
                    { "id": 6, 'name': selectedValues.join(",") },
                    { "id": 7, 'name': qtyArray },
                    { "id": 8, 'name': itemname },
                    { "id": 9, 'name': finalprice.toString() },
                    { "id": 10, 'name': padddate },
                ];
                console.log('***', myArr)
                // if (comname !== '' && vehicle_number !== '' && vbrand !== '' && vmodel !== '' && contact !== '' && selectedValues.join(",") !== '' && qtyArray !== '' && itemname.join(",") !== '' && selling_price.join(",") !== '') {
                navigation.navigate('Quosum', JSON.stringify(myArr))
                // }
            } else {
                alert(t('Please select other item'))
            }
        } else {
            Alert.alert('Error!', 'Please Enter valid quantity and  There is only ' + global.st + ' stock left.');
        }
    }
    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 22, color: '#0d0d26', fontWeight: 'bold', marginTop: 15 }}>{t('Generate New Quote')}</Text>
                </View>
                {loading ?
                    <View style={styles.spinner}>
                        <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                    </View>
                    : null}
                {width < '700' ?
                    <View style={{ marginTop: -20 }}>
                        <Image style={{ height: 30, width: 35, marginLeft: 32, position: 'absolute', top: 30 }} source={require('../../../image/carlogo.png')} />
                        {Number ?
                            <Dropdown
                                style={[styles.dropdown2]}
                                placeholderStyle={styles.placeholderStyle}
                                selectedTextStyle={styles.selectedTextStyle}
                                itemTextStyle={{ color: "#afb0b6" }}
                                data={Number}

                                maxHeight={300}
                                labelField="label"
                                valueField="value"
                                placeholder={!isFocus3 ? (t("Vehicle Number")) : "..."}
                                // value={value}
                                onFocus={() => setIsFocus3(true)}
                                onBlur={() => setIsFocus3(false)}
                                onChange={(item) => {
                                    // setSelect(0)
                                    setvehicle_number(item.label)
                                    setvehiclenumber(item)
                                    setIsFocus3(false);
                                }}

                            /> : null}
                        {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>Please Select Vehicle Number</Text> : null}


                        {selecteddrop2Values == '0' ?
                            <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -5 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                    <TextInput onChangeText={(value) => setvehicle_number(value)} placeholder={t("Vehicle Number")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>
                                </View>
                                {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>{t('Please Enter Vehicle Number')}</Text> : null}
                            </View>
                            : null}
                        <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                <TextInput onChangeText={(value) => setVbrand(value)} value={vbrand} placeholder={t("Vehicle Brand")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>
                            </View>
                        </View>
                        {vbrand === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Vehicle Brand')}</Text> : null}
                        <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                <TextInput onChangeText={(value) => setVmodel(value)} value={vmodel} placeholder={t("Vehicle Model")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}></TextInput>
                            </View>
                        </View>
                        {vmodel === '' && submitted ? <Text style={styles.chooseUserName2}>{t('Please Enter Vehicle Model')}</Text> : null}
                        <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/com.png')} />
                                <TextInput onChangeText={(value) => setComame(value)} value={comname} placeholder={t("Company Name")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>
                            </View>
                        </View>
                        {comname === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Company Name')}</Text> : null}

                        <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/per.png')} />
                                <TextInput onChangeText={(value) => setDname(value)} value={dname} placeholder={t("Driver's Name")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>
                            </View>
                        </View>
                        {dname === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Driver Name')}</Text> : null}
                        <View style={{ borderWidth: 2, marginLeft: '5%', marginRight: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: 20 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/call.png')} />
                                <TextInput onChangeText={(value) => setContact(value)} value={contact} placeholder={t("Contact Number")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                </TextInput>
                            </View>
                        </View>
                        {contact === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Contact Number')}</Text> : null}
                    </View>
                    :
                    <View style={{ marginTop: -20 }}>
                        <View style={{ flexDirection: 'row', flex: 1, borderWidth: 0 }}>
                            <Image style={{ height: 30, width: 35, marginLeft: 32, position: 'absolute', top: 30 }} source={require('../../../image/carlogo.png')} />
                            <View style={{ width: '50%' }}>
                                {Number ?
                                    <Dropdown
                                        style={[styles.dropdown2]}
                                        placeholderStyle={styles.placeholderStyle}
                                        selectedTextStyle={styles.selectedTextStyle}
                                        itemTextStyle={{ color: "#afb0b6" }}
                                        data={Number}
                                        maxHeight={300}
                                        labelField="label"
                                        valueField="value"
                                        placeholder={!isFocus3 ? (t("Vehicle Number")) : "..."}
                                        // value={value}
                                        onFocus={() => setIsFocus3(true)}
                                        onBlur={() => setIsFocus3(false)}
                                        onChange={(item) => {
                                            // setSelect(0)
                                            setvehicle_number(item.label)
                                            setvehiclenumber(item)
                                            setIsFocus3(false);
                                        }}
                                    /> : null}
                            </View>
                            {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>Please Select Vehicle Number</Text> : null}
                            {selecteddrop2Values == '0' ?
                                <View style={{ borderWidth: 2, margin: '5%', padding: '0%', borderColor: '#afb0b6', borderRadius: 10, marginTop: -5 }}>
                                    <View style={{ flexDirection: 'row' }}>
                                        <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                        <TextInput onChangeText={(value) => setvehicle_number(value)} value={vehicle_number} placeholder={t("Vehicle Number")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                        </TextInput>
                                    </View>
                                    {vehicle_number === '' && submitted ? <Text style={styles.chooseUserName2}>{t('Please Enter Vehicle Number')}</Text> : null}
                                </View>
                                : null}
                            <View style={{ borderWidth: 2, padding: '0%', borderColor: '#afb0b6', borderRadius: 10, height: 47, width: '45%', alignSelf: 'center' }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />
                                    <TextInput onChangeText={(value) => setVbrand(value)} value={vbrand} placeholder={t("Vehicle Brand")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>
                                </View>
                            </View>
                            {vbrand === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Vehicle Brand')}</Text> : null}
                        </View>
                        <View style={{ flexDirection: 'row', flex: 1, borderWidth: 0 }}>
                            <View style={{ borderWidth: 2, padding: '0%', borderColor: '#afb0b6', borderRadius: 10, height: 47, width: '45%', alignSelf: 'center', marginLeft: 20 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/carlogo.png')} />

                                    <TextInput onChangeText={(value) => setVmodel(value)} value={vmodel} placeholder={t("Vehicle Model")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}></TextInput>
                                </View>
                            </View>
                            {vmodel === '' && submitted ? <Text style={styles.chooseUserName2}>{t('Please Enter Vehicle Model')}</Text> : null}
                            <View style={{ borderWidth: 2, padding: '0%', borderColor: '#afb0b6', borderRadius: 10, height: 47, width: '45%', alignSelf: 'center', marginLeft: 20 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/com.png')} />
                                    <TextInput onChangeText={(value) => setComame(value)} value={comname} placeholder={t("Company Name")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>
                                </View>
                            </View>
                            {comname === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Company Name')}</Text> : null}
                        </View>
                        <View style={{ flexDirection: 'row', flex: 1, borderWidth: 0 }}>
                            <View style={{ borderWidth: 2, padding: '0%', borderColor: '#afb0b6', borderRadius: 10, height: 47, width: '45%', alignSelf: 'center', marginLeft: 20, marginTop: 20 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 30, width: 35, marginTop: 11, marginRight: 10, marginLeft: 10 }} source={require('../../../image/per.png')} />
                                    <TextInput onChangeText={(value) => setDname(value)} value={dname} placeholder={t("Driver's Name")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>

                                </View>
                            </View>
                            {dname === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Driver Name')}</Text> : null}

                            <View style={{ borderWidth: 2, padding: '0%', borderColor: '#afb0b6', borderRadius: 10, height: 47, width: '45%', alignSelf: 'center', marginLeft: 20, marginTop: 20 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Image style={{ height: 35, width: 35, marginTop: 5, marginRight: 10, marginLeft: 10 }} source={require('../../../image/call.png')} />
                                    <TextInput onChangeText={(value) => setContact(value)} value={contact} placeholder={t("Contact Number")} fontSize={19} marginTop={5} color={'#afb0b6'} placeholderTextColor={'#afb0b6'} style={{ borderWidth: 0, height: 40, width: '50%', color: "#000000" }}>
                                    </TextInput>
                                </View>
                            </View>
                        </View>
                        {contact === '' && submitted ? <Text style={styles.chooseUserName}>{t('Please Enter Contact Number')}</Text> : null}
                    </View>
                }
                <View style={{ flexDirection: 'row', borderWidth: 0, width: '86%' }}>
                    <Text style={{ fontSize: 22, color: '#0d0d26', fontWeight: 'bold', marginTop: 15, marginLeft: 25 }}>{t('Select Item')}</Text>
                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }}><Text style={{ fontSize: 22, color: '#0d0d26', fontWeight: 'bold', marginTop: 15, marginLeft: '45%' }}>{t('QTY')}</Text></View>
                </View>
                <View style={{ flexDirection: 'row', marginTop: -10 }}>
                    <TouchableOpacity>
                        <Image style={styles.ficon3} source={require('../../../image/item.png')} />
                    </TouchableOpacity>
                    {category ?
                        <Dropdown
                            style={[styles.dropdown]}
                            placeholderStyle={styles.placeholderStyle}
                            selectedTextStyle={styles.selectedTextStyle}
                            itemTextStyle={{ color: "#afb0b6" }}
                            data={category}
                            maxHeight={300}
                            labelField="label"
                            valueField="value"
                            placeholder={!isFocus ? (t("Product name")) : "..."}
                            // value={value}
                            onFocus={() => {
                                setIsFocus(true)
                            }}
                            onBlur={() => setIsFocus(false)}
                            onChange={(item) => {
                                console.log('JJ', item)
                                setdropdownvalue(item, 0)
                                setIsFocus(false);
                            }}
                        /> : null}
                    <TextInput keyboardType="numeric" onEndEditing={(event) => setqtyvalue(event.nativeEvent.text, 0, 2,'')} value={qtyArray} style={{ borderWidth: 2, width: '20%', marginLeft: 10, height: 60, marginTop: 20, borderRadius: 10, borderColor: '#AFB0B6', fontSize: 20 }}></TextInput>
                </View>
                {qtyArray === '' && submitted ? <Text style={styles.chooseUserName}>Please Enter Qty value</Text> : null}
                <View>{textInputs}</View>
                <TouchableOpacity onPress={handleAddInput}>
                    <View style={{ flexDirection: 'row', marginLeft: 10 }}>
                        <Image style={styles.ficon1} source={require('../../../image/add.png')} />
                        <Text style={{ color: 'black', fontSize: 19, marginTop: 5 }}>{t('Add Item')}</Text>
                    </View>
                </TouchableOpacity>
                <View>{cunstomtextInputs}</View>
                <TouchableOpacity onPress={handleAddInput2}>
                    <View style={{ flexDirection: 'row', marginLeft: 10 }}>
                        <Image style={styles.ficon1} source={require('../../../image/add.png')} />
                        <Text style={{ color: 'black', fontSize: 19, marginTop: 5 }}>{t('Add Miscellanous')}</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.btn} onPress={passarray2}>
                    <Text style={styles.btninner} >
                        {t('Save')}
                    </Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    )

}
export default Nquo;