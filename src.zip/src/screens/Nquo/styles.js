import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
    },
    
    ficon3:{
        width:35,
        height:35,
        margin:9,
        position:'absolute',
        top:20,
        left:10
      },
      dropdown: {
        // height: 50,
        borderColor: '#AFB0B6',
        // borderWidth: 0.5,
        borderRadius: 10,
        paddingHorizontal: 8,
        borderWidth:2,
        // borderBottomWidth:1,
        width:'70%',
        // alignSelf:'center',
        borderStyle: 'solid',
        // paddingLeft:'2%',
        marginTop:20,
        marginLeft:13,
        height:60
        
      },
      dropdown2:{

        borderWidth: 2,
         margin: '5%',
          padding: '0%', 
          borderColor: '#afb0b6',
           borderRadius: 10,
           height:50

      },
      dropdown3:{
        borderWidth: 2,
      
         padding: '0%', 
         borderColor: '#afb0b6',
          borderRadius: 10,
          height:50,
          width:'45%',
          marginTop:8,
          margin:5
      },
      placeholderStyle: {
        fontSize: 18,
        color: '#AFB0B6',
        fontFamily:'Poppins-bold',
        marginLeft:57
        // borderWidth:1
      },
      selectedTextStyle: {
        fontSize: 17,
        color:'#000000',
        fontFamily:'Poppins-bold',
        marginLeft:57

        // borderWidth:1
      },
      ficon1:{
        width:20,
        height:20,
        margin:9,
    },
    btn:{
        height:45,borderRadius:3,backgroundColor:'#346696',width:'37%',marginLeft:'33%',marginTop:'30%'
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    spinner: {
      flex: 1,
      justifyContent: 'center',
      backgroundColor:'rgba(24, 24, 24, 0.075)',
      position:'absolute',
      top:0,
      zIndex:9999,
      height:'100%',
      width:'100%'
    },
    chooseUserName2:{
      color:'#cc1a1a',
      textAlign:'left',
      alignContent:'flex-start',
      fontFamily:'Poppins-Regular',
      marginLeft:25,
      // borderWidth:1,
      marginTop:-18,
      marginBottom:5
  },
  chooseUserName:{
    color:'#cc1a1a',
    textAlign:'left',
    alignContent:'flex-start',
    fontFamily:'Poppins-Regular',
    marginLeft:25,
    // borderWidth:1,
    
},
})
