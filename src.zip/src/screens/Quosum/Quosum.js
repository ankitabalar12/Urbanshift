import React, { useState, useEffect } from "react";
import {
    Image,
    ScrollView,
    Text,
    TouchableOpacity,
    View,
    StatusBar,
    ActivityIndicator,
    Dimensions
} from "react-native";


import { styles } from "./styles";
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-community/async-storage';
import '../../../i18n';
import { useTranslation } from 'react-i18next';



const Quosum = ({ navigation, route }) => {
    const [comname, setcomname] = useState('');
    const [loading, setLoading] = useState(false);
    const [dname, setdname] = useState(false);
    const [conname, setconname] = useState(false);
    const [vnumber, setvnumber] = useState(false);
    const [brand, setbrand] = useState(false);
    const [model, setmodel] = useState(false);
    const [qty2, setqty2] = useState('');
    const [description, setdescription] = useState([]);
    const [itemname, setitemname] = useState([]);
    const [selling_price, setselling_price] = useState([]);
    const [total, setTotal] = useState('');
    const [totalarray, setparray] = useState([]);
    const [qtyarray, setqtyarray] = useState([]);
    const [final, setfinal] = useState('');
    const [subprice, setsubprice] = useState([]);
    const { t, i18n } = useTranslation();
    const [Value, setValue] = useState('');
    const [currentLanguage, setLanguage] = useState('');
    const [quonumber, setquonumber] = useState('');
    const [quodate, setquodate] = useState('');
    const [zero, setzero] = useState('');
    const [quonumbersave, setquonumbersave] = useState('');
    const [height, setHeight] = useState('');
    const [width, setWidth] = useState('');
    const [last, setlast] = useState('');
    const [len, setlen] = useState('');
    const [lenght, setlenght] = useState('');

    useEffect(() => {

        navigation.addListener('focus', async () => {
            const typee = await AsyncStorage.getItem('type');
            //console.log('type== => ', typee);
            //Get device Height
            setHeight(Dimensions.get('screen').height);
            //console.log('height>>>', height)
            global.he = height
            //Get device Width
            setWidth(Dimensions.get('screen').width);
            //console.log('width>>>', width)
            global.we = width


            quonum();

            selectlan(typee)
            const Nquo = route.params
            //console.log('myarr-------------', Nquo)

            const screenData = JSON.parse(Nquo);
            var data2 = screenData.map(function (item) {
                return {
                    key: item.id,
                    label: item.name
                };
            });

            setcomname(data2[0].label)
            setdname(data2[2].label)
            setconname(data2[5].label)
            setvnumber(data2[1].label)
            setbrand(data2[3].label)
            setmodel(data2[4].label)
            setquodate(data2[10].label)
            //const qtyarray2 = data2[7].label
            const qtyarray2 = data2[7].label.filter((item) => item !== null && item !== undefined);

            console.log('setqty2>>>', qtyarray2)


            setqty2(qtyarray2)
            //console.log('getdata2[7].label>>>', data2[7].label)
            //console.log('getdata2[8].label>>>', data2[8].label)
            const desc = data2[8].label // ['abcd','abcd']
            setlast(desc)
            //console.log('desc', desc.join(","))//abcd,abcd
            global.des = desc.join(",")
            setdescription(global.des)
            //console.log('description', description)



            const Price = data2[9].label
            //console.log('Price')
            const pricearray = Price.split(",")
            setselling_price(Price)
            //console.log('----------------------------*********************-----------------------')
            var NewText = ''
            var multi = ''
            var totalprice = ''
            var iyear = ''

            {
                qtyarray2.map((ar, index) => (
                    NewText = pricearray[index].replace("$", ""),
                    multi = NewText * ar,
                    totalprice = Number(totalprice) + Number(multi),
                    subprice.push(multi)
                ))
            }

            //console.log('total-----', totalprice)
            setfinal(totalprice)
            //console.log(subprice)
            //console.log('----------------------------*********************-----------------------')
        })
    }, []);

    const quonum = async () => {
        const result = await AsyncStorage.getItem('QasLogin')
        const screenData = JSON.parse(result)
        setLoading(true)
        fetch(global.url + 'getquotationid.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-type': 'application/json',
            },
            body: JSON.stringify({
                user_id: screenData.id,

            }),
        }).then((res) => res.json())
            .then(async (json) => {

                if (json.ResponseCode == '1') {
                    //console.log('json.>', json)
                    setquonumber(json.quotation_id)
                   setlen(json.quotation_id)
                     //console.log('len>>',len)
                   
                     const paddedNumber = String(json.quotation_id).padStart(6, '0');
                     //console.log('paddedNumber>>',paddedNumber)
                     setzero(paddedNumber)
                }

                setLoading(false)

            })
            .catch((err) => {
                //console.log(err)
            })

    }


    const selectlan = async (value) => {
        //console.log('selectedd', value)
        setValue(value)
        if (value == '1') {
            changeLanguage('en')
        }
        if (value == '2') {
            changeLanguage('hi')
        }


    }

    const changeLanguage = value => {
        i18n
            .changeLanguage(value)
            .then(() => setLanguage(value))
            .catch(err => console.log(err));
    };
    const addquo = async () => {
        const result1 = await AsyncStorage.getItem('QasLogin')
        const user = JSON.parse(result1)
        // const result1 = await AsyncStorage.getItem('QasLogin')
        // const screenData = JSON.parse(result1)
        const Nquo = route.params
        //console.log(Nquo)
        const screenData = JSON.parse(Nquo);
        var data = screenData.map(function (item) {
            return {
                key: item.id,
                label: item.name
            };
        });

        const qtyarray2 = data[7].label.filter((item) => item !== null && item !== undefined);

       
        setLoading(true)
        fetch(global.url + 'addquotation.php', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: user.id,
                company_name: data[0].label,
                vehicle_number: data[1].label,
                driver_name: data[2].label,
                vehicle_brand: data[3].label,
                vehicle_model: data[4].label,
                contact_number: data[5].label,
                item: data[8].label.toString(),
                qty: qtyarray2.toString(),
                price: data[9].label
            }),
        })
            .then((res) => res.json())
            .then(async (json) => {
                if (json.ResponseCode == '1') {

                    // alert('okok')
                    //console.log('Response %%%%%%%%%%%%%%%%=>', json)
                    //console.log('qas id>>', json.quotation_id)
                    // //console.log('screndata.quotation_id>>',screenData.quotation_id)
                    // await AsyncStorage.setItem('quoid', JSON.stringify(screenData.quotation_id));
                    navigation.navigate('Home')
                    //console.log()

                    setLoading(false)
                    alert(json.ResponseMsg)
                }
                else {
                    alert(json.ResponseMsg)
                }

            })
            .catch((err) => {
                //console.log(err);
                //console.log(err)
            });
    }

    return (
        <View style={styles.maincontainer}>
            <ScrollView style={{ bottom: 10 }}>
                <StatusBar backgroundColor='#fafafd' barStyle="dark-content" />
                <View style={{ margin: 30 }}>
                    <View style={{ height: 10 }}></View>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="chevron-back" size={35} style={{ color: '#0d0d26', marginLeft: -10 }} />

                        {/* <Image style={styles.ficon} source={require('../../../image/back.png')} /> */}
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: '#0d0d26', fontWeight: 'bold', marginTop: 10 }}>{t('Quotation Summary')}</Text>
                    <View style={{ height: 15 }}></View>
                    {loading ?
                        <View style={styles.spinner}>
                            <ActivityIndicator size="large" color="#1976d2" animating={loading} />
                        </View>
                        : null}
                    {/* <View><Text>{height}</Text></View>
                        <View><Text>{width}</Text></View> */}
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Quotation Number')}</Text>
                        </View>

                        <View style={styles.view}>
                            <Text style={styles.sw1}>{zero}</Text>
                        </View>

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Quotation Date')}</Text>
                        </View>

                        <View style={styles.view}>
                            <Text style={styles.sw1}>{quodate}</Text>
                        </View>

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Comapany Name')}</Text>
                        </View>

                        <View style={styles.view}>
                            <Text style={styles.sw1}>{comname}</Text>
                        </View>

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Driver Name')}</Text>
                        </View>



                        <View style={styles.view}>
                            <Text style={styles.sw1}>{dname}</Text>
                        </View>

                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Contact Name')}</Text>
                        </View>



                        <View style={styles.view}>
                            <Text style={styles.sw1}>{conname}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Vehicle Number')}</Text>
                        </View>


                        <View style={styles.view}>
                            <Text style={styles.sw1}>{vnumber}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Brand')}</Text>
                        </View>



                        <View style={styles.view}>
                            <Text style={styles.sw1}>{brand}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>
                    <View style={styles.frow}>
                        <View style={{ width: '50%' }}>
                            <Text style={styles.fw}>{t('Model')}</Text>
                        </View>



                        <View style={styles.view}>
                            <Text style={styles.sw1}>{model}</Text>
                        </View>
                    </View>
                    <View style={{ height: 10 }}></View>

                    <View style={styles.box}>
                        <View style={styles.hadding}>
                            <Text style={styles.h1}>{t('Description')}</Text>

                            <Text style={styles.h3}>{t('QTY')}</Text>
                            <Text style={styles.h4}>{t('Total Price(SGD)')}</Text>

                        </View>
                        {qty2 != '' ?
                            <View>
                                {qty2.map((ar, index) => (

                                    <View style={styles.sub1}>
                                        <View style={styles.spash}><Text style={styles.destext}>{last[index]}</Text></View>
                                        {ar != ''?
                                            <Text style={styles.t3}>{ar}</Text>
                                           :null
                                        }
                                        {subprice[index] != ''?
                                            <Text style={styles.t4}>${subprice[index]}</Text>
                                            :null    
                                        }

                                        
                                        

                                    </View>
                                ))}

                            </View> : null

                        }
                        {/* {height<'700'?
                            <View style={styles.desview2} >
                            {description.map((des, index) => (
                                                // //console.log('desloop>>>>>>>>>>>>>>',des)
                                                
                                                <Text style={styles.tt}>{des}</Text>
                                                
                                                ))}
                            </View>
                            :
                        <View style={styles.desview} >
                        {description.map((des, index) => (
                                            // //console.log('desloop>>>>>>>>>>>>>>',des)
                                        
                                            <Text style={styles.t1}>{des}</Text>
                                        
                                            ))}
                        </View>
                        } */}


                        <TouchableOpacity >
                            <View style={styles.hadding2}>
                                <Text style={styles.hh1}>{('Grand Total')}</Text>

                                <Text style={styles.hh5}>${final}</Text>
                            </View>

                        </TouchableOpacity>
                    </View>



                </View>
                <TouchableOpacity style={styles.btn} onPress={addquo} >
                    <Text style={styles.btninner} >
                        {t('Submit')}
                    </Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    )

}
export default Quosum;
