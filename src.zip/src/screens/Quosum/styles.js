import { StyleSheet, Platform } from "react-native";

export const styles = StyleSheet.create({
    maincontainer: {
        backgroundColor: '#fafafd',
        height: '100%',
        marginTop: Platform.OS === "ios" ? 35 : 0,
        // borderWidth:1
    },
    main:{
        width: '100%', flexDirection: 'row' ,marginLeft:30,marginBottom:10,marginTop:-5,borderWidth:0
    },
    sub:{
        width: '35%' 
    },
    frist:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18
    },
    fline:{
        textAlign: 'left', color: '#526578', fontSize: 18
    },
    view:{
        width: '35%',marginLeft:10
    },
    frow:{
        width: '100%', flexDirection: 'row',borderWidth:0
    },
    fw:{
        textAlign: 'left', color: '#8a97a4', fontSize: 18,marginLeft:10
    },
    sw:{
        textAlign: 'right', color: '#526578', fontSize: 18
    },
    sw1:{
        textAlign: 'left', color: '#526578', fontSize: 18
    },
    view:{
        width: '45%',marginLeft:10
    },
    box:{
        borderWidth:2,
        // margin:10,
        borderColor:'#e5e5e5',
        borderRadius:10,
        width:'100%',
        
    },
    hadding:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        backgroundColor:'#346696',
        height:43,
        // borderWidth:1,
        width:'100%'
      },
    hadding2:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        backgroundColor:'#346696',
        height:40,
        // borderWidth:1,
        width:'100%'
    },
    hh1:{
        color:'#ffffff',
        // marginLeft:'3%',
        fontSize:18,
        // marginRight:'7%',
        marginTop:5,
        width:'73%',
        paddingLeft:10
        // marginLeft:5
        // borderWidth:1
    },
    h1:{
        color:'#ffffff',
        width:'38%',
        fontSize:18,
        // borderWidth:1,
        // textAlign:'center',
        // paddingTop:'2%',
        textAlignVertical:'center',
        marginLeft:'2%'
    },
    h3:{
        color:'#ffffff',
        width:'20%',
        fontSize:18,
        // marginTop:5,
        // borderWidth:1,
        textAlign:'center',
        // paddingTop:'1%'
        textAlignVertical:'center'

    },
    h4:{
        color:'#ffffff',
        width:'40%',
        fontSize:18,
        // marginTop:5,
        // borderWidth:1,
        textAlign:'center',
        // paddingTop:'1%'
        textAlignVertical:'center'

    },
    h5:{
        color:'#ffffff',
        marginLeft:'30%',
        fontSize:18,
        marginTop:5,
        flex:1,
        justifyContent:'flex-end'
        // borderWidth:1

    },
    hh5:{
        color:'#ffffff',
        // marginLeft:'30%',
        fontSize:18,
        marginTop:5,
        // flex:1,
        // justifyContent:'flex-end',
        // borderWidth:1,
        width:'25%',
        // paddingLeft:'10%',
      

    },
    sub1:{
        // borderWidth:1,
        flex:1,
        flexDirection:'row',
        borderBottomColor:'#e5e5e5',
        borderBottomWidth:2,
        margin:'2%',
        padding:'1%'
       
    },
    
    t1:{
     
        // marginLeft:'2%',
         fontSize:18,
         color:'#000000',
       
        //  borderWidth:1,
        //  margin:20,
         marginTop:20,
         marginBottom:20,
         marginLeft:7
        //  width:'40%',
        //  textAlign:'center'
        
     },
    tt:{
     
        // marginLeft:'2%',
         fontSize:18,
         color:'#000000',
       
        //  borderWidth:
         marginTop:20,
         marginBottom:20,
         marginLeft:15,
         marginTop:35
        //  width:'40%',
        //  textAlign:'center'
        
     },
 
     desview:{
        position:'absolute',
        // borderWidth:1,

        top:26,
        paddingTop:5
     },
     desview2:{
            position:'absolute',
            // borderWidth:1,

            top:35,
            paddingTop:5
     },
     spash:{
        // borderWidth:1,
        // position:'absolute',
        margin:10,
        width:'33%',
        marginTop:3
       
     },
     tt1:{
        // marginLeft:'2%',
        fontSize:18,
        color:'#000000',
        // borderWidth:1,
        width:'40%'
     },
     ttt1:{
        marginLeft:'2%',
        fontSize:18,
        color:'#000000',
        // borderWidth:1
     },
   
     t2:{
        
         marginLeft:'11%',
         fontSize:18,
         color:'#000000'
 
     },
     t3:{
        
        //  marginLeft:'12%',
         fontSize:18,
         color:'#000000',
         width:'20%',
         textAlign:'center'
 
     },
     t4:{
        // marginLeft:'34%',
        fontSize:18,
        color:'#000000',
        width:'40%',
        textAlign:'center'
     },
     textinput:{
        borderWidth:2,
        marginTop:30,
        fontSize:16,
        borderColor:'#a3a3a3',
        borderRadius:10
        // paddingTop:-5
        
      },
      btn:{
        height:45,borderRadius:3,backgroundColor:'#346696',width:'37%',marginLeft:'33%',marginTop:35
    },
    btninner:{
        textAlign:'center',color:'white',fontSize:18,fontWeight:'bold',marginTop:7
    },
    spinner: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor:'rgba(24, 24, 24, 0.075)',
        position:'absolute',
        top:0,
        zIndex:9999,
        height:'100%',
        width:'100%'
      },
      descri:{
    
        // top:'-24%',
        marginLeft:10,
        // marginBottom:10,
        // borderWidth:1,
    //   position:'absolute',
        marginBottom:30,
    
      },
      destext:{
        fontSize:17,
        color:'#000000'
      }
})
