import React, { useState, useEffect } from 'react';
import { ScrollView, Text, TextInput, TouchableOpacity, StatusBar, SafeAreaView, View, Image, ActivityIndicator } from 'react-native';
import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-community/async-storage';
import { resetNavigateTo } from '../../../NavigationHelper';



export default function Login({ route, navigation }) {
  const [password, setPassword] = useState('');
  const [passwordVisibility, setPasswordVisibility] = useState(true);
  const [email, setEmail] = useState('');
  const [submitted, setsubmitted] = useState(false)
  const [loading, setLoading] = useState(false);
  const [key, setkey] = useState(0);
  const [utype, setUsertype] = useState('');
  useEffect(() => {
    async function fetchData() {
      const keyc = route.params
      setkey(keyc)
      //console.log('loginpage user =>', keyc)
      //  //console.log('global.tokenId.token',global.tokenId.token)

    }
    fetchData();
  }, [])


  const handlePasswordVisibility = () => {
    setPasswordVisibility(!passwordVisibility);
    //console.log(passwordVisibility)
  };
  const car = async (vnum) => {

    setLoading(true)

    if (vnum !== '') {

      {
        fetch(global.url + 'getuserprofile.php', {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            vehicle_number: vnum
          }),
        })
          .then((res) => res.json())
          .then(async (json) => {
            //console.log('ResponseMsg', json)
            if (json.ResponseCode == '1') {
              //console.log('ResponseMsg', json)

              // await AsyncStorage.setItem('startScreen', "loginsucess");
              //console.log(json.user_data);
              await AsyncStorage.setItem('full_name', JSON.stringify(json.user_data.full_name));
              setLoading(false)
            }
            else {
              alert(json.ResponseMsg)
            }
            setLoading(false)
          })
          .catch((err) => {
            //console.log(err);
            //console.log(err)
          });


      }
    }

  }

  const submit = () => {
    const keyc = route.params
    //console.log('loginpage user =>', keyc)
    setsubmitted(true);
    //console.log('&&&&&&&&&&&&&')
    //console.log(email)
    if (key == '1') {
      if (password !== '') {

        //console.log('customer')
        // if (email !== '' 
        // //  &&
        //   // password !== ''
        //   ) 
        {
          setLoading(true);
          //console.log('condition true')
          fetch(global.url + 'login.php', {
            method: 'POST',
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              username: password,
              // device_id: global.tokenId.token,
              device_id: '',
              type: 1
            }),
          })
            .then((res) => res.json())
            .then(async (json) => {
              //console.log(json)
              //console.log('*****', email, '*****', password)
              if (json.ResponseCode == '1') {
                await AsyncStorage.setItem('startScreen', "loginsucess");
                await AsyncStorage.setItem('usertype', "1");
                await AsyncStorage.setItem('QasLogin', JSON.stringify(json.user_data));
                resetNavigateTo(navigation, 'Home', json.user_data.vehicle_number);
                setLoading(false);
                // setEmail('');
                setPassword('');
                // car(password);
              } else {
                alert(json.ResponseMsg)
                setLoading(false)
              }
            })
            .catch((err) => {
              //console.log(err);
              //console.log(err)
            });
        }
      }
    } else {
      //console.log('mechanic')
      if (email !== '' && password !== '') {
        setLoading(true);
        //console.log('condition true')
        fetch(global.url + 'login.php', {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: email,
            password: password,
            // device_id:global.tokenId.token,          
            device_id: '',
            type: 2
          }),
        })
          .then((res) => res.json())
          .then(async (json) => {
           
            //console.log('*****', email, '*****', password)
            if (json.ResponseCode == '1') {
              //console.log('json>>>>',json)
              await AsyncStorage.setItem('startScreen', "loginsucess");
              await AsyncStorage.setItem('usertype', "2");
              await AsyncStorage.setItem('QasLogin', JSON.stringify(json.user_data));


              resetNavigateTo(navigation, 'Home');
              // navigation.navigate('Home')
              setLoading(false);
              setEmail('');
              setPassword('');
            } else {
              alert(json.ResponseMsg)
              setLoading(false)


            }
          })
          .catch((err) => {
            //console.log(err);
            //console.log(err)
          });
      }
    }
  }

  return (

    <SafeAreaView style={{ flex: 1, backgroundColor: '#fafafd' }}>

      <View style={styles.maincontainer}>
        <ScrollView>
          <StatusBar backgroundColor='#fafafd' barStyle='dark-content' />

          <TouchableOpacity onPress={() => navigation.goBack()}>
            {/* {/ <Image source={require('../../../image/back.png')} /> /} */}
            <Ionicons name="chevron-back" size={35} style={{ color: 'black', marginLeft: 20 }} />
          </TouchableOpacity>
          <View style={{ margin: 30 }}>
            <View style={{ height: 90 }}></View>
            <Text style={styles.frst}>
              QAS Auto

            </Text>
            <Text style={{ marginTop: 10, fontSize: 35, color: 'black', fontWeight: 'bold' }}>
              Welcome Back 👋
            </Text>
            <Text style={{ marginTop: 10, fontSize: 17 }}>
              Let's log in to view your
            </Text>
            <Text style={{ fontSize: 17 }}>
              appointments!
            </Text>

            <View style={{ height: 20 }}></View>
            {key == '1' ?
              <View>
                <View style={{ height: 8 }}></View>
                <View style={styles.showinput}>
                  <Image style={styles.ficon} source={require('../../../image/pass.png')} />
                  <TextInput
                    style={styles.textInput}
                    name="password"
                    placeholder="Enter your car number"
                    autoCapitalize="none"
                    autoCorrect={false}
                    textContentType="newPassword"
                    secureTextEntry={passwordVisibility}
                    value={password}
                    enablesReturnKeyAutomatically
                    onChangeText={text => setPassword(text)}
                  />
                  <TouchableOpacity style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} onPress={() => handlePasswordVisibility()}>
                    {passwordVisibility == true ?
                      <Ionicons name="eye-off-outline" size={25} style={{ margin: 6 }} />
                      :
                      <Ionicons name="eye" size={25} style={{ margin: 6 }} />
                    }
                  </TouchableOpacity>
                </View>
                {password === '' && submitted ? <Text style={styles.validate}>Please enter car number</Text> : null}
                <View style={{ height: 20 }}></View>
              </View>
              :
              <View>
                <View style={styles.showinput}>
                  <Ionicons name="mail-outline" size={25} color={'#afb0b6'} style={{ margin: 6 }} />
                  <TextInput style={styles.textInput} onChangeText={(value) => setEmail(value)} value={email} placeholder="E-mail" />
                </View>
                {email === '' && submitted ? <Text style={styles.validate}>Please enter Email </Text> : null}
                <View style={{ height: 8 }}></View>
                <View style={styles.showinput}>
                  <Image style={styles.ficon} source={require('../../../image/pass.png')} />
                  <TextInput
                    style={styles.textInput}
                    name="password"
                    placeholder="Enter password"
                    autoCapitalize="none"
                    autoCorrect={false}
                    textContentType="newPassword"
                    secureTextEntry={passwordVisibility}
                    value={password}
                    enablesReturnKeyAutomatically
                    onChangeText={text => setPassword(text)}
                  />
                  <TouchableOpacity style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }} onPress={() => handlePasswordVisibility()}>
                    {passwordVisibility == true ?
                      <Ionicons name="eye-off-outline" size={25} style={{ margin: 6 }} />
                      :
                      <Ionicons name="eye" size={25} style={{ margin: 6 }} />
                    }
                  </TouchableOpacity>
                </View>
                {password === '' && submitted ? <Text style={styles.validate}>Please enter password </Text> : null}
                <View style={{ height: 20 }}></View>
              </View>
            }
            <TouchableOpacity style={styles.btn} onPress={submit}>
              <Text style={styles.btninner}>
                Log in
              </Text>
            </TouchableOpacity>
            {loading ?
              <View style={styles.spinner}>
                <ActivityIndicator size="large" color="#1976d2" animating={loading} />
              </View>
              : null}
            <View style={{ height: 20 }}></View>
            <TouchableOpacity onPress={() => navigation.navigate('Forgotpass')}>
              <Text style={{ fontSize: 20, color: '#346696', textAlign: 'center' }}>Forgot Password?</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};
